#ifndef		__DEMO_PAGE_FLIPPING_H__
#define		__DEMO_PAGE_FLIPPING_H__

#include "updtedvr.h"

extern void select_page_flipping(DEMO_SCREEN_UPDATE_DRIVER *driver);

#endif				/* __DEMO_PAGE_FLIPPING_H__ */
