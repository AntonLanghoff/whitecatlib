#ifndef		__DEMO_DOUBLE_BUFFER_H__
#define		__DEMO_DOUBLE_BUFFER_H__

#include "updtedvr.h"

extern void select_double_buffer(DEMO_SCREEN_UPDATE_DRIVER *driver);

#endif				/* __DEMO_DOUBLE_BUFFER_H__ */
