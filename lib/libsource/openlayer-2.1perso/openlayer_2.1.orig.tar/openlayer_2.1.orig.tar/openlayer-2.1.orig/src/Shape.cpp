#include "Shape.hpp"

ol::Shape::
~Shape() {}


void ol::Shape::
RotateBy( float angle ) {}


void ol::Shape::
TransformBy( const Placement &placement ) {}

