#include "Internal.hpp"


#include "Internal.hpp"

namespace ol {

bool firstLog = true;

}
