MidiShare MMSystem Driver
________________________________________________________________________

The MidiShare MMSystem Driver provides MIDI input/output to MidiShare
client applications. It is build on top of Windows MMSystem layer.
It should provide access to all the ports available in the MIDI tab 
of the Multimedia control panel.
To install this driver as a MidiShare components, see the MidiShare 
documentation.

When first activated, the driver generate a file named msMMSystem.ini
in the client application folder. This file declares all the available
slots followed by a list of ports numbers representing input or output 
ports connections. To modify these connections, uses the msDriver 
application.
Further activation of the driver will use this ini file to restore
the slots connections.

The msMMSystem.ini file is read in precedence order:
first  : in the client application folder
second : in the windows folder
If you want to share the .ini file among several applications, put it in
the windows folder.

In case of problem, the msMMSystem driver generates a log file named
msMMSystem.log in the client folder: it contains a description of the 
problem and if available, the reason.

________________________________________________________________________
The MidiShare MMSystem driver has been developped by Grame with the 
contribution of Sony CSL - Paris.
For more information, see at http://www.grame.fr/MidiShare/
________________________________________________________________________
                  Grame - Computer Music Research Lab.
                            9, rue du Garet
                          69001 Lyon - France
                  grame@grame.fr    midishare@grame.fr
