 	MidiShare interface to Allegro Common Lisp



You must load the interface files to access MidiShare and Player functions in Lisp.

- The MidiShare-Interface.lisp file contains the definition of the MidiShare types 
and MidiShare functions. Some MidiShare functions are not interfaced 
because Lisp callback can not be used safely by MidiShare.

- The Player-Interface.lisp is the interface file for the Player library. 

- The tutorial folder contains tutorials on most of MidiShare and Player functions.

Please report bugs, comments to midishare@grame.fr

