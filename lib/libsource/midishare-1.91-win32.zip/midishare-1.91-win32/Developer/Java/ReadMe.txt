			MidiShare Java Kit 1.24



Installation
------------

- the JMidi.dll,JPlayer.dll files have to be installed in the local JVM (usually in JRExx/bin) or
in the folder where the MidiShare/Java application will run

- the grame.jar file contains the native classes, it must be installed in the local JVM 
(usually in JRExx/lib/extensions)


Versions
--------

1.00 01/23/97 First release.
1.15 06/12/97 MIDIFile management is now complete. More functions to deal with MidiShare 
events and sequences have been added (see the MidiEvent and MidiSequence classes). 
The documentation has been updated.
1.21 09/01/98 This release uses the MidiShare Thunk version. It allows to access the 
MidiShare 16 bits kernel which is more stable and efficient from Java (a 32 bits environment).
1.22 09/07/01 This release uses the MidiShare win-mono version.
1.23 12/17/01 Update of the documentation, updated installation instructions.
1.24 17/03/05 Updated for MidiShare 1.88 release


Known problems and limitations
------------------------------

Different MidiShare clients won't be able to communicate unless they run
in the same address space (ie they belong to the same process).
It is not recommended to launch several MidiShare clients using the mono-
application MidiShare version. If you do so, they won't be able to share 
the input output devices.
 

Please send any bug report and comments to midishare@grame.fr


