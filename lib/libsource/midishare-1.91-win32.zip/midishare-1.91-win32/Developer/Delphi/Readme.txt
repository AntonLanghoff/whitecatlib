The Delphi32 package is the translation in Borland Delphi 4 of the Mshare.h file 
and the Tutorial,  msEcho & msCtrl programs.

This file describe the contents of the msDelphi package.


A) Mshare32.pas
=============

This is the Delphi version of Mshare.h minus some macros done by the C pre-processor. 
This file is mandatory to access MidiShare kernel routines (Mshare32.dll). 
You need to copy this file into your units folder.


Remarks :
---------


2) The conditional compilation is specific to my MIDI configuration.

{$ifdef MDX}
      if e^.port = 1 then e^.port := 2;
{$endif}

I have 2 MIDI In and 3 MIDI Out, then I have a mismatch of port number for the same device.

3) The "Go" command is the "G" or "g" key.


B) Tutorial
===========

This is the translation of the C Tutorial program.

Files :
-------

1) Tutorial.dpr, About.dfm, About.pas, Debug.dfm, Debug.pas, Main.dfm, Main.pas, 
SubTutor.pas, msGlobal.pas, Tutorial.opt, Tutorial.res : main program.




C) msCtrl
===========

This is the translation of the C msCtrl program.

Files :
-------

1) msCtrl.dpr, About.dfm, About.pas, Main.dfm, Main.pas, msCtrl.opt, msCtrl.res : main program.

  


D) msEcho
===========

This is the translation of the C msEcho program.

Files :
-------

1) msEcho.dpr, About.dfm, About.pas, Main.dfm, Main.pas, msGlobal.pas, msEcho.opt, 
msEcho.res : main program.
 you need to put the delay parameter to 1000 and the velocity parameter to -10


This software claims no warranty, implied or otherwise. This software is provided "AS IS". 
The author claims no responsibility for any damages that might be caused by the use 
or abuse of this software.
To use this package with Delphi16 under Windows98, you must copy bc45rtl.dll and bwcc.dll
from the units folder to your windows folder 


Contact : Alain RIVIERE, 100437.3605@compuserve.com
modified 23/3/99 by Jean-Philippe Fabre, jpfabre@yahoo.fr to run on delphy 1.0 and delphy 4
                            