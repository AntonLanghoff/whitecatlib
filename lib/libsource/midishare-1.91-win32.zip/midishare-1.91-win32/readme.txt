________________________________________________________________________
How to install MidiShare mono-application release
________________________________________________________________________
Put the mshare32.dll, midishare.ini and the desired drivers
into the application folder (any MidiShare client application)
The file mshare32.dll is the current MidiShare kernel library.
For the drivers setup, see the drivers section.

If you want to share the DLLs and the .ini files between several
client applications, you can also put them into the Windows folder.

General behavior concerning the required DLLs and the midishare.ini 
files is the following : 
the required files are read in precedence order:
first  : in the client application folder
second : in the windows folder


________________________________________________________________________
MidiShare Drivers
________________________________________________________________________
MidiShare Drivers are separate components, provided as DLLs. 
The 'midishare.ini' file includes a 'Drivers' section. At wakeup time,
the MidiShare kernel loads all the DLLs included in the 'active' item
of the 'Drivers' section. To disable a driver, simply move it to the
'disable' item.
Available drivers are the following:
msMMSystem.dll  : provides MIDI input/output
msLANDriver.dll : provides real-time communication over a local network.
msWANDriver.dll : provides real-time communication over Internet.

The drivers behavior is controled using .ini files. When not found, the
driver uses default setup values.
The .ini files are read in precedence order:
first  : in the client application folder
second : in the windows folder
If you want to share a .ini file among several applications, put it in
the windows folder.

________________________________________________________________________
How to setup the MidiShare ports connections
________________________________________________________________________
You can use the msDrivers application. See Setup.html 


________________________________________________________________________
Compatibility issue
________________________________________________________________________
The new version of MidiShare is compatible with Windows 2000. 
It should equally run on ME, NT and previous windows versions (95, 98).
Existing 32 bits MidiShare client applications should run with the 
MidiShare mono-application version without any change.
 
________________________________________________________________________
Limitations
________________________________________________________________________
Different MidiShare clients won't be able to communicate unless they run
in the same address space (ie they belong to the same process).
It is not recommended to launch several MidiShare clients using the mono-
application MidiShare version. If you do so, they won't be able to share 
the input output devices.
 
________________________________________________________________________
Versions
________________________________________________________________________
MidiShare Kernel 'mshare32.dll' : 1.9.1.0

Available MidiShare Drivers
________________________________________________________________________
msMMSystem.dll  : 1.0.3.0
msLANDriver.dll : 1.0.1.0
msWANDriver.dll : 1.0.1.0

________________________________________________________________________
The MidiShare mono application release for windows 2000 has been 
developped by Grame with the contribution of Sony CSL - Paris.
For more information, see at http://midishare.sourceforge.net
________________________________________________________________________
                  Grame - Computer Music Research Lab.
                            9, rue du Garet
                          69001 Lyon - France
                  research@grame.fr    midishare@grame.fr
