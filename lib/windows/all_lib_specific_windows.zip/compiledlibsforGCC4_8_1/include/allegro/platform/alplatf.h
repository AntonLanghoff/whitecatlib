/* #undef ALLEGRO_BCC32 */
/* #undef ALLEGRO_BEOS */
/* #undef ALLEGRO_DJGPP */
/* #undef ALLEGRO_DMC */
/* #undef ALLEGRO_HAIKU */
/* #undef ALLEGRO_MACOSX */
#define ALLEGRO_MINGW32
/* #undef ALLEGRO_MPW */
/* #undef ALLEGRO_MSVC */
/* #undef ALLEGRO_PSP */
/* #undef ALLEGRO_QNX */
/* #undef ALLEGRO_UNIX */
/* #undef ALLEGRO_WATCOM */

/* These are always defined now. */
#define ALLEGRO_NO_ASM
#define ALLEGRO_USE_C
