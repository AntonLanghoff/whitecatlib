#ifndef OL_TRANSFORM_MATRIX_HPP
#define OL_TRANSFORM_MATRIX_HPP

#include "Declspec.hpp"


namespace ol {


class OL_LIB_DECLSPEC TransformMatrix {
public:
   
private:
   
};



}



#end� // OL_TRANSFORM_MATRIX_HPP
