#ifndef WINDOW_H
#define WINDOW_H

#ifdef __cplusplus
   extern "C" {
#endif

void position_window(int x, int y);

#ifdef __cplusplus
   }
#endif

#endif
