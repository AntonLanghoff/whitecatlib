/*----------------------------------------------------------------------------
 msScore.h

 Header file for MidiShare applications using msScore library. 

 e-mail: Jean-Jacques.CERESA@enac.fr
-----------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
 Versions informations.
 -----------------------------------------------------------------------------*/

#ifndef __MSSCORE_H__
#define __MSSCORE_H__

/*---------------------------------------------------------------------------*/
/* To use for Windows, add: #define __Windows__ in your sources files */


/*--- Definition for the Windows Operating System ---------------------------*/
#ifdef __Windows__		
#include "Midishare.h"

#ifdef WIN32 /* For WIN 32 applications or DLL */
/* for DLL library building add: #define  __BuildLib__  in your sources files */
	#ifdef __BuildLib__
		
		#define MSSCOREAPI  __declspec(dllexport) /* to export API functions */

	#else

		#define MSSCOREAPI  __declspec(dllimport) /* to import API functions */

	#endif

#else	/* Not WIN32 but WIN 16 bits */

	#define MSSCOREAPI WINAPI _export

#endif	/* WIN32 */
#endif	/* __Windows__ */

/*=============================================================================
=============================================================================*/

#define False               0
#define True                1

#define TicksPerQuarterNote	0

/*--------------- les types stock�s dans la tempo map -----------------------*/
//	typeCopyright, typeMarker, typeTempo, typeSMPTEOffset
//	typeTimeSign, typeKeySign

#define IsTempoMap( t) ( (t)==typeCopyright || (t)==typeMarker || \
							((t)>=typeTempo && (t)<=typeKeySign))

/*--------------- constantes d�finissant les codes d'erreur ------------*/
#define ErrOpen		1			/* ouverture du fichier impossible 	*/
#define ErrRead		2			/* erreur de lecture du fichier		*/
#define ErrWrite	3			/* erreur d'�criture du fichier		*/
#define ErrVol		4			/* erreur d�termination du volume 	*/
#define ErrGetInfo 	5			/* erreur lors de GetFInfo			*/
#define ErrSetInfo	6			/* erreur lors de SetFInfo			*/
#define ErrMidiFileFormat	7	/* mauvais format MidiFile 			*/

/*--------------------------------------------------------------------------*/

typedef struct MidiFileInfos  FAR * MidiFileInfosPtr;
typedef struct MidiFileInfos
{
	long format;					/* format du fichier				*/
	long timedef;					/* d�finition du temps				*/
	long clicks;					/* nbre de pas d'horloge/noire/frame*/
	long tracks;               		/* nombre de tracks                 */

}MidiFileInfos;

/*----------------------------------------------------------------------------
 for compatibility with Player MidiFileSave() and MidiFileLoad() API
 define the macro__UseMsScoreApi__ in your sources files.
 #define __UseMsScoreApi__
-----------------------------------------------------------------------------*/

#ifdef __UseMsScoreApi__
	#define MidiFileSave MidiFileScoreSave 
	#define MidiFileLoad MidiFileScoreLoad 
#endif
/*----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
int  MSSCOREAPI MidiFileScoreSave( char * name, MidiSeqPtr seq, 
							 MidiFileInfosPtr infos);

/*----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
int  MSSCOREAPI MidiFileScoreLoad( char * name, MidiSeqPtr seq, 
							 MidiFileInfosPtr infos);

/*---------------------------------------------------------------------------*/
#endif  /*  __MSSCORE_H__ */

