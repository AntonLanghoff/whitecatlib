/*----------------------------------------------------------------------------
 MsNotes.h

 Header file for MidiShare applications using MsNotes library. 

 e-mail: Jean-Jacques.CERESA@enac.fr
-----------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
 Versions informations.
 
 Octobre v 1.00. First version.
 Janvier v 1.01. This version is a replacement of the v 1.00.
 
 In v 1.01, somes existing bugs have been fixed and improvements added.
 Thanks to Alfio Fazio for bug reporting, suggestions and ideas.

 Bugs in v 1.00 fixed in v 1.01:
    - Bug on position and sizing of msNotes child window (S_CHILD): fixed.
	- Bug, access violation when one opens dialog box with msNotes
	  child window (S_CHILD): fixed.
	
 Improvements in v 1.01:
  - New set of clef: 
			BASS_OCT_DWN_CLEF	 ( Clef  Fa 3,  line 4	) (New)
			BASS_CLEF			 ( Clef  Fa 4,  line 4	)
			BARITON_CLEF		 ( Clef  Fa 4,  line 3	) (New)
			TENOR_CLEF			 ( Clef  Do 5,  line 4	)
			ALTO_CLEF			 ( Clef  Do 5,  line 3	)
			MEZZO_SOPRANO_CLEF	 ( Clef  Do 5,  line 2	) (New)
			SOPRANO_CLEF		 ( Clef  Do 5,  line 1	) (New)
			TREBLE_CLEF			 ( Clef  Sol 5, line 2	)
			TREBLE_OCT_DWN_CLEF	 ( Clef  Sol 4, line 2	) (New)
			TREBLE_OCT_UP_CLEF	 ( Clef  Sol 6, line 2	) (New)
			TREBLE_BASS_CLEF	 ( Clef  Sol 5, line 2  ) (New)
  
  - New fields in StaffInfos structure.
		Byte	SplitPitch;	// Split pitch for TREBLE/BASS staves				
		Byte	Flags;		// Hide height-zone line: HIDE_LINE_F							
	
	The user can also set these fields with the Staff infos dialog box.

  - New events accepted.The typeNote and typeTextual event are now accepted.
    
	TypeNote acts now as a pair of {typeKeyOn,typeKeyOff}. So these 3 events
	are accepted. However when user edit a {typeKeyOn,typeKeyOff} note, this
	pair of events are removed and replaced by a single typeNote event.
 
    TypeTextual event are displayed below the stave.
	The user can also edit text events.

-----------------------------------------------------------------------------*/

#ifndef __MSNOTES_H__
#define __MSNOTES_H__

/*---------------------------------------------------------------------------*/
/* To use for Windows, add: #define __Windows__ in your sources files */


/*--- Definition for the Windows Operating System ---------------------------*/
#ifdef __Windows__		
#include "Midishare.h"
#define nil 0
#ifdef WIN32 /* For WIN 32 applications or DLL */
/* for DLL library building add: #define  __BuildLib__  in your sources files */
#	ifdef __BuildLib__
		
#	   define MSNOTESAPI  __declspec(dllexport) /* to export API functions */

#	else

#	   define MSNOTESAPI  __declspec(dllimport) /* to import API functions */

#	endif
#	define MSNOTESALARMAPI	CALLBACK

#else	/* Not WIN32 but WIN 16 bits */

#   	define MSNOTESAPI WINAPI _export
#	define MSNOTESALARMAPI	WINAPI _export

#endif	/* WIN32 */


typedef HWND	hMsNotes;	/* Handle of a MsNotes window. */
typedef HWND	hMsParent;	/* Handle of a MsNotes window parent. */

#endif	/* __Windows__ */

/*=============================================================================
	Common types and declarations.
=============================================================================*/
typedef unsigned long       Dword;
typedef unsigned short      Word;
typedef unsigned char       Byte;
typedef Byte				Bool;
#define MakeWord(a, b)      ((Word)(((Byte)(a)) | ((Word)((Byte)(b))) << 8))
#define MakeLong(a, b)		((long)(((Word)(a)) | ((Dword)((Word)(b))) << 16))
#define LoWord(l)           ((Word)(l))
#define HiWord(l)           ((Word)(((Dword)(l) >> 16) & 0xFFFF))
#define LoByte(w)           ((Byte)(w))
#define HiByte(w)           ((Byte)(((Word)(w) >> 8) & 0xFF))

#define Max(a,b)            (((a) > (b)) ? (a) : (b))
#define Min(a,b)            (((a) < (b)) ? (a) : (b))

#define Null    ((void *)0)

#define False               0
#define True                1
/*---------------------------------------------------------------------------*/


/*=============================================================================
 These macros are useful for Getting and Setting informations
=============================================================================*/
#define LoWordInfos(li)	(LoWord(li))
#define HiWordInfos(li)	(HiWord(li))
#define LoByteInfos(wi)	(LoByte(wi))
#define HiByteInfos(wi)	(HiByte(wi))
#define MakeLongInfos(lw,hw) (MakeLong(lw,hw))
#define MakeWordInfos(lb,hb) (MakeWord(lb,hb))
/*------------ Macros for setting information -------------------------------*/
/* Build a XY_MSN information */
#define MakeXY_MSN(x,y) (MakeLongInfos(x,y))
/* Build a SIZE_MSN information */
#define MakeSIZE_MSN(w,h) (MakeLongInfos(w,h))
/* Build a SIGN_MSN information */
#define MakeSIGN_MSN(Num,Deno,Tone) (MakeLongInfos(	MakeWordInfos(Num,Deno), \
													MakeWordInfos(Tone,0)))
/* Build a BBU_MSN information */
#define MakeBBU_MSN(Beat,Bar) (MakeLongInfos(Beat,Bar)) 

/* Build a PORT_STAFF information */
#define MakePORT_STAFF(Part,Port) (MakeWordInfos(Part,Port))
/* Build a CHAN_STAFF information */
#define MakeCHAN_STAFF(Part,Chan) (MakeWordInfos(Part,Chan))

/*------------ Macros for getting informations ------------------------------*/
/* Return the X and X position from XY_MSN informations */	
#define XposXY_MSN(i) (LoWordInfos(i))	/* Return the X position	*/	
#define YposXY_MSN(i) (HiWordInfos(i))	/* Return the Y position	*/

/* Return the Width and Height from SIZE_MSN informations */	
#define WidthSIZE_MSN(i) (LoWordInfos(i)) /* Return the Width */
#define HeightSIZE_MSN(i)(HiWordInfos(i))/* Return the Height */

/* Return Numerator, Denominator and Tonality from SIGN_MSN informations */	
#define NumSIGN_MSN(i)	 (LoByteInfos(LoWordInfos(i)))	/* return numerator	*/
#define DenoSIGN_MSN(i)	 (HiByteInfos(LoWordInfos(i)))	/* return denominator */
#define iToneSIGN_MSN(i) (LoByteInfos(HiWordInfos(i)))	/* return Tonality	*/

/* Return the Bar and Beat from BBU_MSN informations */	
#define BeatBBU_MSN(i)	 (LoWordInfos(i))	/* Return Beat */
#define BarBBU_MSN(i)	 (HiWordInfos(i))	/* Return Bar  */

/* Return the Port and Part from PORT_STAFF informations */	
#define PartPORT_STAFF(i)	 (LoByteInfos(i))	/* return Part */
#define PortPORT_STAFF(i)	 (HiByteInfos(i))	/* return Port	*/

/* Return the Channel and Part from CHAN_STAFF informations */	
#define PartCHAN_STAFF(i)	 (LoByteInfos(i))	/* return Part */
#define ChanCHAN_STAFF(i)	 (HiByteInfos(i))	/* return Chan	*/

/*--Values of resolution(RES_MSN),and denominator(DENO_MSN) -----------------*/
#define WHOLE		1				// Value of a whole.
#define HALF		2				// Value of a half.
#define QUARTER		4				// Value of a quarter.
#define N8_TH		8				// Value of an eight.
#define N16_TH		16				// Value of an sixteenth.
#define N32_ND		32				// Value of a thirty second.
#define N64_TH		64				// Value sixty fourth.

/*-- Values of key signature (KEY_SIGN_MSN) ---------------------------------*/
enum	
{ 
	KEY_Cf,	/* Cf (7 flats ) */	KEY_Gf,	/* Gf (6 flats ) */
	KEY_Df,	/* Df (5 flats ) */	KEY_Af,	/* Af (4 flats ) */
	KEY_Ef,	/* Ef (3 flats ) */	KEY_Bf,	/* Bf (2 flats ) */
	KEY_F,	/* F  (1 flat  ) */	KEY_C,	/* C			 */
	KEY_G,	/* G  (1 sharp ) */	KEY_D,	/* D  (2 sharps) */
	KEY_A,	/* A  (3 sharps) */	KEY_E,	/* E  (4 sharps) */
	KEY_B,	/* B  (5 sharps) */	KEY_Fs,	/* Fs (6 sharps) */
	KEY_Cs	/* Cs (7 sharps) */
};

/*=============================================================================
	Structure of general informations about a MsNotes window.
=============================================================================*/
/* Style */
#define	S_EDIT		0x0001	/* Interactive window 			*/
#define S_VAR_SIZE	0x0002	/* The window can be sized.		*/
#define S_BORDER	0x0004	/* Border						*/
#define S_TITLE		0x0008	/* Caption bar and border		*/
#define S_VSCROLL	0x0010	/* Scroll bar vertical			*/
#define S_HSCROLL	0x0020	/* Scroll bar horizontal		*/
#define S_MENU		0x0040	/* Menu							*/
#define S_MINIMIZE	0x0080	/* Minimize button				*/
#define S_MAXIMIZE	0x0100	/* Maximize button				*/
#define S_STATUS	0x0200	/* Status bar					*/
#define S_CHILD		0x0400	/* Child window					*/

#define S_VHSCROLL	((S_VSCROLL|S_HSCROLL))
#define S_DEFAULT	((S_TITLE|S_VHSCROLL|S_VAR_SIZE|S_EDIT|S_MENU|S_STATUS ))
#define S_CANNOTIFY	((S_TITLE|S_VHSCROLL|S_VAR_SIZE|S_EDIT ))

/* Macros to test style */
#define IsEdit(s)		((s & S_EDIT))
#define IsVarSize(s)	((s & S_VAR_SIZE))
#define IsBorder(s)		((s & S_BORDER))
#define IsTitle(s)		((s & S_TITLE))
#define IsVscroll(s)	((s & S_VSCROLL))
#define IsHscroll(s)	((s & S_HSCROLL))
#define IsMenu(s)		((s & S_MENU))
#define IsStatusBar(s)	((s & S_STATUS))
#define IsMinimize(s)	((s & S_MINIMIZE))
#define IsMaximize(s)	((s & S_MAXIMIZE))
#define IsChild(s)		((s & S_CHILD))
#define IsCanNotify(s)	((s & S_CANNOTIFY))

#define N_MAXSTAFF	255						/* Number max of staffs  */

typedef char FAR *TitlePtr;
typedef  void * InfosPtr;
typedef struct
{
	Byte	NbrStaff;	/* Number  of staff in the internal array			*/
	Byte	LenTitle;	/* Lenght of title.									*/
	Word	Style;		/* Style											*/
	short	xPos;		/* Position x of right edge.						*/
	short	yPos;		/* Position y of the top edge.						*/
	short	Width;		/* Width.											*/
	short	Height;		/* Height.											*/
	Byte	Numerator;	/* Numerator of Time Signature .					*/
	Byte	Denominator;/* Denominator of Time Signature					*/
	Byte	iTone;		/* Key signature.									*/
	Word	TimePPQN;	/* Time base for date and duration.					*/
	Byte	Resolution;	/* Value of the resolution in fraction of a whole.	*/
	Byte	Flags;		/* Flags: Grid on/off.								*/
	Word	BarBBU;		/* Bar date (0 based) of BBU pointer on left edge	*/
	Word	BeatBBU;	/* Beat date (0 based) of BBU pointer on left edge	*/
	Byte	StaffUp;	/* Current Staff number (0 based) on top of window.	*/
	Byte	NbrMaxStaff;/* Number maximun of staff to display.				*/
	Byte	NbrMaxBar;	/* Number maximum of bar to display.				*/
}MsNotesInfos, * FAR MsNotesInfosPtr;

/*=============================================================================
	Structure of  informations about a staff.
=============================================================================*/
/*-- Values of clef staff (CLEF_STAFF) --------------------------------------*/

#define	BASS_OCT_DWN_CLEF	0	/* Clef  Fa 3,  line 4	*/
#define	BASS_CLEF			1	/* Clef  Fa 4,  line 4	*/
#define	BARITON_CLEF		2	/* Clef  Fa 4,  line 3	*/
#define	TENOR_CLEF			3	/* Clef  Do 5,  line 4	*/
#define	ALTO_CLEF			4	/* Clef  Do 5,  line 3	*/
#define	MEZZO_SOPRANO_CLEF	5	/* Clef  Do 5,  line 2	*/
#define	SOPRANO_CLEF		6	/* Clef  Do 5,  line 1	*/
#define	TREBLE_CLEF			7	/* Clef  Sol 5, line 2	*/
#define	TREBLE_OCT_DWN_CLEF	8	/* Clef  Sol 4, line 2	*/
#define	TREBLE_OCT_UP_CLEF	9	/* Clef  Sol 6, line 2	*/
#define	TREBLE_BASS_CLEF	10	/* Clef  Sol 5, line 2  */


#define NAMESIZE	12	/* Size of buffer name */

/*----------------------------------------------------------------------------
	Values of the staff flags infos
	Each bit of infos value is a flag. The description of the flags follow.
-----------------------------------------------------------------------------*/
#define HIDE_LINE_F	0x01	/* Hide height zone line control				*/
#define IsHideLine(f)		(( f & HIDE_LINE_F ))
#define SetHideLine(f)		( f |= HIDE_LINE_F  )
#define ResetHideLine(f)	( f &= ~HIDE_LINE_F )

#define NBR_PART 4				/* maximum parts number per staff		*/

/*----------------------------------------------------------------------------
  Part informations for polyphonic staff
-----------------------------------------------------------------------------*/
// Description of Part informations
#define PART_ENABLED_F	0x01	/* The part is enabled					*/
#define STEM_F			0x02	/* Stemming is up						*/

// Retourne True si la partie est autoris�e.
#define IsPartEnabled(f)	(( f & PART_ENABLED_F ))
#define SetPart(f)			( f |= PART_ENABLED_F)
#define ResetPart(f)		( f &= ~PART_ENABLED_F)

// Retourne True si les tiges sont vers le haut.
#define IsStemUp(f)			(( f & STEM_F ))
#define SetStemUp(f)		( f |= STEM_F)
#define ResetStemUp(f)		( f &= ~STEM_F)


typedef struct
{
	Byte 	TrkNum;		/* Track number for this part					*/ 
	Byte	Port;		/* Number of Midi Port used to hear the  notes.	*/
	Byte	Channel;	/* Number of Midi channel to hear the notes.	*/
	Byte	Flags;		/* Flags: PART_ENABLED_F, STEM_F				*/
}PartInfos, FAR *PartInfosPtr;  
typedef  PartInfos TabParts[NBR_PART];		/* Table of parts			*/

// Description of score informations
typedef struct
{
	MidiSeqPtr Score;	/* Score sequence */
	Word TimePPQN;		/* Time division PPQN */
	Byte Format;		/* MidiFile format */
}ScoreInfos, FAR * ScoreInfosPtr;


typedef struct
{
	char	Name[NAMESIZE];	/* Name of the staff.							*/
	MidiSeqPtr	Seq;	/* S�quence MidiShare for the staff .				*/
	Byte	iClef;		/* Clef identifier									*/
	Byte	SplitPitch;	/* Split pitch for TREBLE/BASS staves				*/
	Byte	Flags;		/* Flags: HIDE_LINE_F								*/
	Word	Height;		/* Height of the display zone for the port�e.		*/
	TabParts TabParts;
}StaffInfos, * FAR StaffInfosPtr;

typedef union 
{
	StaffInfos Staff;
	ScoreInfos Score;
}StaffScore, * FAR StaffScorePtr;

typedef  hMsNotes * FAR PtrhMsNotes;		/* Pointer on HMSNOTES		*/

/*=============================================================================
  The API functions
=============================================================================*/
/*-----------------------------------------------------------------------------
	creation - destruction of a  MsNotes window.
-----------------------------------------------------------------------------*/
/* creation */
Byte	MSNOTESAPI CreateMsNotes(
					hMsParent	hMsParent,		/* Handle of parent			*/
					PtrhMsNotes PtrhMsNotes,	/* Pointer on Window handle */
					TitlePtr	Title,				/* Title of the window.	*/
					Word	Style,					/* Style of window		*/
					Word	xPos,				/* Position x of topleft 	*/
					Word	yPos,				/* Position y of topleft	*/
					Word	Width,					/* Width.				*/
					Word	Height,					/* Height.				*/
					MsNotesInfosPtr MsNotesInfos,	/* General Infos		*/
					StaffScorePtr StaffScore,		/* Staff Infos or Score	*/
					Byte NbrStaff					/* Number of StaffInfos	*/ 
													/* 0 if Score			*/
					);

/*  destruction */
Byte	MSNOTESAPI DestroyMsNotes(
				hMsNotes hMsNotes			/* Handle of MsNotes window	 */
				);

/*----------------------------------------------------------------------------
	Getting and setting general informations about a MsNotes window.
-----------------------------------------------------------------------------*/
/* Following are codes identifiers for window and staff informations:InfosId */
enum 
{	/* codes identifiers for window informations */
	LEN_TITLE_MSN = 0,	/* Number of byte of title							*/
	TITLE_MSN ,		/* Window title										*/
	STYLE_MSN,		/* style											*/
	XY_MSN,			/* Coordinate of the upper-left corner  X et Y	(Notify) */
	SIZE_MSN,		/* Height and width								(Notify) */
	NUM_MSN,		/* Numerator of Time Signature	 (Notify)				 */
	DENO_MSN,		/* Denominator of Time Signature (Notify)				 */
	KEY_SIGN_MSN,	/* Tonality (Notify)									 */
	SIGN_MSN,		/* Numerator, denominator, and tonality					 */
	PPQN_MSN,		/* Time division in Part Per Quarter Note				 */
	RES_MSN	,		/* Resolution for displayed note duration (Notify)		 */									
	FLAGS_MSN,		/* Infos are flags described in the next section (Notify)*/
	GUIDE_DATE_MSN,	/* Date of the cursor guide								 */
	BBU_MSN,		/* BBU date under le left edge of the window (Notify)	 */
	STAFFUP_MSN,	/* Index of staff at the top of window	(Notify)		 */
	NBR_STAFF_MSN,	/* Number of staff										 */
	MAX_STAFF_MSN,	/* Number max of staff to display						 */
	MAX_BAR_MSN,	/* Number max of bar to display							 */
	INFOS_MSN,		/* All the window informations							 */
 	
	/* Codes identifiers for staff informations */
	NAME_STAFF,		/* Name of staff or instrument (Notify)			*/
	SEQ_STAFF,		/* Sequence MidiShare (Notify)					*/							
	CLEF_STAFF,		/* Clef in the staff header	(Notify)			*/
	H_STAFF,		/* Height of staff zone	(Notify)				*/
	PORT_STAFF,		/* Midi port used to hear note	(Notify)		*/
	CHAN_STAFF,		/* Midi channel used to hear note (Notify)		*/	
	INFOS_STAFF,	/* All the staff informations					*/
	
	/* Notify code only */
	N_INSERT_STAFF,	/* Insertion of a new staff						*/
	N_REMOVE_STAFF,	/* Removing a staff								*/
	N_MOVE_STAFF,	/* Changing the position of a staff				*/
	N_PLAY_EV_STAFF,/* Play the specified Event						*/
	N_CLOSE_MSN,	/* The user close the MsNotes Window			*/

	/* Score code */
	SCORE_STAFF,	/* A staff score 					*/
	SCORE_MSN,		/* A window score 					*/
};

/*----------------------------------------------------------------------------
	Values of the flags infos FLAGS_MSN.
	Each bit of infos value is a flag. The description of the flags follow.
-----------------------------------------------------------------------------*/
/* The flag GRID_DATE is used for placement of note at date multiples
 of the duration */
#define GRID_DATE	0x01	/* Grid to place note.			*/
/* The flag GUIDE_DATE  enable a cursor to be guided for reading the staff */
#define GUIDE_READER	0x02	/* Guide to choose the date.	*/

#define IsGridDate(f)		((f & GRID_DATE))
#define SetGridDate(f)		( f |= GRID_DATE )
#define ResetGridDate(f)	( f &= ~GRID_DATE )
#define IsGuideReader(f)	((f & GUIDE_READER))
#define SetGuideReader(f)	( f |= GUIDE_READER )
#define ResetGuideReader(f)	( f &= ~GUIDE_READER )

/* Getting informations */
Byte 	MSNOTESAPI GetMsNotesInfos( 
					hMsNotes	hMsNotes,	/* Handle of MsNotes window	*/
					Byte		InfosId,	/* Id of infos to retrieve	*/ 
					InfosPtr	Infos		/* Pointer on infos to get	*/
					);

#define BG_ERASE_F	0x1				/* Erase the background of window	*/
#define BUILD_F		0x2						/* Build the symbols tables.*/
#define REBUILDALL	(BG_ERASE_F|BUILD_F)	/* Update Window			*/

/* Setting informations */
Byte 	MSNOTESAPI SetMsNotesInfos( 
					hMsNotes	hMsNotes,	/* Handle of MsNotes window	*/
					Byte		InfosId,	/* Id of infos to set		*/ 
					long		Infos,		/* Value to set				*/
					Byte		Flags		/* Update Window			*/
					);

/*-----------------------------------------------------------------------------
	Application notify proc�dure 
-----------------------------------------------------------------------------*/
typedef Byte (MSNOTESALARMAPI *ApplNotifyPtr) (
					hMsNotes	hMsNotes,	/* Handle of MsNotes window	*/
					Byte		StaffId,	/* Id of the changed Staff	*/
					Byte		InfosId,	/* Id of the changed infos	*/ 
					long		Infos		/* Value of the infos		*/
					);

/*----------------------------------------------------------------------------
	Setting application notify  procedure.
-----------------------------------------------------------------------------*/
Byte	MSNOTESAPI SetMsNotesApplNotify (
				hMsNotes hMsNotes,			/* Handle of MsNotes window	*/
				ApplNotifyPtr ApplNotify	/* Pointer to notify routine */
				);

/*----------------------------------------------------------------------------
	Insertion  , removing and moving staff on a MsNotes window.
-----------------------------------------------------------------------------*/
/* Insertion of staff: can be undo   */
Byte 	MSNOTESAPI InsertStaff( 
					hMsNotes		hMsNotes,	/* Handle of MsNotes window	*/
					StaffInfosPtr	Infos,		/* Staff infos to insert	*/
					Byte			StaffPos,	/* Position (0 based)		*/
					Byte			Flags		/* Update Window			*/
					);

/* Removing of staff: can be undo  */
Byte 	MSNOTESAPI RemoveStaff( 
					hMsNotes	hMsNotes,	/* Handle of MsNotes window	*/
					Byte		StaffPos,	/* Position (0 based)		*/
					Byte		Flags		/* Update Window			*/
					);

/* Moving of staff: can be undo */
Byte 	MSNOTESAPI MoveStaff( 
					hMsNotes	hMsNotes,	/* Handle of MsNotes window		*/
					Byte		CurPos,		/* Current position (0 based)	*/
					Byte		NewPos,		/* New position (0 based)		*/
					Byte		Flags		/* Update Window				*/
					);
/* Insert a score: cannot be undo */
Byte 	MSNOTESAPI InsertScore( 
					hMsNotes		hMsNotes,	/* Handle of MsNotes window	*/
					ScoreInfosPtr	Infos,		/* Score infos to insert	*/
					Byte			StaffPos,	/* Position (0 based)		*/
					Byte			Flags		/* Update Window			*/
					);

/*----------------------------------------------------------------------------
	Getting and setting staff informations .
-----------------------------------------------------------------------------*/
/* Getting informations */
Byte	MSNOTESAPI GetStaffInfos( 
					hMsNotes	hMsNotes,	/* Handle of MsNotes window	*/
					Byte		StaffPos,	/* Position of the staff	*/
					Byte		InfosId,	/* Id of infos to retrieve	*/ 
					InfosPtr	Infos		/* Pointer on infos to get	*/
					);

/* Setting informations : can be undo */
Byte 	MSNOTESAPI SetStaffInfos( 
					hMsNotes	hMsNotes,	/* Handle of MsNotes window	*/
					Byte		StaffPos,	/* Position of the staff	*/
					Byte		InfosId,	/* Id of infos to set		*/ 
					long		Infos,		/* Value to set				*/
					Byte		Flags		/* Update Window			*/
					);

/*----------------------------------------------------------------------------
	Undo the last Insertion,Removing, Moving of staff  or 
	Setting staff informations .
-----------------------------------------------------------------------------*/
Byte 	MSNOTESAPI UndoLastStaffOp(
					hMsNotes	hMsNotes	/* Handle of MsNotes window	*/
					);
					
/*----------------------------------------------------------------------------
	Getting Status informations.
-----------------------------------------------------------------------------*/
/*-----------------------------------------------------------------------------
 Code errors: MSNerror
-----------------------------------------------------------------------------*/
#define		MSNok				0	/* Successful operation.				*/
/* Errors returned by API system calls */
#define		MSNerrOS			1	/* Operating System errror.				*/
/* Invalid parameters */
#define		MSNerrBadHandle		2	/* Handle of window is invalid.			*/
#define		MSNerrBadInfos		3	/* Infos value is invalid.				*/
#define		MSNerrBadIdInfos	4	/* Code identifier is invald.			*/
#define		MSNerrBadOp			5	/* Operation (Set or Get) is invalid	*/
#define		MSNerrBadPos		6	/* Staff index is  invalid.				*/
/* Tables full */
#define		TABEVSYM_FULL		7	/* TabEvSym	table		*/	
#define		SYMTAB_FULL			8	/* SymTab	table		*/
#define		TABSYSDIR_FULL		9	/* TabSysDir table		*/
/* Invalid events in the sequence.*/
#define		KEYON_OVERLAP		10	/* 2 overlapped KeyOn events  with		*/
									/* same pitch.							*/
#define		KEYOFF_MISS			11	/* KeyOn event without a KeyOff event	*/

/*----------------------------------------------------------------------------
	Getting version informations.
-----------------------------------------------------------------------------*/
typedef struct
{
	short MShareVersion;
	short MsNotesVersion;
}VersionInfos;


VersionInfos  MSNOTESAPI GetMsNotesVersion( void );

/*---------------------------------------------------------------------------*/
#endif  /*  __MSNOTES_H__ */

