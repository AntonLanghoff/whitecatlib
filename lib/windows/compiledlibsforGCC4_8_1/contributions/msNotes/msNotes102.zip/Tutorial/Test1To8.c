/******************************************************************************
 Test1To8.c
 Email: Jean-Jacques.CERESA@enac.fr
******************************************************************************/

/******************************************************************************
				*** WELCOME TO THE MSNOTES TUTORIAL ***

This tutorial is is intended for the developers who wish to understand how a 
MsNotes window works and learn the API of the MsNotes library.
For each API functions, the tutorial execute a serie of tests step by step.
In order for you to learn the API functions and look at the source code, you
must print the 'TestXXToYY.c' file before starting.
These files contents the series of tests executed by the tutorial program.

Try the following method for learning about a test:
	1)Read the description of the test in the window tutorial and in the 
	'TestXXToYY.c' file.
	2)Read the source code of the test in the 'TestXXToYY.c.c' file.
	3)Try to anticipate about the result before executing.
	4)Execute the step and read the result displayed in the 'Result'
	  window of the tutorial program.
	5)Verify the result and what you have expected at (3).

******************************************************************************/

#define STRICT
#define __Windows__		// Application Windows 
#include "Tutorial.h"


/*=============================================================================
	The following tests create MsNotes windows with various style by using
	CreateMsNotes() and DestroyMsNotes() APIs. 
=============================================================================*/

Byte CreateWindowStaff(Word Style , Word Height, MsNotesInfosPtr WndInfos);

/*----------------------------------------------------------------------------
Test 1: step 1/1: 

This test create a simple MsNotes Windows with the following behavior:
	- The style is for display only ( editing is disabled ).
	- The staff information table has one staff, filled with some notes
	  before creation.
	- The windows informations ( MsNotesInfos ) are those by default:
		Meter key: 4/4.
		Key signature: C.
		Resolution: thirty second ( 1/32 of a whole).
		Bar:Beat:Unit pointer at 1:1:0.
		Number maximun of staff to display: 1.
		Number maximun of bar to display: 1.

If the result is successful, you can see a small MsNotes window at the top of
the tutorial dialog box.
Try to register a notifying callback procedure by pressing the 'Notify' check 
box below and see the result in this window.
-----------------------------------------------------------------------------*/
byte Test1_Step1_1(void)
{
	/* Setting the style */
	Word Style = 0;

	/* Setting the height */
	Word Height = DEFAULT_H-1 ;

	/* Creation is performed by CreateWindow1Staff */ 
	return CreateWindowStaff(Style, Height, Null);
}


/*----------------------------------------------------------------------------
Test 2: step 1/1: 

This test create a window. It do the same work than Test 1 but with a light
different style window. 

	- The style is: S_BORDER ( editing is disabled ).

If the result is successful, you can see a small MsNotes window (above the
tutorial dialog box) with a thin border.
Try to register a notifying callback procedure by pressing the 'Notify' check 
box below and see the result in this window.
-----------------------------------------------------------------------------*/
byte Test2_Step1_1(void)
{
	/* Setting the style */
	Word Style = S_BORDER;

	/* Setting the height */
	Word HeightBorderSimple = GetSystemMetrics(SM_CYBORDER);
	Word Height = DEFAULT_H-1 + 2 * HeightBorderSimple;

	/* Creation is performed by CreateWindow1Staff */ 
	return CreateWindowStaff(Style, Height, Null);
}

/*----------------------------------------------------------------------------
Test 3: step 1/1: 

This test create a window. It do the same work than Test 2 , with a light
different style window, a status bar is to be added.  

	- The style is: S_BORDER + S_STATUS ( editing is disabled ).

If the result is successful, you can see a small MsNotes window (above the
tutorial dialog box) with a thin border and a status bar.
When the user move the mouse over the note, the following are display in the
status bar:
	The Bar Beat Unit values of the internal BBU pointer.
	The pitch of the note pointed by the mouse .
Try to register a notifying callback procedure by pressing the 'Notify' check 
box below and see the result in this window.
-----------------------------------------------------------------------------*/
byte Test3_Step1_1(void)
{
	/* Setting the style */
	Word Style = S_BORDER | S_STATUS;

	/* Setting the height */
	Word HeightBorderSimple = GetSystemMetrics(SM_CYBORDER);
	Word Height = DEFAULT_H-1 + 2 * HeightBorderSimple + HEIGHTSBAR; 

	/* Creation is performed by CreateWindow1Staff */ 
	return CreateWindowStaff(Style, Height, Null);
}

/*----------------------------------------------------------------------------
Test 4: step 1/1: 

This test create a window. It do the same work than Test 3 , with a light
different style window, a title bar is to be added.  

	- The style is: S_BORDER + S_STATUS + S_TITLE ( editing is disabled ).

If the result is successful, you can see a small MsNotes window (above the
tutorial dialog box) with a 3D border a status bar and a caption bar.
Now the window can bee moved by the user. So the window is able to notify the
tutorial application.
Try to register a notifying callback procedure by pressing the 'Notify' check 
box below and see the result in this window.
Try to move the MsNotes window and seen the result in the lower control window.
-----------------------------------------------------------------------------*/
byte Test4_Step1_1(void)
{
	/* Setting the style */
	Word Style = S_BORDER | S_STATUS | S_TITLE;
	
	/* Setting the height */
	Word HeightBorderSimple = GetSystemMetrics(SM_CYBORDER);
	Word HeightBorder3D = GetSystemMetrics(SM_CYEDGE);
	Word HeightTitle = GetSystemMetrics(SM_CYCAPTION);
	Word Height = DEFAULT_H-1 + 2 * HeightBorderSimple + HEIGHTSBAR +
				HeightTitle +	2 * HeightBorder3D;

	/* Creation is performed by CreateWindow1Staff */ 
	return CreateWindowStaff(Style, Height, Null);
}

/*----------------------------------------------------------------------------
Test 5: step 1/1: 

This test create a window. It do the same work than Test 4 , with a light
different style, the window can be sized.  

	- The style is: S_BORDER + S_STATUS + S_TITLE + S_VAR_SIZE
	- (Editing is disabled).

If the result is successful, you can see a small MsNotes window (above the
tutorial dialog box) with a sizable window border a status bar and a caption
bar. Now the window can bee sized by the user. So the window is able to notify
the tutorial application.
Try to register a notifying callback procedure by pressing the 'Notify' check 
box below and see the result in this window.
Try to size the MsNotes window and seen the result in the lower control window.
-----------------------------------------------------------------------------*/
byte Test5_Step1_1(void)
{
	/* Setting the style */
	Word Style = S_BORDER | S_STATUS | S_TITLE | S_VAR_SIZE ;
	
	/* Setting the height */
	Word HeightBorderVarSize = GetSystemMetrics(SM_CYSIZEFRAME);
	Word HeightTitle = GetSystemMetrics(SM_CYCAPTION);
	Word Height = DEFAULT_H-1  + HEIGHTSBAR +
				HeightTitle +	2 * HeightBorderVarSize;

	/* Creation is performed by CreateWindow1Staff */ 
	return CreateWindowStaff(Style, Height, Null);
}

/*----------------------------------------------------------------------------
Test 6: step 1/1: 

This test create a window. It do the same work than Test 5 , with a light
different style, an horizontal scroll bar is to be added.  

	- The style is: S_BORDER + S_STATUS + S_TITLE + S_VAR_SIZE + S_HSCROLL
	- (Editing is disabled).

When you use the horizontal scroll bar the BBU pointer (Bar Beat Unit) display
the new time at the left of the window. The window has the default behavior so
you can see only one bar and only one staff.

If the result is successful, you can see a small MsNotes window (above the
tutorial dialog box) with an horizontal scroll bar, a sizable window border
a status bar and a caption bar. Now the date time staff can bee scrolled by
the user. So the window is able to notify the tutorial application.
Try to register a notifying callback procedure by pressing the 'Notify' check 
box below and see the result in this window.
Try to use the horizontal scroll bar and seen the result in the lower control
window.
-----------------------------------------------------------------------------*/
byte Test6_Step1_1(void)
{
	/* Setting the style */
	Word Style = S_BORDER | S_STATUS | S_TITLE | S_VAR_SIZE | S_HSCROLL;
	
	/* Setting the height */
	Word HeightBorderVarSize = GetSystemMetrics(SM_CYSIZEFRAME);
	Word HeightTitle = GetSystemMetrics(SM_CYCAPTION);
	Word Thumb = GetSystemMetrics(SM_CXHTHUMB);
	Word Height = DEFAULT_H-1  + HEIGHTSBAR +
				HeightTitle +	2 * HeightBorderVarSize + Thumb;

	/* Creation is performed by CreateWindow1Staff */ 
	return CreateWindowStaff(Style, Height, Null);
}

/*----------------------------------------------------------------------------
Test 7: step 1/1: 

This test create a window. It do the same work than Test 6 , with a
different style, a vertical scroll bar is to be added and the edition of notes
is now enabled.  

	- The style is: S_BORDER + S_STATUS + S_TITLE + S_VAR_SIZE + S_HSCROLL +
	  S_VSCROLL + S_EDIT.

With the S_EDIT style, the window show a tool bar a the top to the client area.
Now the user is allowed to use the full interactives features of the window.
To learn about the edition capabilities, please refer to the user manual and 
try to use edition commands described in this manual.

The vertical scroll bar is show only when necessary.With one staff in the
internal StaffInfos table, the vertical scroll bar is hidden.

If the result is successful, you can see a small MsNotes window (above the
tutorial dialog box) with a tool bar, a vertical and horizontal scroll bar,
a sizable window border, a status bar and a caption bar.
So the window is able to notify the tutorial application.
Try to register a notifying callback procedure by pressing the 'Notify' check 
box below and see the result in this window.
-----------------------------------------------------------------------------*/
byte Test7_Step1_1(void)
{
	/* Setting the style */
	Word Style = S_BORDER | S_STATUS | S_TITLE | S_VAR_SIZE | S_HSCROLL |
				 S_VSCROLL | S_EDIT;
	
	/* Setting the height */
	Word HeightBorderVarSize = GetSystemMetrics(SM_CYSIZEFRAME);
	Word HeightTitle = GetSystemMetrics(SM_CYCAPTION);
	Word Thumb = GetSystemMetrics(SM_CXHTHUMB);
	Word Height = DEFAULT_H-1  + HEIGHTSBAR +
				HeightTitle +	2 * HeightBorderVarSize + Thumb + HEIGHTTBAR;

	/* Creation is performed by CreateWindow1Staff */ 
	return CreateWindowStaff(Style, Height, Null);
}

/*----------------------------------------------------------------------------
 These are the window informations used by the next test.
 The informations are the same then default except for NbrMaxStaff and
 NbrMaxBar.
----------------------------------------------------------------------------*/
MsNotesInfos WndInfos={	// Window informations
	0,		/* WndInfos.NbrStaff=0,		Number  of staff					*/
	0,		/* WndInfos.LenTitle = 0,	lenght of title.					*/
	0,		/* WndInfos.Style = 0,		style.								*/
	0,		/* WndInfos.xPos = 0,		position x of right edge.			*/
	0,		/* WndInfos.yPos = 0,		position y of the top edge.			*/
	0,		/* WndInfos.Width = 0,		width.								*/
	0,		/* WndInfos.Height = 0,		height.								*/
	4,		/* WndInfos.Numerator = 4,	numerator of Time Signature .		*/
	4,		/* WndInfos.Denominator=4,	denominator of Time Signature		*/
	KEY_C,	/* WndInfos.iTone = KEY_C,	key signature.						*/
	96,		/* WndInfos.TimePPQN= 96,	time base for date and duration.	*/
	32,		/* WndInfos.Resolution=32,	value of the resolution.			*/
	0,		/* WndInfos.Flags = 0,		flags: no GRID_DATE, no GUIDE_READER*/
	0,		/* WndInfos.BarBBU=0,		bar date (0 based) of BBU pointer	*/
	0,		/* WndInfos.BeatBBU=0,		beat date (0 based) of BBU pointer	*/
	0,		/* WndInfos.StaffUp=0,		current Staff number (0 based).		*/
	3,		/* WndInfos.NbrMaxStaff=3,	number maximun of staff to display.	*/
	4		/* WndInfos.NbrMaxBar=4,	number maximum of bar to display.	*/
};

/*----------------------------------------------------------------------------
Test 8: step 1/1: 

This test create a window. It do the same work than Test 7 , with new window
informations ( MsNotesInfos ). Now this window can display 3 staffs and 4
bars by staff.

If the result is successful, you can see a small MsNotes window (above the
tutorial dialog box) with a tool bar, a vertical and horizontal scroll bar,
a sizable window border, a status bar and a caption bar.
So the window is able to notify the tutorial application.
Try to register a notifying callback procedure by pressing the 'Notify' check 
box below and see the result in this window.
-----------------------------------------------------------------------------*/
byte Test8_Step1_1(void)
{
	/* Setting the style */
	Word Style = S_DEFAULT;
	
	/* Setting the height */
	Word HeightBorderVarSize = GetSystemMetrics(SM_CYSIZEFRAME);
	Word HeightTitle = GetSystemMetrics(SM_CYCAPTION);
	Word Thumb = GetSystemMetrics(SM_CXHTHUMB);
	Word Height = DEFAULT_H-1  + HEIGHTSBAR +
				HeightTitle +	2 * HeightBorderVarSize + Thumb + HEIGHTTBAR;

	/* Creation is performed by CreateWindow1Staff */ 
	/* The window informations set in the WndInfos */ 
	return CreateWindowStaff(Style, Height, &WndInfos);
}


/******************************************************************************
Creation a simple MsNotes Windows with the following behavior:
	- The style is the parameter.
	- The staff information table has one staff, filled with some notes
	  before creation.
	- The windows informations ( MsNotesInfos ) are those by default if 
	  WndInfos is false:
		Meter key: 4/4.
		Key signature: C.
		Resolution: thirty second ( 1/32 of a whole).
		Flags: no GRID_DATE , no GUIDE_READER.
		Bar:Beat:Unit pointer at 1:1:0.
		Number maximun of staff to display: 1.
		Number maximun of bar to display: 1.
Input parameters:	
		. Style ,Height  of the window to create.
		. WndInfos is the address of the window information. 
OutPut parameter
	The result code of the creation CreateMsNotes.
******************************************************************************/
Byte CreateWindowStaff(Word Style , Word Height, MsNotesInfosPtr WndInfos)
{
	Byte s;	// Status of operation
		
	StaffInfos	TrkTab[1];	// Staffs informations
	BYTE NbrStaff=1;		// The number of staffs in TrkTab
	/*-----------------------------------------------------------------------
	 Initialise StaffInfos table for Staff 0
	------------------------------------------------------------------------*/
	// Initialise 
	strncpy(TrkTab[0].Name,"Piano",NAMESIZE);	/* Name of the staff.		*/
	TrkTab[0].Name[NAMESIZE-1] ='\0';
	TrkTab[0].Seq=MidiNewSeq();		/* Sequence MidiShare.					*/
	TrkTab[0].iClef=TREBLE_CLEF;	/* Clef:TREBLE_CLEF						*/
	TrkTab[0].SplitPitch=gmP(C,5);	/* Default split pitch.					*/
	TrkTab[0].Flags = 0;			/* Do not hide height-zone line			*/
	TrkTab[0].Height=0;				/* Default height of the display zone.	*/
	TrkTab[0].TabParts[0].Port=PORT;/* Midi Port used to hear notes.		*/
	TrkTab[0].TabParts[0].Channel=0;/* Midi channel to hear the notes.		*/

	// Add some notes to the Staff 0 sequence
	TrkTab[0].TabParts[0].Flags =0;	/* Disable Part 0				*/
	TrkTab[0].TabParts[1].Flags =0; /* Disable Part 1				*/
	TrkTab[0].TabParts[2].Flags =0; /* Disable Part 2				*/
	TrkTab[0].TabParts[3].Flags =0; /* Disable Part 3				*/
	SetPart(TrkTab[0].TabParts[0].Flags); /* Enable Part 0			*/
	
	TrkTab[0].TabParts[0].TrkNum = 1;	/* Track number 1 for Part 0		*/
	AddNote(TrkTab[0].Seq,1,PORT,0,gmP(G,5), 0 ,48, 64);
	AddNote(TrkTab[0].Seq,1,PORT,0,gmP(B,5), 48,48, 96);
	AddNote(TrkTab[0].Seq,1,PORT,0,gmP(D,6), 48+48,3*48, 127);
	AddNote(TrkTab[0].Seq,1,PORT,0,gmP(B,5), 48+48+3*48,24, 80);
	AddNote(TrkTab[0].Seq,1,PORT,0,gmP(G,6), 48+48+3*48+24,48, 127);
	AddNote(TrkTab[0].Seq,1,PORT,0,gmP(C,6), 48+48+3*48+24+48,48, 80);

	// Add Text 
	{
		MidiEvPtr Ev= NewEvText(0,1, "G chord");
		MidiAddSeq(TrkTab[0].Seq,Ev);
	}
	/*-----------------------------------------------------------------------
	 Create a MSNotes Windows 
	------------------------------------------------------------------------*/
	/* Destroy any window if already exist */
	DestroyPendingMsNotesWindow();
	/* Create the new window */
	s = CreateMsNotes(	
						ghwndDlg,			/* Handle of parent				*/
						&hWndMsNotes,		/* address of handle to return	*/
						"msNotes window",	/* Title						*/
						Style,				/* Style						*/
						329,10,				/* Position X and Y				*/
						364,				/* Width						*/
						Height,				/* Height						*/
						WndInfos,			/* MsNotesInfos					*/
						(StaffScorePtr)TrkTab,		/* StaffInfos table		*/
						NbrStaff);			/* Number of Staff				*/
	/*-----------------------------------------------------------------------
	 Get the result and prepare the result message 
	------------------------------------------------------------------------*/
	// Prepare the result message
	wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Creation, status:%d, %s",s,TabErrMsg[s]);
	iResBuff = strlen(ResultBuff);
	return s;
}

