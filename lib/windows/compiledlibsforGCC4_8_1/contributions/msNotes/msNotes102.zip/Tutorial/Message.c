/******************************************************************************
 Message.c
 Email: Jean-Jacques.CERESA@enac.fr
******************************************************************************/

#define STRICT
#define __Windows__		// Application Windows 
#include "Tutorial.h"

/*----------------------------------------------------------------------------
 Table of report message indexed by the status returned by MsNotes API.
	MSNok				0	// Successful operation.
 Errors returned by API system calls 
	MSNerrOS			1	// Operating System errror.
 Invalid parameters 
	MSNerrBadHandle		2	// Handle of window is invalid.
	MSNerrBadInfos		3	// Infos value is invalid.
	MSNerrBadIdInfos	4	// Code identifier is invald.
	MSNerrBadOp			5	// Operation reading or writing are invalid.
	MSNerrBadPos		6	// Staff index is  invalid.
 Tables full 
	TABEVSYM_FULL		7	// TabEvSym	table		
	SYMTAB_FULL			8	// SymTab	table	
	TABSYSDIR_FULL		9	// TabSysDir table	
 Invalid events in the sequence.
	KEYON_OVERLAP		10	// 2 overlapped KeyOn events  with
							// same pitch.
	KEYOFF_MISS			11	// KeyOn event without a KeyOff event

-----------------------------------------------------------------------------*/
char * TabErrMsg[]={
	"MSNok, successful operation.",
	"MSNerrOS, Operating System errror.",
	"MSNerrBadHandle, handle of window is invalid.",
	"MSNerrBadInfos, infos value is invalid.",
	"MSNerrBadIdInfos, code identifier is invald.",
	"MSNerrBadOp, operation is invalid.",
	"MSNerrBadPos, staff index is  invalid.",
	"TABEVSYM_FULL, error on table TABEVSYM.",
	"SYMTAB_FULL, error on table SYMTAB.",
	"TABSYSDIR_FULL, error on table TABSYSDIR.",
	"KEYON_OVERLAP, notes overlap",
	"KEYOFF_MISS, KeyOn without KeyOff"
};

/*----------------------------------------------------------------------------
 Table of name code identifier indexed by the code identifier.
-----------------------------------------------------------------------------*/
char * TabNameIdInfos[]={
	"LEN_TITLE_MSN" ,	/* Number of byte of title							*/
	"TITLE_MSN" ,		/* Window title										*/
	"STYLE_MSN",		/* style											*/
	"XY_MSN",			/* Coordinate of the upper-left corner  X et Y		*/
	"SIZE_MSN",			/* Height and width									*/
	"NUM_MSN",			/* Numerator of Time Signature						*/
	"DENO_MSN",			/* Denominator of Time Signature					*/
	"KEY_SIGN_MSN",		/* Tonality											*/
	"SIGN_MSN",			/* Numerator, denominator, and tonality				*/
	"PPQN_MSN",			/* Time division in Part Per Quarter Note			*/
	"RES_MSN",			/* Resolution for displayed note duration			*/									
	"FLAGS_MSN",		/* Infos are flags described in the next section    */
	"GUIDE_DATE_MSN",	/* Date of the cursor guide							*/
	"BBU_MSN",			/* BBU date under le left edge of the window		*/
	"STAFFUP_MSN",		/* Index of staff at the top of window				*/
	"NBR_STAFF_MSN",	/* Number of staff									*/
	"MAX_STAFF_MSN",	/* Number max of staff to display					*/
	"MAX_BAR_MSN",		/* Number max of bar to display						*/
	"INFOS_MSN",		/* All the windows informations						*/
 	
	/* Codes identifiers for staff informations */
	"NAME_STAFF",		/* Name of staff or instrument					*/
	"SEQ_STAFF",		/* Sequence MidiShare							*/							
	"CLEF_STAFF",		/* Clef in the staff header						*/
	"H_STAFF",			/* Height of staff zone							*/
	"PORT_STAFF",		/* Midi port used to hear note					*/
	"CHAN_STAFF",		/* Midi channel used to hear note				*/	
	"INFOS_STAFF",		/* All the staff informations					*/
	
	/* Notify code only */
	"N_INSERT_STAFF",	/* Insertion of a new staff						*/
	"N_REMOVE_STAFF",	/* Removing a staff								*/
	"N_MOVE_STAFF",		/* Changing the position of a staff				*/
	"N_PLAY_EV_STAFF",	/* Play the specified Event						*/
	"N_CLOSE_MSN",		/* The user close the MsNotes window			*/

	/* Codes identifiers for score  */
	"SCORE_STAFF",		/* A staff score 					*/
	"SCORE_MSN"			/* A window score 					*/

};


/*----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
void AddNote(MidiSeqPtr	Seq,
			 Byte RefNum, Byte Port, Byte Chan, Byte Pitch, long Date,
			 short Duration, Byte Vel)
{
	MidiEvPtr Ev;
	Ev = MidiNewEv (typeKeyOn);
	MidiSetRefNum(Ev, RefNum);
	MidiSetPort(Ev,Port);
	MidiSetChan(Ev,Chan);

	MidiSetDate ( Ev, Date);
	MidiSetField (Ev, 0, Pitch);
	MidiSetField (Ev, 1, Vel);
	MidiAddSeq(Seq,Ev);

	Ev = MidiNewEv (typeKeyOff);
	MidiSetRefNum(Ev, RefNum);
	MidiSetPort(Ev,Port);
	MidiSetChan(Ev,Chan);
	MidiSetDate ( Ev, Date + Duration);
	MidiSetField (Ev, 0, Pitch);
	MidiAddSeq(Seq,Ev);
}

/*----------------------------------------------------------------------------
 Creation et retour d'un Ev de type typeTextual � partir d'une chaine.
 Le texte contient le zero  de fin de cha�ne.
 Retourne Null si erreur d'allocation  m�moire MidiShare.
-----------------------------------------------------------------------------*/
MidiEvPtr NewEvText( long Date,Byte RefNum, char Text[] )
{
	MidiEvPtr Ev = 0;
	Byte i=0,t;
	if ( Text && (Ev = MidiNewEv(typeTextual)) )
	{
		MidiSetRefNum( Ev, RefNum );
		MidiSetDate ( Ev, Date );	// Date 
		do							// copie le texte dans Ev avec le zero
		{ t= Text[i++]; MidiAddField( Ev, t);} while (t); 
		if( i != (Byte)MidiCountFields(Ev))	{ MidiFreeEv ( Ev ) ; return 0;}
	}
	return Ev;
}

/*----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
void  DestroyPendingMsNotesWindow(void)
{
	Byte s;

	if (hWndMsNotes)
	{
		/* Destroy the window */
		s=DestroyMsNotes(hWndMsNotes); 
		hWndMsNotes = Null;
		
		/* Uncheck de 'Notify' check box, clear the window, disable window. */
		SendDlgItemMessage(ghwndDlg, IDC_CHECK_NOTIFY,BM_SETCHECK ,0,0);
		SetDlgItemText(ghwndDlg,IDC_EDIT_NOTIFY,""); // Clear the window
		EnNotifyWnd = False;

		/* Prepare the result message */
		wsprintf( &ResultBuff[iResBuff],"\r\n\t-Destroying, status:%d, %s",
										s,TabErrMsg[s]);
		iResBuff = strlen(ResultBuff);
	}
}

/*----------------------------------------------------------------------------
 
-----------------------------------------------------------------------------*/
char DescTest1_Step1_1[]="\
Test 1:step 1/1:\r\n\
-------------------------\r\n\
This test create a simple MsNotes Windows with the following behavior:\r\n\
	- The style is for display only ( editing is disabled ).\r\n\
	- The staff information table has one staff, filled with some notes \
before creation.\r\n\
	- The windows informations ( MsNotesInfos ) are those by default:\r\n\
		.Meter key: 4/4.\r\n\
		.Key signature: C.\r\n\
		.Resolution: thirty second ( 1/32 of a whole).\r\n\
		.Bar:Beat:Unit pointer at 1:1:0.\r\n\
		.Number maximun of staff to display: 1.\r\n\
		.Number maximun of bar to display: 1.\r\n\
If any MsNotes window already exist it is destroyed before creating the new \
one.\r\n\
Press the push button to execute and see the status in the result window";

/*---------------------------------------------------------------------------*/
char Res1_Step1_1[]="\
\r\n\
If the result is successful, you can see a small MsNotes window at the top of \
the tutorial dialog box.\r\n\
Try to register a notifying callback procedure by pressing the 'Notify' check \
box below and see the result in this window.";


/*---------------------------------------------------------------------------*/
char DescTest2_Step1_1[]="\
Test 2:step 1/1:\r\n\
-------------------------\r\n\
This test create a window. It do the same work than Test 1 but with a light \
different style window.\r\n\
	- The style is: S_BORDER ( editing is disabled ).\r\n\
Press the push button to execute and see the status in the result window";

/*---------------------------------------------------------------------------*/
char Res2_Step1_1[]="\
\r\n\
If the result is successful, you can see a small MsNotes window with a thin \
border at the top of the tutorial dialog box.\r\n\
Try to register a notifying callback procedure by pressing the 'Notify' check \
box below and see the result in this window.";

/*---------------------------------------------------------------------------*/
char DescTest3_Step1_1[]="\
Test 3:step 1/1:\r\n\
-------------------------\r\n\
This test create a window. It do the same work than Test 2 , with a light \
different style window, a status bar is to be added.\r\n\
	- The style is: S_BORDER + S_STATUS ( editing is disabled )\r\n\
Press the push button to execute and see the status in the result window";

/*---------------------------------------------------------------------------*/
char Res3_Step1_1[]="\
\r\n\
If the result is successful, you can see a small MsNotes window (above the \
tutorial dialog box) with a thin border and a status bar.\r\n\
When the user move the mouse over the note, the following are display in the \
status bar:\r\n\
	- The Bar Beat Unit values of the internal BBU pointer.\r\n\
	- The pitch of the note pointed by the mouse.\r\n\
Try to register a notifying callback procedure by pressing the 'Notify' check \
box below and see the result in this window.";

/*---------------------------------------------------------------------------*/
char DescTest4_Step1_1[]="\
Test 4:step 1/1:\r\n\
-------------------------\r\n\
This test create a window. It do the same work than Test 3 , with a light \
different style window, a title bar is to be added.\r\n\
	- The style is: S_BORDER + S_STATUS + S_TITLE ( editing is disabled ).\r\n\
Press the push button to execute and see the status in the result window.";

/*---------------------------------------------------------------------------*/
char Res4_Step1_1[]="\
\r\n\
If the result is successful, you can see a small MsNotes window (above the \
tutorial dialog box) with a 3D border a status bar and a caption bar.\r\n\
Now the window can bee moved by the user. So the window is able to notify the \
tutorial application.\r\n\
Try to register a notifying callback procedure by pressing the 'Notify' check \
box below and see the result in this window.\r\n\
Try to move the MsNotes window and seen the result in the lower control \
window.";

/*---------------------------------------------------------------------------*/
char DescTest5_Step1_1[]="\
Test 5:step 1/1:\r\n\
-------------------------\r\n\
This test create a window. It do the same work than Test 4 , with a light \
different style, the window can be sized.\r\n\
	- The style is: S_BORDER + S_STATUS + S_TITLE + S_VAR_SIZE.\r\n\
	- (Editing is disabled).\r\n\
Press the push button to execute and see the status in the result window.";

/*---------------------------------------------------------------------------*/
char Res5_Step1_1[]="\
\r\n\
If the result is successful, you can see a small MsNotes window (above the \
tutorial dialog box) with a sizable window border a status bar and a caption \
bar. Now the window can bee sized by the user. So the window is able to notify \
the tutorial application.\r\n\
Try to register a notifying callback procedure by pressing the 'Notify' check \
box below and see the result in this window.\r\n\
Try to size the MsNotes window and seen the result in the lower control \
window.";

/*---------------------------------------------------------------------------*/
char DescTest6_Step1_1[]="\
Test 6:step 1/1:\r\n\
-------------------------\r\n\
This test create a window. It do the same work than Test 5 , with a light \
different style, an horizontal scroll bar is to be added.\r\n\
	- The style is: S_BORDER + S_STATUS + S_TITLE + S_VAR_SIZE + S_HSCROLL.\r\n\
	- (Editing is disabled).\r\n\
When you use the horizontal scroll bar the BBU pointer (Bar Beat Unit) display \
the new time at the left of the window. The window has the default behavior so \
you can see only one bar and only one staff.\r\n\
Press the push button to execute and see the status in the result window.";

/*---------------------------------------------------------------------------*/
char Res6_Step1_1[]="\
\r\n\
If the result is successful, you can see a small MsNotes window (above the \
tutorial dialog box) with an horizontal scroll bar, a sizable window border \
a status bar and a caption bar. Now the date time staff can bee scrolled by \
the user. So the window is able to notify the tutorial application.\r\n\
Try to register a notifying callback procedure by pressing the 'Notify' check \
box below and see the result in this window.\r\n\
Try to use the horizontal scroll bar and seen the result in the lower control \
window.";

/*---------------------------------------------------------------------------*/
char DescTest7_Step1_1[]="\
Test 7:step 1/1:\r\n\
-------------------------\r\n\
This test create a window. It do the same work than Test 6 , with a \
different style, a vertical scroll bar is to be added and the edition of \
notes is now enabled.\r\n\
	- The style is: S_BORDER + S_STATUS + S_TITLE + S_VAR_SIZE + \r\n\
	                S_HSCROLL + S_VSCROLL + S_EDIT.\r\n\
With the S_EDIT style, the window show a tool bar a the top to the client \
area. Now the user is allowed to use the full interactives features of the \
window.\r\n\
The vertical scroll bar is show only when necessary. With one staff in the \
internal StaffInfos table, the vertical scroll bar is hidden.\r\n\
To learn about the edition capabilities, please refer to the user manual and \
try to use edition commands described in this manual.\r\n\
Press the push button to execute and see the status in the result window.";

/*---------------------------------------------------------------------------*/
char Res7_Step1_1[]="\
\r\n\
If the result is successful, you can see a small MsNotes window (above the \
tutorial dialog box) with a tool bar, a vertical and horizontal scroll bar, \
a sizable window border, a status bar and a caption bar. So the window is \
able  to notify the tutorial application.\r\n\
Try to register a notifying callback procedure by pressing the 'Notify' check \
box below and see the result in this window.";

/*---------------------------------------------------------------------------*/
char DescTest8_Step1_1[]="\
Test 8:step 1/1:\r\n\
-------------------------\r\n\
This test create a window. It do the same work than Test 7 , with new window \
informations ( MsNotesInfos ). Now this window can display 3 staffs and 4 \
bars by staff.\r\n\
Press the push button to execute and see the status in the result window.";

/*---------------------------------------------------------------------------*/
char DescTest9_Step1_1[]="\
Test 9:step 1/1:\r\n\
-------------------------\r\n\
This test get the length LEN_TITLE_MSN of the window title.\r\n\
Now the application know the lenght of the buffer need to get the title \
of the window.\r\n\
If the result is successful, the value of the lenght is displayed in the \
result window.\r\n\
Press the push button to execute and see the status in the result window.";

/*---------------------------------------------------------------------------*/
char DescTest10_Step1_1[]="\
Test 10:step 1/1:\r\n\
-------------------------\r\n\
This test set the length of the window title LEN_TITLE_MSN to  8 bytes.\r\n\
This is usefull to limit the length of the title to the lenght of the buffer \
used to get the window title.\r\n\
Now a maximum of 8 bytes of the title will be received when getting the \
window title.\r\n\
Press the push button to execute and see the status in the result window.";

/*---------------------------------------------------------------------------*/
char DescTest11_Step1_1[]="\
Test 11:step 1/1:\r\n\
-------------------------\r\n\
This test get the window title TITLE_MSN.\r\n\
If the result is successful, the title is displayed in the result window.\r\n\
Press the push button to execute and see the status in the result window.";

/*---------------------------------------------------------------------------*/
char DescTest12_Step1_1[]="\
Test 12:step 1/1:\r\n\
-------------------------\r\n\
This test set window title TITLE_MSN to: This is a new title.\r\n\
If the result is successful, the new title is display in the caption bar if \
it exits.\r\n\
Press the push button to execute and see the status in the result window.";

/*---------------------------------------------------------------------------*/
char DescTest13_Step1_1[]="\
Test 13:step 1/1:\r\n\
-------------------------\r\n\
This test get the window style STYLE_MSN.\r\n\
If the result is successful, the style is displayed in the result window.\r\n\
Press the push button to execute and see the status in the result window.";

/*---------------------------------------------------------------------------*/
char DescTest14_Step1_1[]="\
Test 14:step 1/1:\r\n\
-------------------------\r\n\
This test set window style STYLE_MSN to: 0.\r\n\
Press the push button to execute and see the status in the result window.";

/*---------------------------------------------------------------------------*/
char DescTest15_Step1_1[]="\
Test 15:step 1/1:\r\n\
-------------------------\r\n\
This test get the window position : XY_MSN";

/*---------------------------------------------------------------------------*/
char DescTest16_Step1_1[]="\
Test 16:step 1/1:\r\n\
-------------------------\r\n\
This test set the window position : XY_MSN.\r\n\
Choose the X and Y values with the spin control 1 and 2 then press the push \
button to execute and see the status in the result window.";

/*---------------------------------------------------------------------------*/
char DescTest17_Step1_1[]="\
Test 17:step 1/1:\r\n\
-------------------------\r\n\
This test get the window size : SIZE_MSN.";

/*---------------------------------------------------------------------------*/
char DescTest18_Step1_1[]="\
Test 18:step 1/1:\r\n\
-------------------------\r\n\
This test set the window position : SIZE_MSN.\r\n\
Choose the Width and Height values with the spin control 1 and 2 then press \
the push button to execute and see the status in the result window.";

/*---------------------------------------------------------------------------*/
char DescTest19_Step1_1[]="\
Test 19:step 1/1:\r\n\
-------------------------\r\n\
This test get the numerator NUM_MSN and denominator DENO_MSN of meter key.";

/*---------------------------------------------------------------------------*/
char DescTest20_Step1_1[]="\
Test 20:step 1/1:\r\n\
-------------------------\r\n\
This test set the numerator NUM_MSN and denominator DENO_MSN of meter key.\r\n\
Choose the Numerator and Denominator values with the spin control 1 and 2 \
then press the push button to execute and see the status in the result window.";

/*---------------------------------------------------------------------------*/
char DescTest21_Step1_1[]="\
Test 21:step 1/1:\r\n\
-------------------------\r\n\
This test get the key signature KEY_SIGN_MSN.";

/*---------------------------------------------------------------------------*/
char DescTest22_Step1_1[]="\
Test 22:step 1/1:\r\n\
-------------------------\r\n\
This test set the key signature KEY_SIGN_MSN.\r\n\
Choose the key signature value with the spin control 1 then press the push \
button to execute and see the status in the result window.";

/*---------------------------------------------------------------------------*/
char DescTest23_Step1_1[]="\
Test 23:step 1/1:\r\n\
-------------------------\r\n\
This test get the numerator NUM_MSN ,denominator DENO_MSN, and key signature \
in one call. These 3 informations are identified by SIGN_MSN.";

/*---------------------------------------------------------------------------*/
char DescTest24_Step1_1[]="\
Test 24:step 1/1:\r\n\
-------------------------\r\n\
This test set the numerator,denominator, and key signature in one call. \
These 3 informations are identified by SIGN_MSN.\r\n\
Choose the Numerator, Denominator and Key signature values with the spin \
control 1 , 2 and 3 then press the push button to execute and see the status \
in the result window.";

/*---------------------------------------------------------------------------*/
char DescTest25_Step1_1[]="\
Test 25:step 1/1:\r\n\
-------------------------\r\n\
This test get the time division in PPQN (Part Per Quarter Note): PPQN_MSN.";

/*---------------------------------------------------------------------------*/
char DescTest26_Step1_1[]="\
Test 26:step 1/1:\r\n\
-------------------------\r\n\
This test set the time division in PPQN (Part Per Quarter Note): PPQN_MSN.\r\n\
Choose the time division value with the spin control 1 then press the push \
button to execute and see the status in the result window.";

/*---------------------------------------------------------------------------*/
char DescTest27_Step1_1[]="\
Test 27:step 1/1:\r\n\
-------------------------\r\n\
This test get the resolution: RES_MSN.";

/*---------------------------------------------------------------------------*/
char DescTest28_Step1_1[]="\
Test 28:step 1/1:\r\n\
-------------------------\r\n\
This test set the resolution: RES_MSN.\r\n\
Choose the resolution value with the spin control 1 then press the push button \
to execute and see the status in the result window.";

/*---------------------------------------------------------------------------*/
char DescTest29_Step1_1[]="\
Test 29:step 1/1:\r\n\
-------------------------\r\n\
This test get the Flags FLAGS_MSN and the date GUIDE_DATE_MSN of the guide \
reader.";

/*---------------------------------------------------------------------------*/
char DescTest30_Step1_1[]="\
Test 30:step 1/1:\r\n\
-------------------------\r\n\
This test set the date of the guide reader: GUIDE_DATE_MSN.\r\n\
Choose the guide date value with the spin control 1 then press the push button \
to execute and see the status in the result window.";

/*---------------------------------------------------------------------------*/
char DescTest31_Step1_1[]="\
Test 31:step 1/1:\r\n\
-------------------------\r\n\
This test get the Bar and Beat of the BBU pointer: BBU_MSN.\r\n\
This value is the position (in beats) of the horizontal scroll bar when \
it exist.";

/*---------------------------------------------------------------------------*/
char DescTest32_Step1_1[]="\
Test 32:step 1/1:\r\n\
-------------------------\r\n\
This test set the Bar and Beat of the BBU pointer: BBU_MSN.\r\n\
Choose the bar and beat values with the spin control 1 and 2 then press the \
push button to execute and see the status in the result window.";

/*---------------------------------------------------------------------------*/
char DescTest33_Step1_1[]="\
Test 33:step 1/1:\r\n\
-------------------------\r\n\
This test get the index of staff at the top of window: STAFFUP_MSN.\r\n\
This value is the position of the vertical scroll bar when it exist.";

/*---------------------------------------------------------------------------*/
char DescTest34_Step1_1[]="\
Test 34:step 1/1:\r\n\
-------------------------\r\n\
This test set the index of staff at the top of window: STAFFUP_MSN.\r\n\
Choose the index value with the spin control 1 then press the push button \
to execute and see the status in the result window.";

/*---------------------------------------------------------------------------*/
char DescTest35_Step1_1[]="\
Test 35:step 1/1:\r\n\
-------------------------\r\n\
This test get the number of staffs inside the window: NBR_STAFF_MSN.";


/*---------------------------------------------------------------------------*/
char DescTest36_Step1_1[]="\
Test 36:step 1/1:\r\n\
-------------------------\r\n\
This test try to set the number of staffs inside the window: NBR_STAFF_MSN.\r\n\
Choose the index value with the spin control 1 then press the push button \
to execute and see the status in the result window.\r\n\
This test will fail because the number of staff cannot be changed directly.\r\n\
The internal number of staff is updated when InsertStaff() and RemoveStaff() \
APIs are used.";

/*---------------------------------------------------------------------------*/
char DescTest37_Step1_1[]="\
Test 37:step 1/1:\r\n\
-------------------------\r\n\
This test get the number maximun of bars displayed (MAX_BAR_MSN) and the \
number maximum of staffs displayed (MAX_STAFF_MSN).";

/*---------------------------------------------------------------------------*/
char DescTest38_Step1_1[]="\
Test 38:step 1/1:\r\n\
-------------------------\r\n\
This test set the number maximun of bars displayed (MAX_BAR_MSN) and the \
number maximum of staffs displayed (MAX_STAFF_MSN).\r\n\
Choose the  nbr. bars and nbr. staffs values with the spin control 1 and 2 \
then press the push button to execute and see the status in the result window.";

/*---------------------------------------------------------------------------*/
char DescTest39_Step1_1[]="\
Test 39:step 1/1:\r\n\
-------------------------\r\n\
This test get and set the whole window information INFOS_MSN.\r\n\
	1) First the  test get the window informations.\r\n\
	2) The iTone, xPos field are changed.\r\n\
	3) The new window informations structure is set.";

/*---------------------------------------------------------------------------*/
char DescTest40_Step1_1[]="\
Test 40:step 1/1:\r\n\
-------------------------\r\n\
This test get the staff and set the staff name NAME_STAFF.\r\n\
	1) The test get the name of staff specified by the spin Infos 1.\r\n\
	2) The test set this name to the staff specified by the spin Infos 2.\r\n\
Choose the index values of the staff source and destination values with the \
spin Infos 1 and 2 then press the push button to execute and see the status \
in the result window.";

/*---------------------------------------------------------------------------*/
char DescTest41_Step1_1[]="\
Test 41:step 1/1:\r\n\
-------------------------\r\n\
This test get and set the sequence SEQ_STAFF of staffs.\r\n\
	1) The test get the sequence of staff specified by the spin Infos 1.\r\n\
	2) The test set this sequence to the staff specified by the spin Infos 2.\
\r\n\
Choose the index values of the staff source and destination values with the \
spin Infos 1 and 2 then press the push button to execute and see the status \
in the result window.";

/*---------------------------------------------------------------------------*/
char DescTest42_Step1_1[]="\
Test 42:step 1/1:\r\n\
-------------------------\r\n\
This test get and set the clef CLEF_STAFF of staffs.\r\n\
	1) The test get the clef of staff specified by the spin Infos 1.\r\n\
	2) The test set this clef to the staff specified by the spin Infos 2.\
\r\n\
Choose the index values of the staff source and destination values with the \
spin Infos 1 and 2 then press the push button to execute and see the status \
in the result window.";

/*---------------------------------------------------------------------------*/
char DescTest43_Step1_1[]="\
Test 43:step 1/1:\r\n\
-------------------------\r\n\
This test get and set the Height H_STAFF of staff zones.\r\n\
	1) The test get the height of staff zone specified by the spin Infos 1.\r\n\
	2) The test set this height to the staff zone specified by the spin \
Infos 2.\r\n\
Choose the index values of the staff source and destination values with the \
spin Infos 1 and 2 then press the push button to execute and see the status \
in the result window.";

/*---------------------------------------------------------------------------*/
char DescTest44_Step1_1[]="\
Test 44:step 1/1:\r\n\
-------------------------\r\n\
This test get and set the Midi port PORT_STAFF of a staff`\r\n\
	1) The test get the Midi Port of staff specified by the spin Infos 1.\r\n\
	2) The test set this Port to the staff specified by the spin Infos 2.\r\n\
Choose the index values of the staff source and destination values with the \
spin Infos 1 and 2 then press the push button to execute and see the status \
in the result window.";


/*---------------------------------------------------------------------------*/
char DescTest45_Step1_1[]="\
Test 45:step 1/1:\r\n\
-------------------------\r\n\
This test get and set the Midi channel CHAN_STAFF of a staff .\r\n\
	1) The test get the Midi channel of staff specified by the spin Infos 1.\
\r\n\
	2) The test set this channel to the staff specified by the spin Infos 2.\
\r\n\
Choose the index values of the staff source and destination values with the \
spin Infos 1 and 2 then press the push button to execute and see the status \
in the result window.";

/*---------------------------------------------------------------------------*/
char DescTest46_Step1_1[]="\
Test 46:step 1/1:\r\n\
-------------------------\r\n\
This test get and set the staff informations INFOS_STAFF.\r\n\
	1) The test get the INFOS_STAFF of staff specified by the spin Infos 1.\r\n\
	2) The test set this INFOS_STAFF to the staff specified by the spin Infos 2.\
\r\n\
Choose the index values of the staff source and destination values with the \
spin Infos 1 and 2 then press the push button to execute and see the status \
in the result window.";

/*---------------------------------------------------------------------------*/
char DescTest47_Step1_1[]="\
Test 47:step 1/1:\r\n\
-------------------------\r\n\
This test insert a new staff.\r\n\
	1) The test get the INFOS_STAFF of staff position specified by the spin \
Infos 1.\r\n\
	2) The test insert a new staff with this INFOS_STAFF to position \
specified by the spin Infos 2.\r\n\
Choose the index values of the staffs source and destination values with the \
spin Infos 1 and 2 then press the push button to execute and see the status \
in the result window.";

/*---------------------------------------------------------------------------*/
char DescTest48_Step1_1[]="\
Test 48:step 1/1:\r\n\
-------------------------\r\n\
This test remove a staff.\r\n\
Choose the index values of the staff to remove with the spin Infos 1 and then \
en press the push button to execute and see the status in the result window.";

/*---------------------------------------------------------------------------*/
char DescTest49_Step1_1[]="\
Test 49:step 1/1:\r\n\
-------------------------\r\n\
This test move a  staff.\r\n\
Choose the current position and new position of the staff with the spin \
Infos 1 and 2 then press the push button to execute and see the status in \
the result window.";








