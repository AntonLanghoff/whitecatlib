/*****************************************************************************
 Module: TutWinmain.c           
 Email: Jean-Jacques.CERESA@enac.fr

******************************************************************************/

#define STRICT
#define __Windows__		// Application Windows 
#include "Tutorial.h"
//#include "MsNotes.h"
//#include "NotesRes.h"
//#include <COMMCTRL.H>

//-Prototypes-----------------------------------------------------------------

extern BOOL CALLBACK TutorialDialogProc(HWND hwndDlg, UINT message, WPARAM wParam,
						   LPARAM lParam) ;
char Titre[]="MsNotes tutorial"; 
HINSTANCE  ghInstance;
/*****************************************************************************/
int  PASCAL WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance,
			LPSTR lpszCmdLine, int nCmdShow)
{

	int r;
	ghInstance = hInstance;
	InitCommonControls ();	// Necessary to load de common controls library.
	r= DialogBox(hInstance, MAKEINTRESOURCE(IDD_TUTORIAL), 
                     NULL, (DLGPROC)TutorialDialogProc);
//	if (r == -1) MessageBeep(-1);
	return 0;

}

