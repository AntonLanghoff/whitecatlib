/******************************************************************************
 NotifyProc.c
 Email: Jean-Jacques.CERESA@enac.fr
******************************************************************************/
#define STRICT
#define __Windows__		// Application Windows 
#include "Tutorial.h"

char ResNotifyFail[]="\r\n\
Installing a notifying procedure fails if the MsNotes window cannot \
notify. A MsNotes window can notify if it has at less one of these flags \
styles:\r\n\
	S_EDIT, which enable edition of notes.\r\n\
	S_VAR_SIZE, which enable sizing the window.\r\n\
	S_TITLE, which enable moving the window.\r\n\
	S_VSCROLL, which enable scrolling the staff vertically.\r\n\
	S_HSCROLL, which enable scrolling the staff horizontally.\
";

/*----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
void Install_Deinstall_Notify(void)
{					
	Byte s;
	if( IsDlgButtonChecked(ghwndDlg,IDC_CHECK_NOTIFY))
	{	// Try to install the notifiy procedure.
		s = SetMsNotesApplNotify (
					hWndMsNotes,/* Handle of MsNotes window	*/
					NotifyProc	/* Pointer to notify routine */
					);
		strcpy(ResultBuff,"Result of installing the notify procedure");
		EnNotifyWnd= ! s;
		SendDlgItemMessage(ghwndDlg, IDC_CHECK_NOTIFY,BM_SETCHECK ,
													EnNotifyWnd,0);
	}
	else 
	{	// Try to de-install the notifiy procedure.
		s = SetMsNotesApplNotify (
					hWndMsNotes,/* Handle of MsNotes window	*/
					Null		/* Pointer to notify routine */
					);
		strcpy(ResultBuff, "Result of de-installing the notify procedure");
		EnNotifyWnd = False;
	}
	iResBuff = strlen(ResultBuff);
	wsprintf( &ResultBuff[iResBuff],":%d, %s", s,TabErrMsg[s]);
	if (s)	
	{
		strcat(ResultBuff, ResNotifyFail);
		MessageBeep(MB_ICONEXCLAMATION);
	}
	SetDlgItemText(ghwndDlg,IDC_EDIT_NOTIFY,""); // Clear the window

	SetDlgItemText(ghwndDlg, IDC_EDIT_RES,ResultBuff);
}

/*----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
Byte MSNOTESALARMAPI NotifyProc (
					hMsNotes	hMsNotes,	/* Handle of MsNotes window	*/
					Byte		StaffId,	/* Id of the changed Staff	*/
					Byte		InfosId,	/* Id of the changed infos	*/ 
					long		Infos		/* Value of the infos		*/
					
					)
{	
	char Buff[100];
	switch (InfosId)
	{
		/*-------------------------------------------------------------------*/
		/* Codes identifiers for staff informations */
		/* Coordinate of the upper-left corner  X et Y	(Notify) */
		case XY_MSN:
			wsprintf( Buff,"%08X\tNo\t%s\tX:%d Y:%d",hMsNotes,
						TabNameIdInfos[InfosId],
						XposXY_MSN(Infos),YposXY_MSN(Infos));

		break;
		/* Height and width								(Notify) */
		case SIZE_MSN:
			wsprintf( Buff,"%08X\tNo\t%s\tW:%d H:%d",hMsNotes,
						TabNameIdInfos[InfosId],
						WidthSIZE_MSN(Infos),HeightSIZE_MSN(Infos));
		break;
		/* Numerator of Time Signature	 (Notify)				 */
		case NUM_MSN:
		/* Denominator of Time Signature (Notify)				 */
		case DENO_MSN:
		/* Tonality (Notify)									 */
		case KEY_SIGN_MSN:
		/* Resolution for displayed note duration (Notify)		 */
		case RES_MSN:	
		/* Infos are flags described in the next section (Notify)*/
		case FLAGS_MSN:
		/* Index of staff at the top of window	(Notify)		 */
		case STAFFUP_MSN:
			wsprintf( Buff,"%08X\tNo\t%s\t%d",hMsNotes,
						TabNameIdInfos[InfosId],Infos);
		break;
		/* BBU date under le left edge of the window (Notify)	 */
		case BBU_MSN:
			wsprintf( Buff,"%08X\tNo\t%s\tBar:%d Beat:%d (0 based)",hMsNotes,
						TabNameIdInfos[InfosId],
						BarBBU_MSN(Infos),BeatBBU_MSN(Infos));
		break;
 	
		/*-------------------------------------------------------------------*/
		/* Codes identifiers for staff informations */
		/* Name of staff or instrument (Notify)			*/
		case NAME_STAFF:
			wsprintf( Buff,"%08X\t%d\t%s\t%s",hMsNotes,StaffId,
						TabNameIdInfos[InfosId],
						(TitlePtr) Infos);
		break;
		/* Sequence MidiShare (Notify)					*/
		case SEQ_STAFF:
			wsprintf( Buff,"%08X\t%d\t%s\tNo",hMsNotes,StaffId,
						TabNameIdInfos[InfosId]);
		break;
		/* Clef in the staff header	(Notify)			*/
		case CLEF_STAFF:
		/* Height of staff zone	(Notify)				*/
		case H_STAFF:
			wsprintf( Buff,"%08X\t%d\t%s\t%d",hMsNotes,StaffId,
					TabNameIdInfos[InfosId],Infos);
		break;
		/* Midi port used to hear note	(Notify)		*/
		case PORT_STAFF:
			wsprintf( Buff,"%08X\t%d\t%s\tPart%d Port:%d",hMsNotes,StaffId,
					TabNameIdInfos[InfosId],PartPORT_STAFF((Word)Infos),
					PortPORT_STAFF((Word)Infos));
		break;
		/* Midi channel used to hear note (Notify)		*/
		case CHAN_STAFF:
			wsprintf( Buff,"%08X\t%d\t%s\tPart%d Chan:%d",hMsNotes,StaffId,
					TabNameIdInfos[InfosId],PartCHAN_STAFF((Word)Infos),
					ChanCHAN_STAFF((Word)Infos));
		break;
		/* All the staff Informations */
		case INFOS_STAFF:
			wsprintf( Buff,"%08X\t%d\t%s\tStaffInfosPtr",hMsNotes,StaffId,
					TabNameIdInfos[InfosId]);
		break;
		
		/* Notify code only */
		/* Insertion of a new staff						*/
		case N_INSERT_STAFF:
			wsprintf( Buff,"%08X\t%d\t%s\tStaffInfosPtr",hMsNotes,StaffId,
					TabNameIdInfos[InfosId]);
		break;
		/* Removing a staff								*/
		case N_REMOVE_STAFF:
			wsprintf( Buff,"%08X\t%d\t%s\tNo",hMsNotes,StaffId,
					TabNameIdInfos[InfosId]);
		break;
		/* Changing the position of a staff				*/
		case N_MOVE_STAFF:
			wsprintf( Buff,"%08X\t%d\t%s\t%d",hMsNotes,StaffId,
					TabNameIdInfos[InfosId],Infos);
		break;
		/* Play the sp�cified Event on the ouput of the Ref application	*/	
		case N_PLAY_EV_STAFF: 
			MidiSendIm (Ref,MidiCopyEv((MidiEvPtr) Infos));
			wsprintf( Buff,"%08X\t%d\t%s\tMidiEvPtr",hMsNotes,StaffId,
						TabNameIdInfos[InfosId]);
		break;
		case N_CLOSE_MSN:
			wsprintf(Buff,"%08X\tNo\t%s\tNo",hMsNotes,TabNameIdInfos[InfosId]);
		break;
	}
//	wsprintf( Buff,"%08X\t%d\t%s\t%08X",hMsNotes,StaffId,
//		TabNameIdInfos[InfosId],Infos);
	SetDlgItemText(ghwndDlg,IDC_EDIT_NOTIFY,Buff);
	return False;
}

