/******************************************************************************
 TutWinProc.c
 
 Email: Jean-Jacques.CERESA@enac.fr
******************************************************************************/
#define STRICT
#define __Windows__		// Application Windows 
#include "Tutorial.h"


/*----------------------------------------------------------------------------
 Globals
-----------------------------------------------------------------------------*/
hMsNotes hWndMsNotes;
short Ref;						// MidiShare reference number
HWND ghwndDlg;					// Handle of the tutorial dialog box;

long Infos1,Infos2,Infos3;		// Value of spin Infos controls.
char ResultBuff[800];			// Buffer to write result message.
Word iResBuff;					// Index in the buffer for the next message.
Byte EnNotifyWnd;				// Enable the notify window control.

//-----------------------------------------------------------------------------
static Byte Start ;				// Pressing the button start
static Byte StateExec;			// State of the 'Execute' button
//-----------------------------------------------------------------------------
// Table of tests: indexed by index  iTest
Byte	iTest;				// Index of the test.
Word	iRelStep;			// Index of  the current step relative to the test
							// specified by iTest.
//-----------------------------------------------------------------------------
// Each byte is the number of steps for the test specified by iTest.
Byte	TabTest[]={
	1,1,1,1,1,1,1,1,1,1,	// Test  1 to 10
	1,1,1,1,1,1,1,1,1,1,	// Test 11 to 20
	1,1,1,1,1,1,1,1,1,1,	// Test 21 to 30
	1,1,1,1,1,1,1,1,1,		// Test 31 to 39
	1,1,1,1,1,1,1,			// Test 40 to 46
	1,1,1					// Test 47 to 49
};		// Table of tests.

//-----------------------------------------------------------------------------
// Table of steps tests: indexed by the fonction GetIndexStep()
StepInfos TabTestStep[]={
	DescTest1_Step1_1,Test1_Step1_1,Res1_Step1_1,0,
	DescTest2_Step1_1,Test2_Step1_1,Res2_Step1_1,0,
	DescTest3_Step1_1,Test3_Step1_1,Res3_Step1_1,0,
	DescTest4_Step1_1,Test4_Step1_1,Res4_Step1_1,0,
	DescTest5_Step1_1,Test5_Step1_1,Res5_Step1_1,0,
	DescTest6_Step1_1,Test6_Step1_1,Res6_Step1_1,0,
	DescTest7_Step1_1,Test7_Step1_1,Res7_Step1_1,0,
	DescTest8_Step1_1,Test8_Step1_1,Res7_Step1_1,0,
	DescTest9_Step1_1,Test9_Step1_1,Null,0,
	DescTest10_Step1_1,Test10_Step1_1,Null,0,

	DescTest11_Step1_1,Test11_Step1_1,Null,0,
	DescTest12_Step1_1,Test12_Step1_1,Null,0,
	DescTest13_Step1_1,Test13_Step1_1,Null,0,
	DescTest14_Step1_1,Test14_Step1_1,Null,0,
	DescTest15_Step1_1,Test15_Step1_1,Null,0,
	DescTest16_Step1_1,Test16_Step1_1,Null,INFOS1_F|INFOS2_F,
	DescTest17_Step1_1,Test17_Step1_1,Null,0,
	DescTest18_Step1_1,Test18_Step1_1,Null,INFOS1_F|INFOS2_F,
	DescTest19_Step1_1,Test19_Step1_1,Null,0,
	DescTest20_Step1_1,Test20_Step1_1,Null,INFOS1_F|INFOS2_F,
	
	DescTest21_Step1_1,Test21_Step1_1,Null,0,
	DescTest22_Step1_1,Test22_Step1_1,Null,INFOS1_F,
	DescTest23_Step1_1,Test23_Step1_1,Null,0,
	DescTest24_Step1_1,Test24_Step1_1,Null,INFOS1_F|INFOS2_F|INFOS3_F,
	DescTest25_Step1_1,Test25_Step1_1,Null,0,
	DescTest26_Step1_1,Test26_Step1_1,Null,INFOS1_F,
	DescTest27_Step1_1,Test27_Step1_1,Null,0,
	DescTest28_Step1_1,Test28_Step1_1,Null,INFOS1_F,
	DescTest29_Step1_1,Test29_Step1_1,Null,0,
	DescTest30_Step1_1,Test30_Step1_1,Null,INFOS1_F,
	
	DescTest31_Step1_1,Test31_Step1_1,Null,0,
	DescTest32_Step1_1,Test32_Step1_1,Null,INFOS1_F|INFOS2_F,
	DescTest33_Step1_1,Test33_Step1_1,Null,0,
	DescTest34_Step1_1,Test34_Step1_1,Null,INFOS1_F,
	DescTest35_Step1_1,Test35_Step1_1,Null,0,
	DescTest36_Step1_1,Test36_Step1_1,Null,INFOS1_F,
	DescTest37_Step1_1,Test37_Step1_1,Null,0,
	DescTest38_Step1_1,Test38_Step1_1,Null,INFOS1_F|INFOS2_F,
	DescTest39_Step1_1,Test39_Step1_1,Null,0,

	DescTest40_Step1_1,Test40_Step1_1,Null,INFOS1_F|INFOS2_F,
	DescTest41_Step1_1,Test41_Step1_1,Null,INFOS1_F|INFOS2_F,
	DescTest42_Step1_1,Test42_Step1_1,Null,INFOS1_F|INFOS2_F,
	DescTest43_Step1_1,Test43_Step1_1,Null,INFOS1_F|INFOS2_F,
	DescTest44_Step1_1,Test44_Step1_1,Null,INFOS1_F|INFOS2_F,
	DescTest45_Step1_1,Test45_Step1_1,Null,INFOS1_F|INFOS2_F,
	DescTest46_Step1_1,Test46_Step1_1,Null,INFOS1_F|INFOS2_F,

	DescTest47_Step1_1,Test47_Step1_1,Null,INFOS1_F|INFOS2_F,
	DescTest48_Step1_1,Test48_Step1_1,Null,INFOS1_F,
	DescTest49_Step1_1,Test49_Step1_1,Null,INFOS1_F|INFOS2_F,

};

BOOL CALLBACK AboutDialogProc(HWND hwndDlg, UINT message, WPARAM wParam,
						   LPARAM lParam) ;

/*----------------------------------------------------------------------------
	Description of the 'Description test' window control.
-----------------------------------------------------------------------------*/
char MsgTest[]="\
		*** WELCOME TO THE MSNOTES TUTORIAL ***\r\n\
This tutorial is is intended for the developers who wish to understand how a \
MsNotes window works and learn the API of the MsNotes library.\r\n\
For each API function, the tutorial execute a serie of tests step by step. \
In order for you to learn the API functions and look at the source code, you \
must print the 'TestXXToYY.c' file before starting.\r\n\
Try the following method for learning about a test:\r\n\
	1)Read the description of the test in this window and in the 'TestXXtoYY.c' \
file.\r\n\
	2)Read the source code of the test in the 'TestXXToYY.c' file.\r\n\
	3)Try to anticipate about the result before executing.\r\n\
	4)Execute the step and read the result displayed in the 'Result' \
window below this one.\r\n\
	5)Verify the result and what you have expected at (3).\r\n\
\r\n\
Following is the description of each control owned by this dialog box.\r\n\
This window control is used to display a description of the test to execute \
and the 'Start' push button let you execute each test step by step.\r\n\
If enabled the 'Infos 1,2,3' spin buttons(to the left of the 'Start' button) \
let you choose values to set before executing the test.\r\n\
The 'Test number' spin button (to the left of the 'Infos 1' button) let \
you choose a test number directely. However if you run this tutorial for the \
first time it is better to use only the push button and follow the default \
serie of tests. \r\n\
Before starting read the description of the others windows controls below \
this one. When you are ready, press the 'Start' button.\r\n\
At any time the 'Restart' push button let you go to the start of this tutorial \
and the 'About' push button gives informations about versions.";

/*----------------------------------------------------------------------------
	Description of the 'Result' window control.
-----------------------------------------------------------------------------*/
char MsgResult[]="\
This is the window to display the result of the tests steps execution. \
Results are displayed after each action on the 'Start|Execute' button.\
";

/*----------------------------------------------------------------------------
	Description of the 'Notify' window control.
-----------------------------------------------------------------------------*/
char MsgNotify[]="\
This is the window control to display parameters received by the application \
callback procedure. This window is enabled only if you press the 'Notify' \
check box. The 'Notify' check is enabled only if a MsNotes window is created \
by the tutorial and pressing the check box register a notify callback \
procedure for this MsNotes window.\r\n\
Parameters values are show in columns 1,2,3 and 4:\r\n\
Column 1 is the handle value (in hexadecimal) of the notifying window.\r\n\
Column 2 is the identifier value (in decimal) of the changed staff.The value \
'No' means that the value has no meaning.\r\n\
Column 3 is the code identifier (literal) of the changed information.\r\n\
Column 4 is the value (in decimal) or the address (literal) of the changed \
information. The value 'No' means that the value has no meaning. \
See the examples below.\r\n\
\r\n\
000000AB	No	DENO_MSN	4\r\n\
The denominator has been changed to the value 4:\r\n\
\r\n\
000000AB	No	BBU_MSN	bar:3 beat.2\r\n\
The BBU pointer has been changed to bar 3 , beat 2.\r\n\
\r\n\
000000AB	No	N_PLAY_EV_STAFF	MidiEvPtr\r\n\
A request to play the event pointed by Infos.\r\n\
\r\n\
000000AB	2	SEQ_STAFF	No\r\n\
The contents sequence of the staff 2 pointed by Infos has been changed.\
";

/*----------------------------------------------------------------------------
 The function return the TestStepPtr index 
 Input parameters:
	iTest, index of the test.
	iStep, index of the step relative to test iTest.
-----------------------------------------------------------------------------*/
Word GetStepIndex( Byte iTest, Word iRelStep)
{
	Byte i;
	for (i=0; i < iTest; i++)  iRelStep += TabTest[i]; 
	return iRelStep;
}

/*----------------------------------------------------------------------------
 Enable / disable the 'notify' window control.
-----------------------------------------------------------------------------*/
void EnableNotifyWnd(HWND hwndDlg, BOOL En)
{
	EnableWindow(GetDlgItem(hwndDlg, IDC_STATIC0_NOTIFY), En);
	EnableWindow(GetDlgItem(hwndDlg, IDC_STATIC1_NOTIFY), En);
	EnableWindow(GetDlgItem(hwndDlg, IDC_STATIC2_NOTIFY), En);
	EnableWindow(GetDlgItem(hwndDlg, IDC_STATIC3_NOTIFY), En);
	EnableWindow(GetDlgItem(hwndDlg, IDC_EDIT_NOTIFY), En);
}

/*----------------------------------------------------------------------------
 Enable / disable the spin 'test number' control
-----------------------------------------------------------------------------*/
void EnableSpinTest(HWND hwndDlg, BOOL En)
{
	EnableWindow(GetDlgItem(hwndDlg, IDC_EDIT_SPIN_TEST), En);
	EnableWindow(GetDlgItem(hwndDlg, IDC_SPIN_TEST), En);
}

/*----------------------------------------------------------------------------
 Enable / disable the spin 'Infos to set' control
-----------------------------------------------------------------------------*/
void EnableInfosControl(void)
{
	Word StepIndex = GetStepIndex(iTest,iRelStep); 
	EnableWindow(GetDlgItem(ghwndDlg, IDC_EDIT_SPIN_INFOS1),IsInfos1(StepIndex));
	EnableWindow(GetDlgItem(ghwndDlg, IDC_SPIN_INFOS1),IsInfos1(StepIndex));

	EnableWindow(GetDlgItem(ghwndDlg, IDC_EDIT_SPIN_INFOS2),IsInfos2(StepIndex));
	EnableWindow(GetDlgItem(ghwndDlg, IDC_SPIN_INFOS2),IsInfos2(StepIndex));

	EnableWindow(GetDlgItem(ghwndDlg, IDC_EDIT_SPIN_INFOS3),IsInfos3(StepIndex));
	EnableWindow(GetDlgItem(ghwndDlg, IDC_SPIN_INFOS3),IsInfos3(StepIndex));
}


/*----------------------------------------------------------------------------
 Display a message description: for the test iTest and step iRelStep
-----------------------------------------------------------------------------*/
void DisplayDesc(HWND hwndDlg)
{
	char * DescMsg = TabTestStep[GetStepIndex(iTest,iRelStep)].DescMsg; 
	if (DescMsg) SetDlgItemText(hwndDlg, IDC_EDIT_TEST,DescMsg );
	// Update the SPIN_TEST control with the new iTest value
	SendDlgItemMessage(hwndDlg,IDC_SPIN_TEST,UDM_SETPOS ,0,
						(LPARAM) MAKELONG(iTest+1, 0)  );
	// Update enabling of the Spin button on step 0 only
	EnableSpinTest(hwndDlg, !iRelStep ); 
	EnableInfosControl();
}


/*----------------------------------------------------------------------------
 Execute the step iRelStep of  iTest.
-----------------------------------------------------------------------------*/
void ExecuteStep(HWND hwndDlg)
{
	Word StepIndex = GetStepIndex(iTest,iRelStep);
	//-----------------------------------------------------
	// Execute the current step procedure
	TestStepPtr TestStep = TabTestStep[StepIndex].TestStep;
	if( TestStep)
	{	char * ResMsg ;	// result message
		// Prepare the result message.
		wsprintf( ResultBuff,"Result for Test:%d Step:%d of %d",
				iTest+1,iRelStep+1,TabTest[iTest]);
		iResBuff = strlen(ResultBuff);
		// Execute the test
		TestStep();
		// complete the result message before display it.
		ResMsg = TabTestStep[StepIndex].ResMsg; 
		if (ResMsg) strcat(ResultBuff, ResMsg);
	}
	else ResultBuff[0]='\0';
	/*--------------------------------------------------------------------------
	Display a message in the  'result' windows. The message is in the ResultBuff
	which is initialised by the ExecuteStep() function before executing the step 
	procedure. The step procedure complete the message with other resulting
	informations.
	--------------------------------------------------------------------------*/
	SetDlgItemText(hwndDlg, IDC_EDIT_RES,ResultBuff);

	//-----------------------------------------------------
	// Update for the next Step
	iRelStep++;		// next step for iTest
	if (iRelStep >= TabTest[iTest])
	{	// Go to the next test
		iRelStep = 0;		iTest ++;
		if ( iTest >= sizeof(TabTest)) iTest=0;
	}
	EnableSpinTest(hwndDlg, False ); // Disable spin button
}

char TextButtDesc[]="Press to display a description of the next test";
/*----------------------------------------------------------------------------
	Set the text of the 'Execute test' button 
-----------------------------------------------------------------------------*/
void UpdateTextButtExect(HWND hwndDlg)
{
	char * Text;
	if ( StateExec )
	{
		Byte Buff[100];
		wsprintf( Buff,"Press to execute Test:%d Step:%d of %d",
					iTest+1,iRelStep+1,TabTest[iTest]); 
		Text = Buff;
	}
	else  	Text = TextButtDesc; 	
	SetDlgItemText(hwndDlg, IDEXEC,Text);
}
	
/*----------------------------------------------------------------------------
	Initialise the contents of the dialog box
-----------------------------------------------------------------------------*/
void InitTutorialDialogBox (HWND hwndDlg)
{
	//-------------------------------------------------------------------------
	hWndMsNotes=Null;
	Start = True;
	iRelStep = iTest = 0;
	StateExec=0;

	//-------------------------------------------------------------------------
	// Initialisation of the spin control.
	SendDlgItemMessage(hwndDlg, IDC_SPIN_INFOS1,UDM_SETRANGE ,0,
					(LPARAM) MAKELONG(UD_MAXVAL, (short) 0));
	SetDlgItemInt(hwndDlg,IDC_EDIT_SPIN_INFOS1,0,FALSE);
	EnableWindow(GetDlgItem(ghwndDlg, IDC_EDIT_SPIN_INFOS1),False);
	EnableWindow(GetDlgItem(ghwndDlg, IDC_SPIN_INFOS1),False);

	SendDlgItemMessage(hwndDlg, IDC_SPIN_INFOS2,UDM_SETRANGE ,0,
					(LPARAM) MAKELONG(UD_MAXVAL, (short) 0));
	SetDlgItemInt(hwndDlg,IDC_EDIT_SPIN_INFOS2,0,FALSE);
	EnableWindow(GetDlgItem(ghwndDlg, IDC_EDIT_SPIN_INFOS2),False);
	EnableWindow(GetDlgItem(ghwndDlg, IDC_SPIN_INFOS2),False);

	SendDlgItemMessage(hwndDlg, IDC_SPIN_INFOS3,UDM_SETRANGE ,0,
					(LPARAM) MAKELONG(UD_MAXVAL, (short) 0));
	SetDlgItemInt(hwndDlg,IDC_EDIT_SPIN_INFOS3,0,FALSE);
	EnableWindow(GetDlgItem(ghwndDlg, IDC_EDIT_SPIN_INFOS3),False);
	EnableWindow(GetDlgItem(ghwndDlg, IDC_SPIN_INFOS3),False);

	SendDlgItemMessage(hwndDlg, IDC_SPIN_TEST,UDM_SETRANGE ,0,
					(LPARAM) MAKELONG(sizeof(TabTest), (short) 1));
	EnableSpinTest(hwndDlg, False); 
	//-------------------------------------------------------------------------
	{	// Set Tabs for the notify window.
		DWORD Unit[]={55-16,85-16,161-16};
		EnableWindow(GetDlgItem(hwndDlg, IDC_CHECK_NOTIFY), False);
		EnNotifyWnd = True;
		EnableNotifyWnd(hwndDlg, True);
		SendDlgItemMessage(hwndDlg, IDC_EDIT_NOTIFY,EM_SETTABSTOPS ,
							3,  // number of tab stops 
							(LPARAM) (LPDWORD) &Unit); // tab stop array 
 	}
	//-------------------------------------------------------------------------
	// Initial welcome messages.
	SetDlgItemText(hwndDlg, IDC_EDIT_TEST,MsgTest);
	SetDlgItemText(hwndDlg, IDC_EDIT_RES,MsgResult);
	SetDlgItemText(hwndDlg, IDC_EDIT_NOTIFY,MsgNotify);
	//-------------------------------------------------------------------------
	// Initial text for the IDEXEC button
	SetDlgItemText(hwndDlg, IDEXEC,"Start");
}

/******************************************************************************
 Procedure of the tutorial dialog box
******************************************************************************/
BOOL CALLBACK TutorialDialogProc(HWND hwndDlg, UINT message, WPARAM wParam,
						   LPARAM lParam) 
{ 
	ghwndDlg = hwndDlg;
	switch (message) 
    { 
		//---------------------------------------------------------------------
		case WM_INITDIALOG: 
			
			// Obligatoire pour charger la librairie MidiShare
			Ref=MidiOpen("Tutorial");
			// Connection a l'application MidiShare
			MidiConnect (Ref, 0, TRUE);  
			InitTutorialDialogBox(hwndDlg);
			return TRUE;
		
 		//---------------------------------------------------------------------
#if 0
		case WM_VSCROLL:
				// D�tection de changement d'information
			if (GetDlgCtrlID((HWND) lParam) == IDC_SPIN_TEST) 
			{
			}
			break; 
#endif
		//---------------------------------------------------------------------
		case WM_COMMAND: 
            switch (LOWORD(wParam)) 
            { 
				//-------------------------------------------------------------
				case IDEXEC: // The Execute test button
                    if (Start)	{ EnNotifyWnd = False;	Start = False;	}
					// Execute the next step.
					if ( StateExec )	ExecuteStep(hwndDlg);
					// Display the description of the next step.
					else	DisplayDesc(hwndDlg);
					StateExec^=1;
					UpdateTextButtExect(hwndDlg);
					break;
				//-------------------------------------------------------------
				case IDC_EDIT_SPIN_TEST:
					if (HIWORD(wParam) == EN_CHANGE) 
					{	//-----------------------------------------------------
						iTest=  GetDlgItemInt(hwndDlg,IDC_EDIT_SPIN_TEST,
													NULL,FALSE) -1;
						// Display the description of the next step.
						if( StateExec)
						{
							DisplayDesc(hwndDlg);
							UpdateTextButtExect(hwndDlg);
						}
					}
					break;
				case IDC_EDIT_SPIN_INFOS1:
				case IDC_EDIT_SPIN_INFOS2:
				case IDC_EDIT_SPIN_INFOS3:
					if (HIWORD(wParam) == EN_CHANGE) 
					{	//-----------------------------------------------------
						Infos1 =  GetDlgItemInt(hwndDlg,IDC_EDIT_SPIN_INFOS1,
													NULL,FALSE) ;
						Infos2 =  GetDlgItemInt(hwndDlg,IDC_EDIT_SPIN_INFOS2,
													NULL,FALSE) ;
						Infos3 =  GetDlgItemInt(hwndDlg,IDC_EDIT_SPIN_INFOS3,
													NULL,FALSE) ;
#if 0
						MessageBeep(-1);
						{ char buff[80];
						wsprintf(buff,"Infos1:%d, I2:%d I3:%d",Infos1,Infos2,Infos3);
						MessageBox(NULL,buff,"",MB_OK);
						}
#endif
					}
					break;
				//-------------------------------------------------------------
				case IDC_ABOUT: // The About button
					DialogBox(ghInstance, MAKEINTRESOURCE(IDD_ABOUT), hwndDlg,
								(DLGPROC)AboutDialogProc);
					break;
				//-------------------------------------------------------------
				case IDC_CHECK_NOTIFY: // The Notify check box
				{
					Install_Deinstall_Notify();
					break;
				}
				//-------------------------------------------------------------
				case IDC_RESTART:	// The Restart button
				case IDCANCEL:		// Send by default processing of WM_CLOSE 
				case IDEXIT:		// The Exit button
					// Clean up as necessary.
					if (hWndMsNotes)
					{
						BYTE s;
						s=DestroyMsNotes(hWndMsNotes); 
					}
					if (LOWORD(wParam) == IDC_RESTART )
					{
						InitTutorialDialogBox(hwndDlg);
						break;
					}
					MidiClose(Ref);
					//---------------------------------------------------------			
					EndDialog(hwndDlg, wParam);
			}
			//-----------------------------------------------------------------
			// Update the enable state of 'Notify' check and 'window' control. 
			if (!Start)
			if (hWndMsNotes) 
				EnableWindow(GetDlgItem(hwndDlg, IDC_CHECK_NOTIFY), True);
			else
			{	// Uncheck and inhibit the check box
				SendDlgItemMessage(hwndDlg, IDC_CHECK_NOTIFY,BM_SETCHECK ,0,0);
				EnableWindow(GetDlgItem(hwndDlg, IDC_CHECK_NOTIFY), False);
				EnNotifyWnd = False;
			}
			EnableNotifyWnd(hwndDlg, EnNotifyWnd);
			return TRUE;
	} 
    return FALSE; 
}


char Email[]="Email: Jean-Jacques.CERESA@enac.fr";
char VersionMsg[]="MsNotes version: %d.%02d using MidiShare version: %d.%02d";
/******************************************************************************
 Procedure of the about dialog box
******************************************************************************/
BOOL CALLBACK AboutDialogProc(HWND hwndDlg, UINT message, WPARAM wParam,
						   LPARAM lParam) 
{ 
	switch (message) 
    { 
		//---------------------------------------------------------------------
		case WM_INITDIALOG: 
		{	char Buff[100];
			short Version;
			VersionInfos VerInfos;
			// Init the version control.
			Version = MidiGetVersion();
			wsprintf(Buff,"MidiShare version: %d.%02d",Version/100,Version%100); 
			SetDlgItemText(hwndDlg, IDC_VERSION_MS,Buff);
			VerInfos = GetMsNotesVersion();
			wsprintf(Buff,VersionMsg,	VerInfos.MsNotesVersion/100,
										VerInfos.MsNotesVersion%100,
										VerInfos.MShareVersion/100,
										VerInfos.MShareVersion%100); 
			SetDlgItemText(hwndDlg, IDC_VERSION_MSNOTES,Buff);
			SetDlgItemText(hwndDlg, IDC_STATIC_EMAIL,Email);
			return TRUE;
		}
		//---------------------------------------------------------------------
		case WM_COMMAND: 
            switch (LOWORD(wParam)) 
            { 
				case IDOK:	// The Exit button
					//---------------------------------------------------------			
					EndDialog(hwndDlg, wParam);
			}
			return TRUE;
	} 
    return FALSE; 
}
