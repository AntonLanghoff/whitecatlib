/******************************************************************************
 Test40ToYY.c
 Email: Jean-Jacques.CERESA@enac.fr
******************************************************************************/


#define STRICT
#define __Windows__		// Application Windows 
#include "Tutorial.h"


/*=============================================================================
	The following tests get and set staff informations by the use of
	GetStaffInfos() and SetStaffInfos() APIs. 
=============================================================================*/

/*----------------------------------------------------------------------------
Test 40: step 1/1: 

This test get the staff and set the staff name NAME_STAFF.
	1) The test get the name of staff specified by the spin Infos 1
	2) The test set this name to the staff specified by the spin Infos 2

Choose the index values of the staff source and destination values with the 
spin Infos 1 and 2 then press the push button to execute and see the status in
the result window.
-----------------------------------------------------------------------------*/
byte Test40_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndMsNotes) Test8_Step1_1();

	/*-------------------------------------------------------------------
	 Get and set the staff name 
	--------------------------------------------------------------------*/
	{
		Byte Name [100];	// Buffer to get the name
		Byte s;				// Status of operation
		Byte StaffSrc = (Byte)Infos1;	// Infos1 is the source staff
		Byte StaffDst = (Byte)Infos2;	// Infos2 is the destination staff
		/* Get the staff name */
		s = GetStaffInfos( 	hWndMsNotes,/* Handle of MsNotes window	*/
							StaffSrc,	/* Position of the staff	*/
							NAME_STAFF,	/* Id of infos to retrieve	*/ 
							Name		/* Pointer on infos to get	*/
						 );
		/* prepare the result message */
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Get staff name, status:%d, %s", s,TabErrMsg[s]);
		iResBuff = strlen(ResultBuff);
		if (s) return s;
		
		/* Set the staff name */
		s = SetStaffInfos(	hWndMsNotes,/* Handle of MsNotes window	*/
							StaffDst,	/* Position of the staff	*/
							NAME_STAFF,	/* Id of infos to retrieve	*/ 
							(long)Name,	/* Pointer on infos to set	*/
							True		/* refresh now				*/
						 );
		/* prepare the result message */
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Set staff name, status:%d, %s", s,TabErrMsg[s]);

		return s;
	}
}


/*----------------------------------------------------------------------------
Test 41: step 1/1: 

This test get and set the sequence SEQ_STAFF of staffs:
	1) The test get the sequence of staff specified by the spin Infos 1
	2) The test set this sequence to the staff specified by the spin Infos 2

Choose the index values of the staff source and destination values with the 
spin Infos 1 and 2 then press the push button to execute and see the status in
the result window.
-----------------------------------------------------------------------------*/
byte Test41_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndMsNotes) Test8_Step1_1();

	/*-------------------------------------------------------------------
	 Get and set the sequence staffs. 
	--------------------------------------------------------------------*/
	{
		Byte s;					// Status of operation
		MidiSeqPtr	Seq;
		Byte StaffSrc = (Byte)Infos1;	// Infos1 is the source staff
		Byte StaffDst = (Byte)Infos2;	// Infos2 is the destination staff
		/* Get the staff sequence */
		s = GetStaffInfos( 	hWndMsNotes,/* Handle of MsNotes window	*/
							StaffSrc,	/* Position of the staff	*/
							SEQ_STAFF,	/* Id of infos to retrieve	*/ 
							&Seq		/* Pointer on infos to get	*/
						 );
		/* prepare the result message */
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Get staff sequence, status:%d, %s", s,TabErrMsg[s]);
		iResBuff = strlen(ResultBuff);
		if (s) 	return s;
		
		/* Set the staff sequence */
		s = SetStaffInfos(	hWndMsNotes,/* Handle of MsNotes window	*/
							StaffDst,	/* Position of the staff	*/
							SEQ_STAFF,	/* Id of infos to retrieve	*/ 
							(long)Seq,	/* Pointer on infos to set	*/
							True		/* refresh now				*/
						 );
		/* prepare the result message */
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Set staff sequence, status:%d, %s", s,TabErrMsg[s]);
		return s;
	}
}

/*----------------------------------------------------------------------------
Test 42: step 1/1: 

This test get and set the clef CLEF_STAFF of staffs:
	1) The test get the clef of staff specified by the spin Infos 1
	2) The test set this clef to the staff specified by the spin Infos 2

Choose the index values of the staff source and destination values with the 
spin Infos 1 and 2 then press the push button to execute and see the status in
the result window.
-----------------------------------------------------------------------------*/
byte Test42_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndMsNotes) Test8_Step1_1();

	/*-------------------------------------------------------------------
	 Get and set the clefs staffs. 
	--------------------------------------------------------------------*/
	{
		Byte s;					// Status of operation
		Byte	Clef;
		Byte StaffSrc = (Byte)Infos1;	// Infos1 is the source staff
		Byte StaffDst = (Byte)Infos2;	// Infos2 is the destination staff
		/* Get the staff clef */
		s = GetStaffInfos( 	hWndMsNotes,/* Handle of MsNotes window	*/
							StaffSrc,	/* Position of the staff	*/
							CLEF_STAFF,	/* Id of infos to retrieve	*/ 
							&Clef		/* Pointer on infos to get	*/
						 );
		/* prepare the result message */
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Get staff clef, status:%d, %s", s,TabErrMsg[s]);
		iResBuff = strlen(ResultBuff);
		if (s) return s;

		/* Set the staff clef */
		s = SetStaffInfos(	hWndMsNotes,/* Handle of MsNotes window	*/
							StaffDst,	/* Position of the staff	*/
							CLEF_STAFF,	/* Id of infos to retrieve	*/ 
							Clef,		/* Infos to set				*/
							True		/* refresh now				*/
						 );
		/* prepare the result message */
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Set staff clef, status:%d, %s", s,TabErrMsg[s]);
		return s;
	}
}

/*----------------------------------------------------------------------------
Test 43: step 1/1: 

This test get and set the Height H_STAFF of staff zones:
	1) The test get the height of staff zone specified by the spin Infos 1
	2) The test set this height to the staff zone specified by the spin Infos 2

Choose the index values of the staff source and destination values with the 
spin Infos 1 and 2 then press the push button to execute and see the status in
the result window.
-----------------------------------------------------------------------------*/
byte Test43_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndMsNotes) Test8_Step1_1();

	/*-------------------------------------------------------------------
	 Get and set the height of  staff zone. 
	--------------------------------------------------------------------*/
	{
		Byte s;					// Status of operation
		Word HeightStaff;
		Byte StaffSrc = (Byte)Infos1;	// Infos1 is the source staff
		Byte StaffDst = (Byte)Infos2;	// Infos2 is the destination staff
		/* Get the staff height */
		s = GetStaffInfos( 	hWndMsNotes,/* Handle of MsNotes window	*/
							StaffSrc,	/* Position of the staff	*/
							H_STAFF,	/* Id of infos to retrieve	*/ 
							&HeightStaff/* Pointer on infos to get	*/
						 );
		/* prepare the result message */
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Get staff height, status:%d, %s", s,TabErrMsg[s]);
		iResBuff = strlen(ResultBuff);
		if (s) return s;

		/* Set the staff height */
		s = SetStaffInfos(	hWndMsNotes,/* Handle of MsNotes window	*/
							StaffDst,	/* Position of the staff	*/
							H_STAFF,	/* Id of infos to retrieve	*/ 
							HeightStaff,/* Infos to set				*/
							True		/* refresh now				*/
						 );
		/* prepare the result message */
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Set staff height, status:%d, %s", s,TabErrMsg[s]);
		return s;
	}
}

/*----------------------------------------------------------------------------
Test 44: step 1/1: 

This test get and set the Midi port PORT_STAFF of a staff 
	1) The test get the Midi Port of staff specified by the spin Infos 1
	2) The test set this Port to the staff specified by the spin Infos 2

Choose the index values of the staff source and destination values with the 
spin Infos 1 and 2 then press the push button to execute and see the status in
the result window.

-----------------------------------------------------------------------------*/
byte Test44_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndMsNotes) Test8_Step1_1();

	/*-------------------------------------------------------------------
	 Get and set the Midi port. 
	--------------------------------------------------------------------*/
	{
		Byte s;					// Status of operation
		Word PartPort = 0;		// Get Part 0 port
		Byte StaffSrc = (Byte)Infos1;	// Infos1 is the source staff
		Byte StaffDst = (Byte)Infos2;	// Infos2 is the destination staff
		/* Get the staff port */
		s = GetStaffInfos( 	hWndMsNotes,/* Handle of MsNotes window	*/
							StaffSrc,	/* Position of the staff	*/
							PORT_STAFF,	/* Id of infos to retrieve	*/ 
							&PartPort	/* Pointer on infos to get	*/
						 );
		/* prepare the result message */
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Get staff port, status:%d, %s", s,TabErrMsg[s]);
		iResBuff = strlen(ResultBuff);
		if (s) return s;

		/* Set the staff port */
		s = SetStaffInfos(	hWndMsNotes,/* Handle of MsNotes window	*/
							StaffDst,	/* Position of the staff	*/
							PORT_STAFF,	/* Id of infos to retrieve	*/ 
							PartPort,	/* Infos to set				*/
							0			/* Do nothing				*/
						 );
		/* prepare the result message */
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Set staff port, status:%d, %s", s,TabErrMsg[s]);
		return s;
	}
}

/*----------------------------------------------------------------------------
Test 45: step 1/1: 

This test get and set the Midi channel CHAN_STAFF of a staff 
	1) The test get the Midi channel of staff specified by the spin Infos 1
	2) The test set this channel to the staff specified by the spin Infos 2

Choose the index values of the staff source and destination values with the 
spin Infos 1 and 2 then press the push button to execute and see the status in
the result window.

-----------------------------------------------------------------------------*/
byte Test45_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndMsNotes) Test8_Step1_1();

	/*-------------------------------------------------------------------
	 Get and set the Midi channel. 
	--------------------------------------------------------------------*/
	{
		Byte s;					// Status of operation
		Word PartChannel = 0;	// Get Part 0 channel
		Byte StaffSrc = (Byte)Infos1;	// Infos1 is the source staff
		Byte StaffDst = (Byte)Infos2;	// Infos2 is the destination staff
		/* Get the staff channel */
		s = GetStaffInfos( 	hWndMsNotes,/* Handle of MsNotes window	*/
							StaffSrc,	/* Position of the staff	*/
							CHAN_STAFF,	/* Id of infos to retrieve	*/ 
							&PartChannel/* Pointer on infos to get	*/
						 );
		/* prepare the result message */
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Get staff channel, status:%d, %s", s,TabErrMsg[s]);
		iResBuff = strlen(ResultBuff);
		if (s) return s;

		/* Set the staff channel */
		s = SetStaffInfos(	hWndMsNotes,/* Handle of MsNotes window	*/
							StaffDst,	/* Position of the staff	*/
							CHAN_STAFF,	/* Id of infos to retrieve	*/ 
							PartChannel,/* Infos to set				*/
							0			/* Do nothing				*/
						 );
		/* prepare the result message */
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Set staff channel, status:%d, %s", s,TabErrMsg[s]);
		return s;
	}
}


/*----------------------------------------------------------------------------
Test 46: step 1/1: 

This test get and set the staff informations INFOS_STAFF. 
	1) The test get the INFOS_STAFF of staff specified by the spin Infos 1.
	2) The test set this INFOS_STAFF to the staff specified by the spin Infos 2.

Choose the index values of the staff source and destination values with the 
spin Infos 1 and 2 then press the push button to execute and see the status in
the result window.

-----------------------------------------------------------------------------*/
byte Test46_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndMsNotes) Test8_Step1_1();

	/*-------------------------------------------------------------------
	 Get and set the StaffInfos. 
	--------------------------------------------------------------------*/
	{
		Byte s;					// Status of operation
		StaffInfos StaffInfos;
		Byte StaffSrc = (Byte)Infos1;	// Infos1 is the source staff
		Byte StaffDst = (Byte)Infos2;	// Infos2 is the destination staff
		/* Get the staff informations */
		s = GetStaffInfos( 	hWndMsNotes,/* Handle of MsNotes window	*/
							StaffSrc,	/* Position of the staff	*/
							INFOS_STAFF,/* Id of infos to retrieve	*/ 
							&StaffInfos	/* Pointer on infos to get	*/
						 );
		/* prepare the result message */
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Get staff informations, status:%d, %s", s,TabErrMsg[s]);
		iResBuff = strlen(ResultBuff);
		if (s) return s;

		/* Set the staff informations */
		s = SetStaffInfos(	hWndMsNotes,		/* Handle of MsNotes window	*/
							StaffDst,			/* Position of the staff	*/
							INFOS_STAFF,		/* Id of infos to retrieve	*/ 
							(long)&StaffInfos,	/* Pointer on infos to set	*/
							True				/* refresh now				*/
						 );
		/* prepare the result message */
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Set staff informations, status:%d, %s", s,TabErrMsg[s]);
		return s;
	}
}

/*=============================================================================
	The following tests Insert, Remove and Move staff the use of
	InsertStaff() , RemoveStaff() and MoveStaff() APIs. 
=============================================================================*/
/*----------------------------------------------------------------------------
Test 47: step 1/1: 

This test insert a new staff. 
	1) The test get the INFOS_STAFF of staff position specified by the spin
	   Infos 1.
	2) The test insert a new staff with this INFOS_STAFF to position specified 
	   by the spin Infos 2.

Choose the index values of the staffs source and destination values with the 
spin Infos 1 and 2 then press the push button to execute and see the status in
the result window.

-----------------------------------------------------------------------------*/
byte Test47_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndMsNotes) Test8_Step1_1();

	{
		Byte s;					// Status of operation
		StaffInfos StaffInfos;
		Byte StaffSrc = (Byte)Infos1;	// Infos1 is the source position.
		Byte StaffDst = (Byte)Infos2;	// Infos2 is the destination position.
		/* Get the staff informations */
		s = GetStaffInfos( 	hWndMsNotes,/* Handle of MsNotes window	*/
							StaffSrc,	/* Position of the staff	*/
							INFOS_STAFF,/* Id of infos to retrieve	*/ 
							&StaffInfos	/* Pointer on infos to get	*/
						 );
		/* prepare the result message */
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Get staff informations, status:%d, %s", s,TabErrMsg[s]);
		iResBuff = strlen(ResultBuff);
		if (s) return s;
		
		/* Insertion of a new Staff */
		s = InsertStaff( 	hWndMsNotes,/* Handle of MsNotes window			*/
							&StaffInfos,/* Pointer on staff informations	*/
							StaffDst,	/* Position of the staff to	insert	*/
							True		/* Refresh now						*/
						);
		/* prepare the result message */
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Insert staff, status:%d, %s", s,TabErrMsg[s]);

		return s;
	}
}

/*----------------------------------------------------------------------------
Test 48: step 1/1: 

This test remove a staff. 

Choose the index values of the staff to remove with the spin Infos 1 and then 
en press the push button to execute and see the status in the result window.
-----------------------------------------------------------------------------*/
byte Test48_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndMsNotes) Test8_Step1_1();

	{
		Byte s;							// Status of operation
		Byte Staff = (Byte)Infos1;		// Infos1 is the staff position.
		/* Remove of a  Staff */
		s = RemoveStaff( 	hWndMsNotes,/* Handle of MsNotes window			*/
							Staff,		/* Position of the staff to	insert	*/
							True		/* Refresh now						*/
						);
		/* prepare the result message */
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Remove staff, status:%d, %s", s,TabErrMsg[s]);
		return s;
	}
}

/*----------------------------------------------------------------------------
Test 49: step 1/1: 

This test move a  staff. 

Choose the current position and new position of the staff with the spin 
Infos 1 and 2 then press the push button to execute and see the status in
the result window.
-----------------------------------------------------------------------------*/
byte Test49_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndMsNotes) Test8_Step1_1();

	{
		Byte s;					// Status of operation
		Byte CurPos = (Byte)Infos1;	// Infos1 is the current position.
		Byte NewPos = (Byte)Infos2;	// Infos2 is the new position.
		/* Remove of a  Staff */
		s = MoveStaff( 	hWndMsNotes,/* Handle of MsNotes window				*/
							CurPos,		/* Current position of the staff	*/
							NewPos,		/* New position of the staff		*/
							True		/* Refresh now						*/
						);
		/* prepare the result message */
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Move a staff, status:%d, %s", s,TabErrMsg[s]);
		return s;
	}
}