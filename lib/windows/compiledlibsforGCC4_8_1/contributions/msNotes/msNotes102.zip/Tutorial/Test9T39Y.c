/******************************************************************************
 Test9ToYY.c
 Email: Jean-Jacques.CERESA@enac.fr
******************************************************************************/


#define STRICT
#define __Windows__		// Application Windows 
#include "Tutorial.h"


/*=============================================================================
	The following tests get and set window informations by the use of
	GetMsNotesInfos() and SetMsNotesInfos() APIs. 
=============================================================================*/

/*----------------------------------------------------------------------------
Test 9: step 1/1:

This test get the length of the window title LEN_TITLE_MSN.
Now the application know the lenght of the buffer need to get the title 
of the window.

If the result is successful, the value of the lenght is displayed in the
result window.
-----------------------------------------------------------------------------*/
byte Test9_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndMsNotes) Test8_Step1_1();

	/*-------------------------------------------------------------------
	 Get the lenght of title 
	--------------------------------------------------------------------*/
	{
		Byte LenTitle;		// Infos
		Byte s;				// Status of operation
		s = GetMsNotesInfos(hWndMsNotes,	/* Handle of MsNotes window	*/
							LEN_TITLE_MSN,	/* Id of the infos to get	*/
							&LenTitle		/* address of the infos		*/
							);
		/* prepare the result message */
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Get lenght of title, status:%d, %s", s,TabErrMsg[s]);
		if (!s)
		{
			iResBuff = strlen(ResultBuff);
			wsprintf( &ResultBuff[iResBuff],"\r\n\t-Lenght of title:%d",
					LenTitle);
		}
		return s;
	}
}

/*----------------------------------------------------------------------------
Test 10: step 1/1: 

This test set the length of the window title LEN_TITLE_MSN to  8 bytes.
This is usefull to limit the length of the title to the lenght of the buffer
used to get the window title.
Now a maximum of 8 bytes of the title will be received when getting the
window title.
-----------------------------------------------------------------------------*/
byte Test10_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndMsNotes) Test8_Step1_1();

	/*-------------------------------------------------------------------
	 Set the lenght of title 
	--------------------------------------------------------------------*/
	{
		Byte LenTitle = 8;	// Infos
		Byte s;				// Status of operation
		s = SetMsNotesInfos(hWndMsNotes,	/* Handle of MsNotes window	*/
							LEN_TITLE_MSN,	/* Id of the infos to set	*/
							LenTitle,		/* Value to set				*/
							0				/* Do nothing				*/ 
							);
		/* prepare the result message */
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Set lenght of title, status:%d, %s", s,TabErrMsg[s]);
		iResBuff = strlen(ResultBuff);
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Lenght of title has been set to:%d bytes.", LenTitle);

		return s;
	}
}

/*----------------------------------------------------------------------------
Test 11: step 1/1: 

This test get the window title TITLE_MSN.

If the result is successful, the title is displayed in the
result window.
-----------------------------------------------------------------------------*/
byte Test11_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndMsNotes) Test8_Step1_1();

	/*-------------------------------------------------------------------
	 Get the window title 
	--------------------------------------------------------------------*/
	{
		Byte Title [100];	// Buffer to get the title
		Byte s;				// Status of operation
		s = GetMsNotesInfos(hWndMsNotes,/* Handle of MsNotes window	*/
							TITLE_MSN,	/* Id of the infos to get	*/
							Title		/* Address of the buffer infos	*/
							);
		/* prepare the result message */
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Get title, status:%d, %s", s,TabErrMsg[s]);
		if (!s)
		{
			iResBuff = strlen(ResultBuff);
			wsprintf( &ResultBuff[iResBuff],"\r\n\t-Title is:%s", Title);
		}
		return s;
	}
}

/*----------------------------------------------------------------------------
Test 12: step 1/1: 

This test set window title TITLE_MSN to: This is a new title.

If the result is successful, the new title is display in the caption bar 
if it exits.
-----------------------------------------------------------------------------*/
byte Test12_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndMsNotes) Test8_Step1_1();

	/*-------------------------------------------------------------------
	 Set the window title 
	--------------------------------------------------------------------*/
	{
		Byte Title []="This is a new title"; // Title to set
		Byte s;				// Status of operation
		s = SetMsNotesInfos(hWndMsNotes,	/* Handle of MsNotes window	*/
							TITLE_MSN,		/* Id of the infos to set	*/
							(long)Title,	/* Address of value to set	*/
							0				/* Do nothing				*/ 
							);
		/* prepare the result message */
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Set title, status:%d, %s", s,TabErrMsg[s]);
		return s;
	}
}

/*----------------------------------------------------------------------------
Test 13: step 1/1: 

This test get the window style STYLE_MSN.

If the result is successful, the style is displayed in the
result window.
-----------------------------------------------------------------------------*/
byte Test13_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndMsNotes) Test8_Step1_1();

	/*-------------------------------------------------------------------
	 Get the window style 
	--------------------------------------------------------------------*/
	{
		Byte s;				// Status of operation
		Word Style;			// Buffer to get the title
		s = GetMsNotesInfos(hWndMsNotes,/* Handle of MsNotes window	*/
							STYLE_MSN,	/* Id of the infos to get	*/
							&Style		/* Address of the buffer value to get*/
							);
		/* prepare the result message */
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Get style, status:%d, %s", s,TabErrMsg[s]);
		
		if (!s)
		{
			strcat(ResultBuff,"\r\n\t-Style is:\t");
			if (!Style)				strcat(ResultBuff,"0.");
			if (IsBorder(Style))	strcat(ResultBuff,"S_BORDER, ");
			if (IsStatusBar(Style))	strcat(ResultBuff,"S_STATUS, ");
			if (IsTitle(Style))		strcat(ResultBuff,"S_TITLE, ");
			if (IsVarSize(Style))	strcat(ResultBuff,"S_VAR_SIZE,");
			if (IsHscroll(Style))	strcat(ResultBuff,"\r\n\t\tS_HSCROLL, ");
			if (IsVscroll(Style))	strcat(ResultBuff,"S_VSCROLL, ");
			if (IsEdit(Style))		strcat(ResultBuff,"S_EDIT, ");
			if (IsMenu(Style))		strcat(ResultBuff,"S_MENU, ");
		}
		return s;
	}
}

/*----------------------------------------------------------------------------
Test 14: step 1/1: 

This test try to set window style STYLE_MSN to: 0.
-----------------------------------------------------------------------------*/
byte Test14_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndMsNotes) Test8_Step1_1();

	/*-------------------------------------------------------------------
	 Set the window style 
	--------------------------------------------------------------------*/
	{
		Byte Style = 0;		// Style to set
		Byte s;				// Status of operation
		s = SetMsNotesInfos(hWndMsNotes,	/* Handle of MsNotes window	*/
							STYLE_MSN,		/* Id of the infos to set	*/
							Style,			/* value to set	*/
							0				/* Do nothing				*/ 
							);
		/* prepare the result message */
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Set style, status:%d, %s",	s,TabErrMsg[s]);
		return s;
	}
}

/*----------------------------------------------------------------------------
Test 15: step 1/1: 

  This test get the window position : XY_MSN
-----------------------------------------------------------------------------*/
byte Test15_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndMsNotes) Test8_Step1_1();
	/*-------------------------------------------------------------------
	 Get the window position 
	--------------------------------------------------------------------*/
	{
		Byte s;				// Status of operation
		long xyPos;
		s = GetMsNotesInfos(hWndMsNotes,/* Handle of MsNotes window	*/
							XY_MSN,		/* Id of the infos to get	*/
							&xyPos		/* Address of the buffer value to get*/
							);
		/* prepare the result message */
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Get X and Y position, status:%d, %s", s,TabErrMsg[s]);
		iResBuff = strlen(ResultBuff);
		if (!s) wsprintf( &ResultBuff[iResBuff],"\r\n\t-X:%d Y:%d",
							XposXY_MSN(xyPos), YposXY_MSN(xyPos));
		return s;
	}
}

/*----------------------------------------------------------------------------
Test 16: step 1/1: 

  This test set the window position : XY_MSN
  Choose the X and Y values with the spin control 1 and 2 then press the 
  push button to execute and see the status in the result window.

-----------------------------------------------------------------------------*/
byte Test16_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndMsNotes) Test8_Step1_1();
	/*-------------------------------------------------------------------
	 Set the window position 
	--------------------------------------------------------------------*/
	{
		Byte s;				// Status of operation
		long xyPos;
		Word xPos = (Word)Infos1;	// Infos1 is X
		Word yPos = (Word)Infos2;	// Infos2 is Y
		xyPos = MakeXY_MSN(xPos,yPos);
		s = SetMsNotesInfos(hWndMsNotes,	/* Handle of MsNotes window	*/
							XY_MSN,			/* Id of the infos to set	*/
							xyPos,			/* value to set	*/
							0				/* Do nothing				*/ 
							);
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Set X and Y position, status:%d, %s", s,TabErrMsg[s]);
		return s;
	}
}

/*----------------------------------------------------------------------------
Test 17: step 1/1: 

  This test get the window size : SIZE_MSN
-----------------------------------------------------------------------------*/
byte Test17_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndMsNotes) Test8_Step1_1();
	/*-------------------------------------------------------------------
	 Get the window size 
	--------------------------------------------------------------------*/
	{
		Byte s;				// Status of operation
		long Size;
		s = GetMsNotesInfos(hWndMsNotes,/* Handle of MsNotes window	*/
							SIZE_MSN,	/* Id of the infos to get	*/
							&Size		/* Address of the buffer value to get*/
							);
		/* prepare the result message */
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Get size, status:%d, %s", s,TabErrMsg[s]);
		iResBuff = strlen(ResultBuff);
		if (!s)	wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Width:%d Height:%d",WidthSIZE_MSN(Size), 
										HeightSIZE_MSN(Size));
		return s;
	}
}

/*----------------------------------------------------------------------------
Test 18: step 1/1: 

  This test set the window position : SIZE_MSN
  Choose the Width and Height values with the spin control 1 and 2 then press
  the push button to execute and see the status in the result window.
-----------------------------------------------------------------------------*/
byte Test18_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndMsNotes) Test8_Step1_1();
	/*-------------------------------------------------------------------
	 Set the window size 
	--------------------------------------------------------------------*/
	{
		Byte s;				// Status of operation
		long Size;
		Word Width =  (Word)Infos1;	// Infos1 is width
		Word Height = (Word)Infos2;	// Infos2 is height
		Size = MakeSIZE_MSN( Width, Height );
		s = SetMsNotesInfos(hWndMsNotes,	/* Handle of MsNotes window	*/
							SIZE_MSN,		/* Id of the infos to set	*/
							Size,			/* value to set	*/
							0				/* Do nothing				*/ 
							);
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Set size, status:%d, %s", s,TabErrMsg[s]);
		return s;
	}
}

/*-----------------------------------------------------------------------------
Test 19: step 1/1: 

  This test get the numerator NUM_MSN and denominator DENO_MSN of meter key.
-----------------------------------------------------------------------------*/
byte Test19_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndMsNotes) Test8_Step1_1();
	/*-------------------------------------------------------------------
	 Get the Numerator and Denominator
	--------------------------------------------------------------------*/
	{
		Byte s;				// Status of operation
		Byte Num;
		Byte Deno;
		/* get the numerator */
		s = GetMsNotesInfos(hWndMsNotes,	/* Handle of MsNotes window		*/
							NUM_MSN,		/* Id of the infos to get		*/
							&Num	/* Address of the buffer value to get	*/
							);
		/* prepare the result status message */
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Get the numerator, status:%d, %s",	s,TabErrMsg[s]);
		iResBuff = strlen(ResultBuff);
		if (!s) wsprintf( &ResultBuff[iResBuff],"\r\n\t-Numerator:%d",Num);
		iResBuff = strlen(ResultBuff);
		/* get the denominator */
		s = GetMsNotesInfos(hWndMsNotes,	/* Handle of MsNotes window		*/
							DENO_MSN,		/* Id of the infos to get		*/
							&Deno	/* Address of the buffer value to get	*/
							);
		/* prepare the result status message */
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Get the denominator, status:%d, %s",s,TabErrMsg[s]);
		iResBuff = strlen(ResultBuff);
		/* prepare the result message */
		if (s) wsprintf( &ResultBuff[iResBuff],"\r\n\t-Denominator:%d",Deno);
		return s;
	}
}

/*-----------------------------------------------------------------------------
Test 20: step 1/1: 

  This test set the numerator NUM_MSN and denominator DENO_MSN of meter key.
  Choose the Numerator and Denominator values with the spin control 1 and 2
  then press the push button to execute and see the status in the result
  window.
-----------------------------------------------------------------------------*/
byte Test20_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndMsNotes) Test8_Step1_1();
	/*-------------------------------------------------------------------
	 Set the Numerator and Denominator 
	--------------------------------------------------------------------*/
	{
		Byte s;						// Status of operation
		Byte Num = (Byte)Infos1;	// Infos1 is the numerator
		Byte Deno = (Byte)Infos2;	// Infos2 is the denominator
		
		/* set the numerator without refresh the window */
		s = SetMsNotesInfos(hWndMsNotes,	/* Handle of MsNotes window	*/
							NUM_MSN,		/* Id of the infos to set	*/
							Num,			/* value to set	*/
							0				/* Don't update now			*/ 
							);
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Set numerator, status:%d, %s",	s,TabErrMsg[s]);
		iResBuff = strlen(ResultBuff);

		/* set the denominator and refresh the window */
		s = SetMsNotesInfos(hWndMsNotes,	/* Handle of MsNotes window	*/
							DENO_MSN,		/* Id of the infos to set	*/
							Deno,			/* value to set	*/
							True			/* Update now			*/ 
							);
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Set denominator, status:%d, %s", s,TabErrMsg[s]);
		return s;
	}
}

/*-----------------------------------------------------------------------------
Test 21: step 1/1: 

  This test get the key signature KEY_SIGN_MSN.
-----------------------------------------------------------------------------*/
byte Test21_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndMsNotes) Test8_Step1_1();
	/*-------------------------------------------------------------------
	 Get the key signature
	--------------------------------------------------------------------*/
	{
		Byte s;				// Status of operation
		Byte iTone;
		/* Get the key signature */
		s = GetMsNotesInfos(hWndMsNotes,	/* Handle of MsNotes window	*/
							KEY_SIGN_MSN,	/* Id of the infos to get	*/
							&iTone	/* Address of the buffer value to get*/
							);
		/* prepare the result message */
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Get key signature status:%d, %s", s,TabErrMsg[s]);
		iResBuff = strlen(ResultBuff);
		if (!s)	wsprintf( &ResultBuff[iResBuff],"\r\n\t-key signature:%d",
							iTone);
		return s;
	}
}

/*----------------------------------------------------------------------------
Test 22: step 1/1: 

  This test set the key signature KEY_SIGN_MSN.
  Choose the key signature value with the spin control 1 then press the
  push button to execute and see the status in the result window.
-----------------------------------------------------------------------------*/
byte Test22_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndMsNotes) Test8_Step1_1();
	/*-------------------------------------------------------------------
	 Set the key signature and update the window. 
	--------------------------------------------------------------------*/
	{
		Byte s;						// Status of operation
		Byte iTone = (Byte)Infos1;	// Infos1 is the key signature.
		/* set the key signature and refresh the window */
		s = SetMsNotesInfos(hWndMsNotes,	/* Handle of MsNotes window	*/
							KEY_SIGN_MSN,	/* Id of the infos to set	*/
							iTone,			/* value to set				*/
							True			/* Update now				*/ 
							);
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Set key signature status:%d, %s", s,TabErrMsg[s]);
		return s;
	}
}

/*-----------------------------------------------------------------------------
Test 23: step 1/1: 

  This test get the numerator NUM_MSN ,denominator DENO_MSN, and key signature
  in one call. These 3 informations are identified by SIGN_MSN.
-----------------------------------------------------------------------------*/
byte Test23_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndMsNotes) Test8_Step1_1();
	/*-------------------------------------------------------------------
	 Get the Numerator, Denominator and Key signature
	--------------------------------------------------------------------*/
	{
		Byte s;				// Status of operation
		long ToneDenoNum;
		s = GetMsNotesInfos(hWndMsNotes,/* Handle of MsNotes window	*/
							SIGN_MSN,	/* Id of the infos to get	*/
							&ToneDenoNum/* Address of the buffer value to get*/
							);
		/* prepare the result message */
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Get Numerator,Denominator and key signature, status:%d, %s",
										s,TabErrMsg[s]);
		iResBuff = strlen(ResultBuff);
		if (!s)	
		{
			Byte Num = NumSIGN_MSN(ToneDenoNum);
			Byte Deno = DenoSIGN_MSN(ToneDenoNum);
			Byte iTone = iToneSIGN_MSN(ToneDenoNum);
			wsprintf( &ResultBuff[iResBuff],
				"\r\n\t-Numerator:%d Denominator:%d KeySignature:%d",
				Num,Deno,iTone);
		}
		return s;
	}
}

/*-----------------------------------------------------------------------------
Test 24: step 1/1: 

 This test set the numerator,denominator, and key signature 
 in one call. These 3 informations are identified by SIGN_MSN.
 Choose the Numerator, Denominator and Key signature values with the spin
 control 1 , 2 and 3 then press the push button to execute and see the status
 in the result window.
-----------------------------------------------------------------------------*/
byte Test24_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndMsNotes) Test8_Step1_1();
	/*-------------------------------------------------------------------
	 Set the Numerator, Denominator and Key signature and update the window
	--------------------------------------------------------------------*/
	{
		Byte s;						// Status of operation
		Byte Num = (Byte)Infos1;	// Infos1 is the numerator.
		Byte Deno = (Byte)Infos2;	// Infos2 is the denominator.
		Byte iTone = (Byte)Infos3;	// Infos3 is the key signature.
		long ToneDenoNum = MakeSIGN_MSN(Num,Deno,iTone);
		/* set the key signature and refresh the window */
		s = SetMsNotesInfos(hWndMsNotes,	/* Handle of MsNotes window	*/
							SIGN_MSN,		/* Id of the infos to set	*/
							ToneDenoNum,			/* value to set				*/
							True			/* Update now				*/ 
							);
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Set Numerator,Denominator and key signature, status:%d, %s",
										s,TabErrMsg[s]);
		return s;
	}
}

/*-----------------------------------------------------------------------------
Test 25: step 1/1: 

  This test get the time division in PPQN (Part per Quarter Note): PPQN_MSN.
-----------------------------------------------------------------------------*/
byte Test25_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndMsNotes) Test8_Step1_1();
	/*-------------------------------------------------------------------
	 Get the time division
	--------------------------------------------------------------------*/
	{
		Byte s;				// Status of operation
		Word TimePPQN;
		s = GetMsNotesInfos(hWndMsNotes,/* Handle of MsNotes window	*/
							PPQN_MSN,	/* Id of the infos to get	*/
							&TimePPQN/* Address of the buffer value to get*/
							);
		/* prepare the result message */
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Get time division, status:%d, %s", s,TabErrMsg[s]);
		iResBuff = strlen(ResultBuff);
		if (!s)	
		{
			wsprintf(&ResultBuff[iResBuff],"\r\n\t-Time division:%d",TimePPQN);
		}
		return s;
	}
}

/*-----------------------------------------------------------------------------
Test 26: step 1/1: 

 This test set the time division in PPQN (Part per Quarter Note): PPQN_MSN.
 Choose the time division value with the spin control 1 then press the push
 button to execute and see the status in the result window.
-----------------------------------------------------------------------------*/
byte Test26_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndMsNotes) Test8_Step1_1();
	/*-------------------------------------------------------------------
	 Set the time division and refresh the window.
	--------------------------------------------------------------------*/
	{
		Byte s;							// Status of operation
		Word TimePPQN = (Word)Infos1;	// Infos1 is the time division
		s = SetMsNotesInfos(hWndMsNotes,	/* Handle of MsNotes window	*/
							PPQN_MSN,		/* Id of the infos to set	*/
							TimePPQN,		/* value to set				*/
							True			/* Update now				*/ 
							);
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Set time division, status:%d, %s", s,TabErrMsg[s]);
		return s;
	}
}

/*-----------------------------------------------------------------------------
Test 27: step 1/1: 

  This test get the resolution: RES_MSN.
-----------------------------------------------------------------------------*/
byte Test27_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndMsNotes) Test8_Step1_1();
	/*-------------------------------------------------------------------
	 Get the resolution
	--------------------------------------------------------------------*/
	{
		Byte s;				// Status of operation
		Byte Res;
		s = GetMsNotesInfos(hWndMsNotes,/* Handle of MsNotes window	*/
							RES_MSN,	/* Id of the infos to get	*/
							&Res		/* Address of the buffer value to get*/
							);
		/* prepare the result message */
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Get the resolution, status:%d, %s", s,TabErrMsg[s]);
		iResBuff = strlen(ResultBuff);
		if (!s)	
		{
			wsprintf(&ResultBuff[iResBuff],"\r\n\t-Resolution:%d",Res);
		}
		return s;
	}
}

/*-----------------------------------------------------------------------------
Test 28: step 1/1: 

 This test set the resolution: RES_MSN.
 Choose the resolution value with the spin control 1 then press the push button
 to execute and see the status in the result window.
-----------------------------------------------------------------------------*/
byte Test28_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndMsNotes) Test8_Step1_1();
	/*-------------------------------------------------------------------
	 Set the resolution and refresh the window.
	--------------------------------------------------------------------*/
	{
		Byte s;						// Status of operation
		Byte Res = (Byte)Infos1;	// Infos1 is the resolution
		s = SetMsNotesInfos(hWndMsNotes,	/* Handle of MsNotes window	*/
							RES_MSN,		/* Id of the infos to set	*/
							Res,			/* value to set				*/
							True			/* Update now				*/ 
							);
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Set resolution, status:%d, %s", s,TabErrMsg[s]);
		return s;
	}
}

/*-----------------------------------------------------------------------------
Test 29: step 1/1: 

 This test get the Flags FLAGS_MSN and the date GUIDE_DATE_MSN of the guide
 reader.
-----------------------------------------------------------------------------*/
byte Test29_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndMsNotes) Test8_Step1_1();
	/*-------------------------------------------------------------------
	 Get Flags and the guide reader date
	--------------------------------------------------------------------*/
	{
		Byte s;				// Status of operation
		Byte Flags;
		long GuideDate;
		/* Get the flags of a windows */
		s = GetMsNotesInfos(hWndMsNotes,	/* Handle of MsNotes window	*/
							FLAGS_MSN,	/* Id of the infos to get	*/
							&Flags	/* Address of the buffer value to get*/
							);
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Get the flags , status:%d, %s", s,TabErrMsg[s]);
		if (!s)
		{
			strcat(ResultBuff,"\r\n\t-Flags are:\t");
			if (! Flags )			strcat(ResultBuff,"0.");
			if (IsGridDate(Flags))	strcat(ResultBuff,"GRID_DATE,");
			if (IsGuideReader(Flags))	strcat(ResultBuff," GUIDE_READER.");
		}
		iResBuff = strlen(ResultBuff);
		/* Get the  guide date */
		s = GetMsNotesInfos(hWndMsNotes,	/* Handle of MsNotes window	*/
							GUIDE_DATE_MSN,	/* Id of the infos to get	*/
							&GuideDate	/* Address of the buffer value to get*/
							);
		/* prepare the result message */
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Get the guide date , status:%d, %s", s,TabErrMsg[s]);
		iResBuff = strlen(ResultBuff);
		if (!s)	
		{
			wsprintf(&ResultBuff[iResBuff],"\r\n\t-Guide date:%d",GuideDate);
		}
		return s;
	}
}

/*-----------------------------------------------------------------------------
Test 30: step 1/1: 

 This test set the date of the guide reader: GUIDE_DATE_MSN.
 Choose the guide date value with the spin control 1 then press the push button
 to execute and see the status in the result window.
-----------------------------------------------------------------------------*/
byte Test30_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndMsNotes) Test8_Step1_1();
	/*-------------------------------------------------------------------
	 Set the guide reader date.
	--------------------------------------------------------------------*/
	{
		Byte s;						// Status of operation
		Byte Flags = GUIDE_READER;	// Flags to enable the display of the guide.
		long GuideDate = Infos1;	// Infos1 is the date
		/* Set the flag to enable the guide reader */
		s = SetMsNotesInfos(hWndMsNotes,	/* Handle of MsNotes window	*/
							FLAGS_MSN,		/* Id of the infos to set	*/
							Flags,			/* value to set				*/
							0				/* Do nothing				*/ 
							);
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Set Flags, status:%d, %s", s,TabErrMsg[s]);
		iResBuff = strlen(ResultBuff);
		/* Set the date of the guider */
		s = SetMsNotesInfos(hWndMsNotes,	/* Handle of MsNotes window	*/
							GUIDE_DATE_MSN,	/* Id of the infos to set	*/
							GuideDate,		/* value to set				*/
							0				/* Do nothing				*/ 
							);
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Set guide date, status:%d, %s", s,TabErrMsg[s]);
		return s;
	}
}

/*-----------------------------------------------------------------------------
Test 31: step 1/1: 

 This test get the Bar and Beat of the BBU pointer: BBU_MSN.
 This value is the position (in beats) of the horizontal scroll bar when
 it exist.
-----------------------------------------------------------------------------*/
byte Test31_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndMsNotes) Test8_Step1_1();
	/*-------------------------------------------------------------------
	 Get the BBU pointer
	--------------------------------------------------------------------*/
	{
		Byte s;				// Status of operation
		long BarBeat;
		s = GetMsNotesInfos(hWndMsNotes,/* Handle of MsNotes window	*/
							BBU_MSN,	/* Id of the infos to get	*/
							&BarBeat	/* Address of the buffer value to get*/
							);
		/* prepare the result message */
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Get Bar and Beat, status:%d, %s", s,TabErrMsg[s]);
		iResBuff = strlen(ResultBuff);
		if (!s) wsprintf( &ResultBuff[iResBuff],"\r\n\t-Bar:%d Beat:%d",
//							HiWordInfos(BarBeat),LoWordInfos(BarBeat) );
							BarBBU_MSN(BarBeat),BeatBBU_MSN(BarBeat) );
		return s;
	}
}

/*-----------------------------------------------------------------------------
Test 32: step 1/1: 

 This test set the Bar and Beat of the BBU pointer: BBU_MSN.
 Choose the bar and beat values with the spin control 1 and 2 then press the
 push button to execute and see the status in the result window.
-----------------------------------------------------------------------------*/
byte Test32_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndMsNotes) Test8_Step1_1();
	/*-------------------------------------------------------------------
	 Set the BBU pointer
	--------------------------------------------------------------------*/
	{
		Byte s;				// Status of operation
		long BarBeat;
		Word Bar =  (Word)Infos1;	// Infos1 is the bar value(0 based)
		Word Beat = (Word)Infos2;	// Infos2 is the beat value(0 based)
		BarBeat = MakeBBU_MSN(Beat,Bar);
		s = SetMsNotesInfos(hWndMsNotes,	/* Handle of MsNotes window	*/
							BBU_MSN,		/* Id of the infos to set	*/
							BarBeat,		/* value to set	*/
							True			/* Refresh now				*/ 
							);
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Set Bar and Beat, status:%d, %s", s,TabErrMsg[s]);
		return s;
	}
}

/*-----------------------------------------------------------------------------
Test 33: step 1/1: 

 This test get the index of staff at the top of window: STAFFUP_MSN.
 This value is the position of the vertical scroll bar when it exist.
-----------------------------------------------------------------------------*/
byte Test33_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndMsNotes) Test8_Step1_1();
	/*-------------------------------------------------------------------
	 Get the staff index
	--------------------------------------------------------------------*/
	{
		Byte s;				// Status of operation
		Byte StaffUp;
		s = GetMsNotesInfos(hWndMsNotes,	/* Handle of MsNotes window	*/
							STAFFUP_MSN,	/* Id of the infos to get	*/
							&StaffUp	/* Address of the buffer value to get*/
							);
		/* prepare the result message */
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Get staff up, status:%d, %s", s,TabErrMsg[s]);
		iResBuff = strlen(ResultBuff);
		if (!s) wsprintf( &ResultBuff[iResBuff],"\r\n\t-Staff up:%d",
							StaffUp );
		return s;
	}
}

/*-----------------------------------------------------------------------------
Test 34: step 1/1: 

 This test set the index of staff at the top of window: STAFFUP_MSN.
 Choose the index value with the spin control 1 then press the push button
 to execute and see the status in the result window.
-----------------------------------------------------------------------------*/
byte Test34_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndMsNotes) Test8_Step1_1();
	/*-------------------------------------------------------------------
	 Set the staff index.
	--------------------------------------------------------------------*/
	{
		Byte s;							// Status of operation
		Byte StaffUp = (Byte)Infos1;	// Infos1 is the staff up
		s = SetMsNotesInfos(hWndMsNotes,	/* Handle of MsNotes window	*/
							STAFFUP_MSN,	/* Id of the infos to set	*/
							StaffUp,		/* value to set	*/
							True			/* Refresh now				*/ 
							);
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Set staff up, status:%d, %s", s,TabErrMsg[s]);
		return s;
	}
}

/*-----------------------------------------------------------------------------
Test 35: step 1/1: 

 This test get the number of staffs inside the window: NBR_STAFF_MSN.
-----------------------------------------------------------------------------*/
byte Test35_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndMsNotes) Test8_Step1_1();
	/*-------------------------------------------------------------------
	 Get the number of staffs
	--------------------------------------------------------------------*/
	{
		Byte s;				// Status of operation
		Byte NbrStaff;
		s = GetMsNotesInfos(hWndMsNotes,	/* Handle of MsNotes window	*/
							NBR_STAFF_MSN,	/* Id of the infos to get	*/
							&NbrStaff	/* Address of the buffer value to get*/
							);
		/* prepare the result message */
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Get number of staffs, status:%d, %s", s,TabErrMsg[s]);
		iResBuff = strlen(ResultBuff);
		if (!s) wsprintf( &ResultBuff[iResBuff],"\r\n\t-Number of staffs:%d",
							NbrStaff );
		return s;
	}
}

/*-----------------------------------------------------------------------------
Test 36: step 1/1: 

 This test try to set the number of staffs inside the window: NBR_STAFF_MSN.
 Choose the index value with the spin control 1 then press the push button
 to execute and see the status in the result window.
 
 This test will fail because the number of staff cannot be changed directly.
 The internal number of staff is updated when InsertStaff() and RemoveStaff()
 APIs are used.
-----------------------------------------------------------------------------*/
byte Test36_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndMsNotes) Test8_Step1_1();
	/*-------------------------------------------------------------------
	 try to set the number of staffs
	--------------------------------------------------------------------*/
	{
		Byte s;							// Status of operation
		Byte NbrStaff = (Byte)Infos1;	// Infos1 is the number of staffs
		s = SetMsNotesInfos(hWndMsNotes,	/* Handle of MsNotes window	*/
							NBR_STAFF_MSN,	/* Id of the infos to set	*/
							NbrStaff,		/* value to set				*/
							0				/* do nothing				*/ 
							);
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Set number of staffs, status:%d, %s", s,TabErrMsg[s]);
		return s;
	}
}

/*-----------------------------------------------------------------------------
Test 37: step 1/1: 

 This test get the number maximun of bars displayed (MAX_BAR_MSN) and the
 number maximum of staffs displayed (MAX_STAFF_MSN).
-----------------------------------------------------------------------------*/
byte Test37_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndMsNotes) Test8_Step1_1();
	/*-------------------------------------------------------------------
	 Get the number maximum of bars and the number maximum of staff.
	--------------------------------------------------------------------*/
	{
		Byte s;				// Status of operation
		Byte NbrMaxBar;
		Byte NbrMaxStaff;
		/* Get the number maximum of bars */
		s = GetMsNotesInfos(hWndMsNotes,	/* Handle of MsNotes window	*/
							MAX_BAR_MSN,	/* Id of the infos to get	*/
							&NbrMaxBar	/* Address of the buffer value to get*/
							);
		/* prepare the result message */
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Get number max of bars, status:%d, %s", s,TabErrMsg[s]);
		iResBuff = strlen(ResultBuff);
		if (!s) wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Number maximum of bars:%d", NbrMaxBar );
		iResBuff = strlen(ResultBuff);
		
		/* Get the number maximum of staffs */
		s = GetMsNotesInfos(hWndMsNotes,	/* Handle of MsNotes window	*/
							MAX_STAFF_MSN,	/* Id of the infos to get	*/
							&NbrMaxStaff	/* Address of the buffer value to get*/
							);
		/* prepare the result message */
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Get number max of staffs, status:%d, %s", s,TabErrMsg[s]);
		iResBuff = strlen(ResultBuff);
		if (!s) wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Number maximum of staffs:%d", NbrMaxStaff );
		return s;
	}
}
 
/*-----------------------------------------------------------------------------
Test 38: step 1/1: 

 This test set the number maximun of bars displayed (MAX_BAR_MSN) and the
 number maximum of staffs displayed (MAX_STAFF_MSN).
 Choose the  nbr. bars and nbr. staffs values of with the spin control 1 and 2 
 then press the push button to execute and see the status in the result window.
-----------------------------------------------------------------------------*/
byte Test38_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndMsNotes) Test8_Step1_1();
	/*-------------------------------------------------------------------
	 Set the number maximum of bar and the number maximum of staff.
	--------------------------------------------------------------------*/
	{
		Byte s;				// Status of operation
		Byte NbrMaxBar =   (Byte)Infos1;	// Infos1 is the nbr. of bars
		Byte NbrMaxStaff = (Byte)Infos2;	// Infos2 is the nbr. of staffs;
		/* set the numerator without refresh the window */
		s = SetMsNotesInfos(hWndMsNotes,	/* Handle of MsNotes window	*/
							MAX_BAR_MSN,	/* Id of the infos to set	*/
							NbrMaxBar,		/* value to set				*/
							0				/* Don't update now			*/ 
							);
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Set number max of bars, status:%d, %s", s,TabErrMsg[s]);
		iResBuff = strlen(ResultBuff);

		/* set the denominator and refresh the window */
		s = SetMsNotesInfos(hWndMsNotes,	/* Handle of MsNotes window	*/
							MAX_STAFF_MSN,	/* Id of the infos to set	*/
							NbrMaxStaff,	/* value to set				*/
							True			/* Update now				*/ 
							);
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Set number max of staffs, status:%d, %s", s,TabErrMsg[s]);
		return s;
	}
}

/*-----------------------------------------------------------------------------
Test 39: step 1/1: 

 This test get and set the whole window information INFOS_MSN
	1) First the  test get the window informations,
	2) The iTone, yPos field are changed.
	3) The new window informations structure is set.
-----------------------------------------------------------------------------*/
byte Test39_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndMsNotes) Test8_Step1_1();
	/*-------------------------------------------------------------------
		Get the window informations.
		Change the iTone and xPos.
		Set the window informations.
	--------------------------------------------------------------------*/
	{
		Byte s;				// Status of operation
		MsNotesInfos WndInfos;
		/* Get the window informations.  */
		s = GetMsNotesInfos(hWndMsNotes,/* Handle of MsNotes window	*/
							INFOS_MSN,	/* Id of the infos to get	*/
							&WndInfos	/* Address of the buffer value to get*/
							);
		/* prepare the result message */
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Get window informations, status:%d, %s", s,TabErrMsg[s]);
		iResBuff = strlen(ResultBuff);
		/* Change the iTone and xPos. */
		WndInfos.iTone = KEY_Gf;	// Gb key signature.
		WndInfos.xPos +=10;			// Shift the X position.
		/* Set the new window informations.  */
		s = SetMsNotesInfos(hWndMsNotes,		/* Handle of MsNotes window	*/
							INFOS_MSN,			/* Id of the infos to set	*/
							(long)&WndInfos,	/* value to set				*/
							0					/* Do nothing				*/ 
							);
		/* prepare the result message */
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Set window informations, status:%d, %s", s,TabErrMsg[s]);
		return s;
	}
}
