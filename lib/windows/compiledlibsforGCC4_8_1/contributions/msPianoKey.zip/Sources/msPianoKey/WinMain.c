/*****************************************************************************
 Module: winmain.c           

 e-mail: Jean-Jacques.CERESA@enac.fr	
******************************************************************************/

#define STRICT
#define __Windows__		// Windows application
#include "MsPianoKey.h"

/*-----------------------------------------------------------------------------
 Globals variables 
-----------------------------------------------------------------------------*/
char NomClasse[]="CS_MSPIANOKEY";	// Class name.
char Title[]="msPianoKey";			// Window title.


HINSTANCE hgInstance;

/*****************************************************************************
 This fonction register the class.
******************************************************************************/
void RegClass (char NomClasse[], HINSTANCE hInstance,WNDPROC PtrProc,int Brush)
	{ 
		WNDCLASS    wndclass ;
		// Window style.
		wndclass.style        = CS_HREDRAW|CS_VREDRAW|CS_CLASSDC;
		wndclass.lpfnWndProc  = PtrProc;
		// User extra bytes in the class structure.
		wndclass.cbClsExtra   = 0;
		// User extra bytes in the window structure.
 		wndclass.cbWndExtra   = 0;
		// Application instance.
		wndclass.hInstance    = hInstance;
		// Window icon.
		wndclass.hIcon     = LoadIcon(NULL,IDI_APPLICATION);
		// Window cursor.
		wndclass.hCursor      = LoadCursor(NULL,IDC_ARROW);
		// Window back brush.
		wndclass.hbrBackground= GetStockObject(Brush);
		// Window menu.
		wndclass.lpszMenuName = NULL;
		// Class name.
		wndclass.lpszClassName= NomClasse;
		RegisterClass (&wndclass) ;
	}


/*****************************************************************************
 The Main msPianoKey application procedure.
******************************************************************************/
int  PASCAL WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance,
			LPSTR lpszCmdLine, int nCmdShow)
{
	HWND hWnd;
	MSG         msg ;
	int x=20;
	int y=20;
	DWORD CreateStyle =	WS_POPUP|WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX;
	hgInstance = hInstance;
	/* Register the class  */
	if (!hPrevInstance) 
		RegClass(NomClasse, hInstance,MyWindowProc,LTGRAY_BRUSH	);
	//-------------------------------------------------------------------------

	/* Main window creation  */
	hWnd=CreateWindow (NomClasse,Title,CreateStyle,
			  x,y,0,0,HWND_DESKTOP,
			  NULL,hInstance,NULL);
    if (hWnd ==NULL) return 0;

	/* Show the window */
	ShowWindow (hWnd, SW_NORMAL) ;

	
	/* Updating the client area */
	UpdateWindow (hWnd) ;

	/* Waiting a message until closing the window */
    while (GetMessage (&msg, NULL, 0, 0))
	{
	  	TranslateMessage (&msg) ;
	  	DispatchMessage (&msg) ;
	}
    return msg.wParam ;/* The end of msPianakey */
}

