/******************************************************************************
 Module:   Winproc.c          

 e-mail: Jean-Jacques.CERESA@enac.fr	
******************************************************************************/

#define STRICT
#define __Windows__				// Windows application.
#include "MsPianoKey.h"

/*-----------------------------------------------------------------------------
 Globals variables 
-----------------------------------------------------------------------------*/
short Ref;						// MidiShare reference number.
hPianoKey hWndPianoKey;			// MsPianoKey window handle.

#define STYLE (S_CHILD_PKEY|S_EDIT_PKEY)
#define FLAGS (F_AFTER_TOUCH|F_PITCH_WHEEL|F_MOD_WHEEL)


/******************************************************************************
 MsPianoKey window procedure.
******************************************************************************/
LRESULT CALLBACK MyWindowProc (HWND hWnd, UINT message, UINT wParam,
							  LONG lParam)
{
	switch(message)
	{
		//-- Cr�ation de la fen�tre -------------------------------------------
		case WM_CREATE:
		{	
			//----------------------------------------------------------------
			// Register to MidiShare library.
			Ref=MidiOpen(Title);
			// Connection to the MidiShare application
			MidiConnect (Ref, 0, TRUE);  

			//----------------------------------------------------------------
			// Creation of the PianoKey window 
			{   // Creation of the PianoKey window 
				Byte s;
				s = CreatePianoKey(
						hWnd,
						&hWndPianoKey, 		 /* address of handle to return */
						"PianoKey window",	 /* Title						*/
						STYLE,				 /* Style						*/
						0,0,				 /* Position X and Y			*/
						/* First key, last key								*/			
						RangeKey(FirstOct),
						10,					 /* Width white keys			*/
						40,					 /* Height white keys			*/
						FLAGS				 /* Flags						*/
						);		
				if (s) return -1;
			}
			//----------------------------------------------------------------
			// Adjust the size of the main window
			{	long SizePianoKey;
				RECT Rect;
				short WidthPiano,HeightPiano;
				long CreateStyle = ((LPCREATESTRUCT)lParam)->style;
				int x = ((LPCREATESTRUCT)lParam)->x;
				int y = ((LPCREATESTRUCT)lParam)->y;
				int Width,Height;
				// Adjust the hWnd window to the size of hWndPianokey window.
				GetPianoKeyInfos(hWndPianoKey,	/* Handle of PianoKey		*/
							SIZE_PKEY,		/* Id of the infos to get		*/
							&SizePianoKey	/* Address of the buffer		*/
							);
				// Compute the width and height of the window.
				Rect.left = 0;		Rect.top = 0;
				WidthPiano = WidthSIZE_WKEY(SizePianoKey);
				Rect.right = WidthPiano + WIDTH_BUTT; 
				Rect.bottom = HeightPiano = HeightSIZE_WKEY(SizePianoKey);
				AdjustWindowRect(&Rect,CreateStyle, FALSE);
				Width = Rect.right - Rect.left;
				Height = Rect.bottom - Rect.top;
				// Set the width and height of the window.
				MoveWindow(hWnd, x,y,Width,Height,True);
				//------------------------------------------------------------
				// Create the setting button
				CreateWindow ("BUTTON","S",WS_CHILD|WS_VISIBLE|BS_PUSHBUTTON,
							WidthPiano,0,WIDTH_BUTT,HeightPiano,hWnd,
							NULL,NULL,NULL);

			}
			//----------------------------------------------------------------
			// Install the notifiy procedure.
			SetPianoKeyApplNotify (
					hWndPianoKey,	/* Handle of MsNotes window	*/
					NotifyProc		/* Pointer to notify routine */
					);
			return 0;
		}
		//---------------------------------------------------------------------
		case WM_COMMAND:
		// message send by a menu or control.
		// Parameter  
		//	HIWORD (wParam ): notifify code  if a control.
		//					: 1 if accelerator, 0 if menu
		//  LOWORD(wParam): code Identifier (menu,control,or accelerator).
		//  HWND(lParam):	Handle of control if control , NULL if menu
		//-- Test if it is a menu message:
			if (! lParam)
			{  // A menu is clicked
			
			}
			else // A control is clicked.
			{	
				InitCommonControls ();	
				DialogBox(hgInstance, MAKEINTRESOURCE(IDD_SETTINGS), 
                     hWnd, (DLGPROC)SettingInfosProc);
			}
			return 0;

		//-- Closing the MsPianoKey application--------------------------------
		case WM_CLOSE:
			// Destroy the Pianokey window.
			DestroyPianoKey(hWndPianoKey); 
			MidiClose(Ref);	// closing from the MidiShare library
			// Destroy the main window.
			DestroyWindow(hWnd);	 
			return 0;
		//-- End of application -----------------------------------------------
		case WM_DESTROY:
			PostQuitMessage(0);
			return (0) ;
	}
	return DefWindowProc (hWnd, message, wParam, lParam);
}

