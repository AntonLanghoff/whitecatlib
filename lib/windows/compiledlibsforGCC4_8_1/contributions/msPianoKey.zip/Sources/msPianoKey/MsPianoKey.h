/******************************************************************************
 MsPianoKey.h
 Email: Jean-Jacques.CERESA@enac.fr
******************************************************************************/

#include "../PianoKey/PianoKey.h"
#include <COMMCTRL.H>
#include "MidiShare.h"
#include "Resource.h"

/*-----------------------------------------------------------------------------
 Globals variables 
-----------------------------------------------------------------------------*/
extern short Ref;				// MidiShare reference number.
extern char Title[];			// MsPianoKey window title.
extern hPianoKey hWndPianoKey;	// MsPianoKey window handle.
extern HINSTANCE hgInstance;	// MsPianoKey instance .
extern Byte Port;				// Midi port use in MidiShare event.
extern Byte Channel;			// Midi channel use in MidiShare event.
extern Byte FirstOct;			// Octave number of the first key  
extern Byte KeyPress;			// key pressure / channel pressure.

/*-----------------------------------------------------------------------------
 Prototypes 
-----------------------------------------------------------------------------*/
BOOL CALLBACK SettingInfosProc(HWND hwndDlg, UINT message, WPARAM wParam,
						   LPARAM lParam);

LRESULT CALLBACK  MyWindowProc (HWND, UINT, UINT, LONG) ;


Byte PIANOKEYALARMAPI NotifyProc (
				hPianoKey	hWndPianoKey,	/* Handle of PianoKey window	*/
				Byte		InfosId,		/* Id of the changed infos		*/ 
				long		Infos			/* Value of the infos			*/
				);

/*-----------------------------------------------------------------------------
 Mocros to set pitch in General Midi
-----------------------------------------------------------------------------*/
// Pitch for octave 0
#define Cf  -1
#define C	0
#define Cs	1
#define Df	Cs
#define D	2
#define Ds	3
#define Ef	Ds
#define E	4
#define Es	5
#define Ff	4
#define F	5
#define Fs	6
#define Gf	Fs
#define G	7
#define Gs	8
#define Af	Gs
#define A	9
#define As	10
#define Bf	As
#define B	11
#define Bs	12

#define GM_PITCH_MAX	127
// gmP return a GM pitch from note name and octave number
#define gmP(Pitch,Oct)	( (Pitch + ((Oct) * 12)) )

/*-----------------------------------------------------------------------------
 Macros to set the range of key.
-----------------------------------------------------------------------------*/
#define NBR_OCT	4			/* Range in octave */
/* last octave number */
#define LastOct(First0ct)		((FirstOct +(NBR_OCT -1)))
// range of the keyboard
#define RangeKey(FirstOct)	(MakeRANGE_PKEY(gmP(C,FirstOct),\
							Min(GM_PITCH_MAX,gmP(B,LastOct(FirstOct)))))
/* Number max of 'First octave' spin control */
#define NUM_OCT_MAX		(((GM_PITCH_MAX/12) - (NBR_OCT-1)))		

/*---------------------------------------------------------------------------*/
#define WIDTH_BUTT	15					/* Width of setting button */
