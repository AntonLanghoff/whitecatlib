//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MsPianoKey.rc
//
#define IDD_SETTINGS                    101
#define IDC_RADIO_KEY_PRESS             1001
#define IDC_RADIO_CHAN_PRESS            1002
#define IDC_SPIN_CHAN                   1016
#define IDC_SPIN_OCT                    1017
#define IDC_EDIT_CHAN                   1020
#define IDC_EDIT_OCT                    1021
#define IDC_STATIC_ABOUT                1026
#define IDC_SPIN_PORT                   1027
#define IDC_VERSION_PIANOKEY            1028
#define IDC_VERSION_MSHARE              1029
#define IDC_EDIT_PORT                   1030
#define IDC_STATIC_EMAIL                1032

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
