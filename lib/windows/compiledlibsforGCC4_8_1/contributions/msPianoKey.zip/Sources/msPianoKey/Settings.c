/******************************************************************************
 Module:   Winproc.c          

 e-mail: Jean-Jacques.CERESA@enac.fr	
******************************************************************************/

#define STRICT
#define __Windows__				// Windows application.
#include "MsPianoKey.h"

Byte Port=0;					// Midi port use in MidiShare event.
Byte Channel=0;					// Midi channel use in MidiShare event.
Byte FirstOct=3;				// Octave number of the first key  
Byte KeyPress=False;			// key pressure / channel pressure.

char Email[]="Email: Jean-Jacques.CERESA@enac.fr";

/******************************************************************************
 Settings dialog procedure.
******************************************************************************/
BOOL CALLBACK SettingInfosProc(HWND hwndDlg, UINT message, WPARAM wParam,
						   LPARAM lParam) 
{ 
	switch (message) 
    { 
		//---------------------------------------------------------------------
		case WM_INITDIALOG: 

		{	char Buff[100];
			short Version;
			// Init the version control.
			Version = MidiGetVersion();
			wsprintf(Buff,"MidiShare version: %d.%02d",Version/100,Version%100); 
			SetDlgItemText(hwndDlg, IDC_VERSION_MSHARE,Buff);
			Version = GetPianoKeyVersion();
			wsprintf(Buff,"PianoKey version: %d.%02d",Version/100,Version%100); 
			SetDlgItemText(hwndDlg, IDC_VERSION_PIANOKEY,Buff);
			SetDlgItemText(hwndDlg, IDC_STATIC_EMAIL,Email);
			//-----------------------------------------------------------------
			// Init of Midi Port spin control
			SendDlgItemMessage(hwndDlg, IDC_SPIN_PORT,UDM_SETRANGE ,0,
				(LPARAM) MAKELONG((short) 255, (short) 0));
			SendDlgItemMessage(hwndDlg, IDC_SPIN_PORT,UDM_SETPOS ,0,
				(LPARAM) MAKELONG((short) Port, 0)  );
			//-----------------------------------------------------------------
			// Init of Midi Channel spin control
			SendDlgItemMessage(hwndDlg, IDC_SPIN_CHAN,UDM_SETRANGE ,0,
				(LPARAM) MAKELONG((short) 16, (short) 1));
			SendDlgItemMessage(hwndDlg, IDC_SPIN_CHAN,UDM_SETPOS ,0,
				(LPARAM) MAKELONG((short) Channel+1, 0)  );
			//-----------------------------------------------------------------
			// Init of First octave spin control
			SendDlgItemMessage(hwndDlg, IDC_SPIN_OCT,UDM_SETRANGE ,0,
				(LPARAM) MAKELONG((short) NUM_OCT_MAX, (short) 0));
			SendDlgItemMessage(hwndDlg, IDC_SPIN_OCT,UDM_SETPOS ,0,
				(LPARAM) MAKELONG((short) FirstOct, 0)  );
			//-----------------------------------------------------------------
			// Init of key pressure / channel pressure radio button control
			{	int id;
				if(KeyPress)	id = IDC_RADIO_KEY_PRESS;
				else			id = IDC_RADIO_CHAN_PRESS;
				CheckRadioButton(hwndDlg,	IDC_RADIO_KEY_PRESS,
											IDC_RADIO_CHAN_PRESS, id);
			}
 			return TRUE;
		}

		//---------------------------------------------------------------------
		case WM_COMMAND: 
            switch (LOWORD(wParam)) 
            { 
				//-------------------------------------------------------------
				// Setting the new values.
				case IDOK: 
					// Midi port.
					Port = GetDlgItemInt(hwndDlg,IDC_EDIT_PORT,NULL, FALSE);
					// Midi channel.
					Channel = GetDlgItemInt(hwndDlg,IDC_EDIT_CHAN,NULL,FALSE)-1;
					// First octave.
					FirstOct = GetDlgItemInt(hwndDlg,IDC_EDIT_OCT,NULL,FALSE);
					SetPianoKeyInfos(hWndPianoKey,	/* Handle of PianoKey	*/
							RANGE_PKEY,				/* Id of the infos to set*/
							RangeKey(FirstOct));	/* value to set			*/
					// Flag Key pressure
					if ( IsDlgButtonChecked(hwndDlg, IDC_RADIO_KEY_PRESS) ==
						BST_CHECKED)	KeyPress = True;
					else				KeyPress = False;
					// Fall through.
				//-------------------------------------------------------------
				case IDCANCEL:
					EndDialog(hwndDlg, wParam);
					return TRUE; 
			} 
    } 
	return FALSE; 
}


