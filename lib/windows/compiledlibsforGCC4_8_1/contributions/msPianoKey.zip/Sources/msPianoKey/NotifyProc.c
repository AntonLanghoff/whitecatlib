/******************************************************************************
 NotifyProc.c
 Email: Jean-Jacques.CERESA@enac.fr
******************************************************************************/
#define STRICT
#define __Windows__		// Application Windows 

#include "MsPianoKey.h"


/******************************************************************************
 MsPianoKey call back procedure. This procedure is call by the PianoKey Dll
 to signal events.
******************************************************************************/
Byte PIANOKEYALARMAPI NotifyProc (
				hPianoKey	hWndPianoKey,	/* Handle of PianoKey window	*/
				Byte		InfosId,		/* Id of the changed infos		*/ 
				long		Infos			/* Value of the infos			*/
				)
{	
	switch (InfosId)
	{
		/*-------------------------------------------------------------------*/
		/* Coordinate of the upper-left corner  X et Y */
#if 0
		case XY_PKEY:
		break;
		/* request to close the Pianokey window */
		case N_CLOSE_PKEY:
		break;
#endif 
		/*-------------------------------------------------------------------*/
		/* State, Key number and velocity */
		case SKEY_PKEY:
		{
			MidiEvPtr Ev ;	// MidiShare event to send
			Byte Type;
			if (StateSKEY_PKEY(Infos)) Type = typeKeyOn;
			else Type = typeKeyOff;
			
			Ev = MidiNewEv(Type);

			MidiSetField (Ev, 0, NumKeySKEY_PKEY(Infos));
			MidiSetField (Ev, 1, VelSKEY_PKEY(Infos));
			MidiSetChan(Ev,Channel);
			MidiSetPort(Ev,Port);

			MidiSendIm (Ref,Ev);
		}
		break;

		/*-------------------------------------------------------------------*/
		/* AFTER_TOUCH event: Key number and pressure	(Notify) */
		case N_AFTER_TOUCH:
		{
			MidiEvPtr Ev ;	// MidiShare event to send
			if (KeyPress)	// Poly key pressure event
			{
				Ev=MidiNewEv(typeKeyPress) ;// MidiShare event to send.
				MidiSetField (Ev, 0,NumKeyN_AFTER_TOUCH(Infos) );// Key number.	
				MidiSetField (Ev, 1,PressN_AFTER_TOUCH(Infos));	 // Pressure.
			}
			else	// Channel pressure event
			{
				Ev=MidiNewEv(typeChanPress) ;// MidiShare event to send
				MidiSetField (Ev, 0,PressN_AFTER_TOUCH(Infos));	 // Pressure.
			}
			MidiSetChan(Ev,Channel);
			MidiSetPort(Ev,Port);
			MidiSendIm (Ref,Ev);
		}
		break;
		/*-------------------------------------------------------------------*/
		/* PITCH_WHEEL event: -8192 to +8191 */
		case N_PITCH_WHEEL:
		{
			MidiEvPtr Ev=MidiNewEv(typePitchWheel) ;// MidiShare event to send
			Infos += 8192;
			MidiSetField (Ev, 0, Infos & 0x7F);		// LSB (7 bits)
			MidiSetField (Ev, 1, Infos >> 7 & 0x7F);// MSB (7 bits)
			MidiSetChan(Ev,0);
			MidiSetPort(Ev,0);
			MidiSendIm (Ref,Ev);
		}
		break;
		/*-------------------------------------------------------------------*/
		/* MOD_WHEEL event: 0 to 16383 */
		case N_MOD_WHEEL:
		{
			MidiEvPtr Ev=MidiNewEv(typeCtrlChange);	// MidiShare event to send
			MidiSetField (Ev, 0, 1);				// Mod wheel num. controler
			MidiSetField (Ev, 1, (Infos * 127)/16383);// Value of the controler
			MidiSetChan(Ev,0);
			MidiSetPort(Ev,0);
			MidiSendIm (Ref,Ev);
		}
		break;
	}
	return False;
}

