/******************************************************************************
 Tutorial.h

 Email: Jean-Jacques.CERESA@enac.fr
******************************************************************************/
#include "../PianoKey/PianoKey.h"
#include "TutRes.h"
#include <COMMCTRL.H>

#define PORT 0

#define HEIGHTSBAR 20					// Height of status bar
#define HEIGHTTBAR 28					// Height of title bar
typedef byte ( *TestStepPtr) (void);	// Pointer on step test procedure.
//-----------------------------------------------------------------------------
// descriptor of informations about a step test.
typedef struct
{
	char	*	DescMsg;	// Pointer of the message description.
	TestStepPtr TestStep;	// Pointer of the step procdure to execute .
	char	*	ResMsg;		// Pointer of the result message.
	Byte		Flags;		// Enable/Disable Infos controls.
}StepInfos;

#define INFOS1_F	0x01	// Flags to enable Infos 1 control.
#define INFOS2_F	0x02	// Flags to enable Infos 2 control.
#define INFOS3_F	0x04	// Flags to enable Infos 3 control.
#define IsInfos1(iStep)	( TabTestStep[iStep].Flags & INFOS1_F )
#define IsInfos2(iStep)	( TabTestStep[iStep].Flags & INFOS2_F )
#define IsInfos3(iStep)	( TabTestStep[iStep].Flags & INFOS3_F )

Byte PIANOKEYALARMAPI NotifyProc (
				hPianoKey	hWndPianoKey,	/* Handle of PianoKey window	*/
				Byte		InfosId,		/* Id of the changed infos		*/ 
				long		Infos			/* Value of the infos			*/
				);

void Install_Deinstall_Notify(void);
void DestroyPendingWindow(void);

extern HINSTANCE  ghInstance;	// Instance of the tutorial application.
extern HWND ghwndDlg;			// Handle of the tutorial dialog box.
extern short Ref;				// MidiShare reference number.
extern char * TabErrMsg[];		// Table of report message.
extern char * TabNameIdInfos[];	// Table of name code identifier.
extern char ResultBuff[800];	// Buffer to write result message.
extern Word iResBuff;			// Index in the buffer for the next message.
extern Byte EnNotifyWnd;		// Enable the notify window control.
extern hPianoKey hWndPianoKey;	// handle of the PianoKey windows.
extern long Infos1,Infos2,Infos3;		// Value of spin Infos controls.

extern char Titre[];

extern char DescTest1_Step1_1[];	extern byte Test1_Step1_1(void);
extern char Res1_Step1_1[];
extern char DescTest2_Step1_1[];	extern byte Test2_Step1_1(void);
extern char Res2_Step1_1[];
extern char DescTest3_Step1_1[];	extern byte Test3_Step1_1(void);
extern char Res3_Step1_1[];
extern char DescTest4_Step1_1[];	extern byte Test4_Step1_1(void);
extern char Res4_Step1_1[];
extern char DescTest5_Step1_1[];	extern byte Test5_Step1_1(void);
extern char Res5_Step1_1[];
extern char DescTest6_Step1_1[];	extern byte Test6_Step1_1(void);
extern char Res6_Step1_1[];
extern char DescTest7_Step1_1[];	extern byte Test7_Step1_1(void);
extern char Res7_Step1_1[];
extern char DescTest8_Step1_1[];	extern byte Test8_Step1_1(void);

extern char DescTest9_Step1_1[];	extern byte Test9_Step1_1(void);
extern char DescTest10_Step1_1[];	extern byte Test10_Step1_1(void);
extern char DescTest11_Step1_1[];	extern byte Test11_Step1_1(void);
extern char DescTest12_Step1_1[];	extern byte Test12_Step1_1(void);
extern char DescTest13_Step1_1[];	extern byte Test13_Step1_1(void);
extern char DescTest14_Step1_1[];	extern byte Test14_Step1_1(void);
extern char DescTest15_Step1_1[];	extern byte Test15_Step1_1(void);
extern char DescTest16_Step1_1[];	extern byte Test16_Step1_1(void);
extern char DescTest17_Step1_1[];	extern byte Test17_Step1_1(void);
extern char DescTest18_Step1_1[];	extern byte Test18_Step1_1(void);
extern char DescTest19_Step1_1[];	extern byte Test19_Step1_1(void);
extern char DescTest20_Step1_1[];	extern byte Test20_Step1_1(void);
extern char DescTest21_Step1_1[];	extern byte Test21_Step1_1(void);
extern char DescTest22_Step1_1[];	extern byte Test22_Step1_1(void);
extern char DescTest23_Step1_1[];	extern byte Test23_Step1_1(void);
extern char DescTest24_Step1_1[];	extern byte Test24_Step1_1(void);
extern char DescTest25_Step1_1[];	extern byte Test25_Step1_1(void);
extern char DescTest26_Step1_1[];	extern byte Test26_Step1_1(void);
extern char DescTest27_Step1_1[];	extern byte Test27_Step1_1(void);
extern char DescTest28_Step1_1[];	extern byte Test28_Step1_1(void);
extern char DescTest29_Step1_1[];	extern byte Test29_Step1_1(void);
extern char DescTest30_Step1_1[];	extern byte Test30_Step1_1(void);
extern char DescTest31_Step1_1[];	extern byte Test31_Step1_1(void);
extern char DescTest32_Step1_1[];	extern byte Test32_Step1_1(void);
extern char DescTest33_Step1_1[];	extern byte Test33_Step1_1(void);
extern char DescTest34_Step1_1[];	extern byte Test34_Step1_1(void);
extern char DescTest35_Step1_1[];	extern byte Test35_Step1_1(void);
extern char DescTest36_Step1_1[];	extern byte Test36_Step1_1(void);
extern char DescTest37_Step1_1[];	extern byte Test37_Step1_1(void);
extern char DescTest38_Step1_1[];	extern byte Test38_Step1_1(void);
extern char DescTest39_Step1_1[];	extern byte Test39_Step1_1(void);

extern char DescTest40_Step1_1[];	extern byte Test40_Step1_1(void);
extern char DescTest41_Step1_1[];	extern byte Test41_Step1_1(void);
extern char DescTest42_Step1_1[];	extern byte Test42_Step1_1(void);
extern char DescTest43_Step1_1[];	extern byte Test43_Step1_1(void);
extern char DescTest44_Step1_1[];	extern byte Test44_Step1_1(void);
extern char DescTest45_Step1_1[];	extern byte Test45_Step1_1(void);
extern char DescTest46_Step1_1[];	extern byte Test46_Step1_1(void);
extern char DescTest47_Step1_1[];	extern byte Test47_Step1_1(void);
extern char DescTest48_Step1_1[];	extern byte Test48_Step1_1(void);
extern char DescTest49_Step1_1[];	extern byte Test49_Step1_1(void);

/*-----------------------------------------------------------------------------
 Pitch General Midi
-----------------------------------------------------------------------------*/
// hauteurs pour l'octave 0
#define Cf  -1
#define C	0
#define Cs	1
#define Df	Cs
#define D	2
#define Ds	3
#define Ef	Ds
#define E	4
#define Es	5
#define Ff	4
#define F	5
#define Fs	6
#define Gf	Fs
#define G	7
#define Gs	8
#define Af	Gs
#define A	9
#define As	10
#define Bf	As
#define B	11
#define Bs	12

/* gmP return the General Midi pitch of a note. */
#define gmP(Pitch,Oct)	( (Pitch + ((Oct) * 12)) )
