/******************************************************************************
 Test1To5.c
 Email: Jean-Jacques.CERESA@enac.fr
******************************************************************************/

/******************************************************************************
				*** WELCOME TO THE PIANOKEY TUTORIAL ***

This tutorial is is intended for the developers who wish to understand how a 
PianoKey window works and learn the API of the PianoKey library.
For each API functions, the tutorial execute a serie of tests step by step.
In order for you to learn the API functions and look at the source code, you
must print the 'TestXXToYY.c' file before starting.
These files contents the series of tests executed by the tutorial program.

Try the following method for learning about a test:
	1)Read the description of the test in the window tutorial and in the 
	'TestXXToYY.c' file.
	2)Read the source code of the test in the 'TestXXToYY.c.c' file.
	3)Try to anticipate about the result before executing.
	4)Execute the step and read the result displayed in the 'Result'
	  window of the tutorial program.
	5)Verify the result and what you have expected at (3).

******************************************************************************/

#define STRICT
#define __Windows__		// Application Windows 
#include "Tutorial.h"


/*=============================================================================
	The following tests create PianoKey windows with various style by using
	CreatePianoKey() and DestroyPianoKey() APIs. 
=============================================================================*/

Byte CreatePianoKeyWindow(Word Style,
				Word		KeyRange,	/* First key and last key			*/
				Word		WidthWkey,	/* Width white keys.				*/
				Word		HeightWkey,	/* Height white keys.				*/
				Byte 		Flags		/* Flags							*/ 
				);

/*----------------------------------------------------------------------------
Test 1: step 1/1: 

This test create a simple PianoKey Windows with the following behavior:
	- The style is for display only ( editing is disabled ).
	- The windows informations are those by default:
		.Key range: FIRST_KEY,LAST_KEY.
		.Width and height of white key: WIDTH_WKEY,HEIGHT_WKEY(6 x 18 pixels.)
		.Flags: No sliders for AFTER_TOUCH, PITCH_WHEEL and MOD_WHEEL.
If the result is successful, you can see a small PianoKey window at the top of
the tutorial dialog box.
Try to register a notifying callback procedure by pressing the 'Notify' check 
box below and see the result in this window.
-----------------------------------------------------------------------------*/
byte Test1_Step1_1(void)
{
	/* Setting style */
	Word Style = 0;
	
	/* key range */
	Word KeyRange = MakeRANGE_PKEY(FIRST_KEY,LAST_KEY);	
	
	/* Width and height white keys. */
	Word WidthWkey =0;		
	Word HeightWkey=0;
	
	/* No sliders */ 
	Byte Flags = 0;		

	/* Creation is performed by CreatePianoKeyWindow */ 
	return CreatePianoKeyWindow(Style, KeyRange,WidthWkey, HeightWkey, Flags);
}

/*----------------------------------------------------------------------------
Test 2: step 1/1: 

This test create a window. It do the same work than Test 1 but with a light
different style window. 

	- The style is: S_BORDER_PKEY ( editing is disabled ).

If the result is successful, you can see a small PianoKey window (above the
tutorial dialog box) with a thin border.
Try to register a notifying callback procedure by pressing the 'Notify' check 
box below and see the result in this window.
-----------------------------------------------------------------------------*/
byte Test2_Step1_1(void)
{
	/* Setting style */
	Word Style = S_BORDER_PKEY;
	
	/* key range */
	Word KeyRange = MakeRANGE_PKEY(FIRST_KEY,LAST_KEY);	
	
	/* Width and height white keys. */
	Word WidthWkey =0;
	Word HeightWkey=0;
	
	/* No sliders */ 
	Byte Flags = 0;		

	/* Creation is performed by CreatePianoKeyWindow */ 
	return CreatePianoKeyWindow(Style, KeyRange,WidthWkey, HeightWkey, Flags);
}


/*----------------------------------------------------------------------------
Test 3: step 1/1: 

This test create a window. It do the same work than Test 2 , with a light
different style window, a title bar is to be added. The key range is from C3
to B6 and the width and height of white key is 8 x 24.   

	- The style is: S_BORDER_PKEY + S_TITLE_PKEY ( editing is disabled ).

If the result is successful, you can see a small PianoKey window (above the
tutorial dialog box) with a 3D border a status bar and a caption bar.
Now the window can bee moved by the user. So the window is able to notify the
tutorial application.
Try to register a notifying callback procedure by pressing the 'Notify' check 
box below and see the result in this window.
Try to move the PianoKey window and seen the result in the lower control window.
-----------------------------------------------------------------------------*/
Byte Test3_Step1_1(void)
{
	/* Setting style */
	Word Style = S_BORDER_PKEY | S_TITLE_PKEY;
	
	/* key range */
	Word KeyRange = MakeRANGE_PKEY(gmP(C,3),gmP(B,6));	
	
	/* Width and height white keys. */
	Word WidthWkey =8;
	Word HeightWkey=24;
	
	/* No sliders */ 
	Byte Flags = 0;		

	/* Creation is performed by CreatePianoKeyWindow */ 
	return CreatePianoKeyWindow(Style, KeyRange,WidthWkey, HeightWkey, Flags);
}


/*----------------------------------------------------------------------------
Test 4: step 1/1: 

This test create a window. It do the same work than Test 3 , with a
different style, the edition of notes is now enabled.  

	- The style is: S_BORDER_PKEY + S_TITLE_PKEY + S_EDIT_PKEY.

With the S_EDIT_PKEY style, the user is allowed to use the keyboard  
features of the window. To learn about the keyboard capabilities, please
refer to the user manual and try to use commands described in this
manual.

If the result is successful, you can see a small PianoKey window (above the
tutorial dialog box) with a caption bar.
So the window is able to notify the tutorial application.
Try to register a notifying callback procedure by pressing the 'Notify' check 
box below and see the result in this window.
When the key are pressed and depressed the SKEY_PKEY event is received by the
callback procedure.
-----------------------------------------------------------------------------*/
byte Test4_Step1_1(void)
{
	/* Setting style */
	Word Style = S_BORDER_PKEY | S_TITLE_PKEY | S_EDIT_PKEY;

	/* key range */
	Word KeyRange = MakeRANGE_PKEY(gmP(C,3),gmP(B,6));	
	
	/* Width and height white keys. */
	Word WidthWkey =8;
	Word HeightWkey=24;
	
	/* No sliders */ 
	Byte Flags = 0;		

	/* Creation is performed by CreatePianoKeyWindow */ 
	return CreatePianoKeyWindow(Style, KeyRange,WidthWkey, HeightWkey, Flags);
}

/*----------------------------------------------------------------------------
Test 5: step 1/1: 

This test create a window. It do the same work than Test 4 , with sliders added
to the right of window.

To use the sliders immediately after pushing down a note, the CTRL key
(of your computer) must be push down before the left clik mouse.
Then you can drag over the AFTER_TOUCH(red), PITCH_WHEEL(green) or 
MOD_WHEEL(blue) sliders.To learn about the keyboard capabilities, please
refer to the user manual and try to use commands described in this
manual.

If the result is successful, you can see a small PianoKey window (above the
tutorial dialog box) with a caption bar.
So the window is able to notify the tutorial application. Try to register a 
notifying callback procedure by pressing the 'Notify' check box below and see 
the result in this window.
When the slider are moving the sliders events are received by the callback 
procedure.
-----------------------------------------------------------------------------*/
byte Test5_Step1_1(void)
{
	/* Setting style */
	Word Style =  S_TITLE_PKEY | S_EDIT_PKEY |S_MENU_PKEY | S_MINIMIZE_PKEY;

	/* key range */
	Word KeyRange = MakeRANGE_PKEY(gmP(C,3),gmP(B,6));	
	
	/* Width and height white keys. */
	Word WidthWkey  = 10;
	Word HeightWkey = 30;
	
	/* No sliders */ 
	Byte Flags = F_AFTER_TOUCH | F_PITCH_WHEEL | F_MOD_WHEEL;		

	/* Creation is performed by CreatePianoKeyWindow */ 
	return CreatePianoKeyWindow(Style, KeyRange,WidthWkey, HeightWkey, Flags);

}

/******************************************************************************
Creation a simple PianoKey Windows with the following behavior:
Input parameters:	
		KeyRange,	First key and last key.
		WidthWkey,	Width white keys.
		HeightWkey,	Height white keys.
 		Flags		Flags.
OutPut parameter
	The result code of the creation CreatePianoKey.
******************************************************************************/
Byte CreatePianoKeyWindow(Word Style,
				Word		KeyRange,	/* First key and last key			*/
				Word		WidthWkey,	/* Width white keys.				*/
				Word		HeightWkey,	/* Height white keys.				*/
				Byte 		Flags		/* Flags							*/ 
)
{
	Byte s;	// Status of operation
		
	/*-----------------------------------------------------------------------
	 Create a MSNotes Windows 
	------------------------------------------------------------------------*/
	/* Destroy any window if already exist */
	DestroyPendingWindow();
	/* Create the new window */
	s = CreatePianoKey(	
						ghwndDlg,		/* Handle of parent.			*/
						&hWndPianoKey,	/* address of handle to return.	*/
						"PianoKey window",	/* Title					*/
						Style,				/* Style					*/
						342,116,			/* Position X and Y			*/
						KeyRange,			/* First key and last key	*/
						WidthWkey,			/* Width white keys.		*/
						HeightWkey,			/* Height white keys.		*/
					 	Flags);				/* Flags					*/ 
	/*-----------------------------------------------------------------------
	 Prepare the result message 
	------------------------------------------------------------------------*/
	// Prepare the result message
	wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Creation, status:%d, %s",s,TabErrMsg[s]);
	iResBuff = strlen(ResultBuff);
	return s;
}

