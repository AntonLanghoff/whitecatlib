/******************************************************************************
 Test16To24.c
 Email: Jean-Jacques.CERESA@enac.fr
******************************************************************************/


#define STRICT
#define __Windows__		// Application Windows 
#include "Tutorial.h"


/*=============================================================================
	The following tests get and set window informations by the use of
	GetPianoKeyInfos() and SetPianoKeyInfos() APIs. 
=============================================================================*/


/*-----------------------------------------------------------------------------
Test 16: step 1/1: 

  This test get the key range (FirstKey and LastKey) of the keyboard.
-----------------------------------------------------------------------------*/
byte Test16_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndPianoKey) Test5_Step1_1();
	/*-------------------------------------------------------------------
	 Get the first key and last key
	--------------------------------------------------------------------*/
	{
		Byte s;				// Status of operation
		Word RangeKey;
		/* get the range */
		s = GetPianoKeyInfos(hWndPianoKey,	/* Handle of PianoKey window		*/
							RANGE_PKEY,		/* Id of the infos to get			*/
							&RangeKey		/* Address of the buffer value to get	*/
							);
		/* prepare the result status message */
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Get the range key, status:%d, %s",	s,TabErrMsg[s]);
		iResBuff = strlen(ResultBuff);
		if (!s)	wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-First key:%d Last key:%d",	FirstKeyRANGE_PKEY(RangeKey), 
												LastKeyRANGE_PKEY(RangeKey));
		return s;
	}
}

/*-----------------------------------------------------------------------------
Test 17: step 1/1: 

  This test set the key range (RANGE_PKEY) of the keyboard.
  Choose the First key and Last key values with the spin control 1 and 2
  then press the push button to execute and see the status in the result
  window.
-----------------------------------------------------------------------------*/
byte Test17_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndPianoKey) Test5_Step1_1();
	/*-------------------------------------------------------------------
	 Set the range key 
	--------------------------------------------------------------------*/
	{
		Byte s;							// Status of operation
		Byte FirstKey = (Byte)Infos1;	// Infos1 is the first key number
		Byte LastKey = (Byte)Infos2;	// Infos2 is the last key number
		Word RangeKey = MakeRANGE_PKEY(FirstKey,LastKey);
		/* set the range key of the keyboard */
		s = SetPianoKeyInfos(hWndPianoKey,	/* Handle of PianoKey window	*/
							RANGE_PKEY,		/* Id of the infos to set		*/
							RangeKey		/* value to set					*/
							);
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Set range key, status:%d, %s",	s,TabErrMsg[s]);
		return s;
	}
}

/*-----------------------------------------------------------------------------
Test 18: step 1/1: 

  This test get the size of white keys (width and height).
-----------------------------------------------------------------------------*/
byte Test18_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndPianoKey) Test5_Step1_1();
	/*-------------------------------------------------------------------
	 Get the width and height of white key
	--------------------------------------------------------------------*/
	{
		Byte s;				// Status of operation
		long SizeWkey;
		/* get the size */
		s = GetPianoKeyInfos(hWndPianoKey,	/* Handle of PianoKey window	*/
							SIZE_WKEY,		/* Id of the infos to get		*/
							&SizeWkey	/* Address of the buffer value to get*/
							);
		/* prepare the result status message */
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Get the size of white key, status:%d, %s",	s,TabErrMsg[s]);
		iResBuff = strlen(ResultBuff);
		if (!s)	wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Width:%d Height:%d",	WidthSIZE_WKEY(SizeWkey), 
											HeightSIZE_WKEY(SizeWkey));
		return s;
	}
}

/*-----------------------------------------------------------------------------
Test 19: step 1/1: 

  This test set the size of white keys (width and height).
-----------------------------------------------------------------------------*/
byte Test19_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndPianoKey) Test5_Step1_1();
	/*-------------------------------------------------------------------
	 Set the width and height of white key
	--------------------------------------------------------------------*/
	{
		Byte s;							// Status of operation
		Byte WidthWkey = (Byte)Infos1;	// Infos1 is the width of white key
		Byte HeightWkey = (Byte)Infos2;	// Infos2 is the height of white key
		long SizeWkey = MakeSIZE_WKEY(WidthWkey,HeightWkey);
		/* set the size */
		s = SetPianoKeyInfos(hWndPianoKey,	/* Handle of PianoKey window	*/
							SIZE_WKEY,		/* Id of the infos to set		*/
							SizeWkey		/* value to set					*/
							);
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Set size of white keys, status:%d, %s",	s,TabErrMsg[s]);
		return s;
	}
}


/*-----------------------------------------------------------------------------
Test 20: step 1/1: 

 This test get the Flags FLAGS_PKEY.
-----------------------------------------------------------------------------*/
byte Test20_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndPianoKey) Test5_Step1_1();
	/*-------------------------------------------------------------------
	 Get Flags 
	--------------------------------------------------------------------*/
	{
		Byte s;				// Status of operation
		Byte Flags;
		/* Get the flags of a pianokey window */
		s = GetPianoKeyInfos(hWndPianoKey,	/* Handle of Pianokey window	*/
							FLAGS_PKEY,		/* Id of the infos to get	*/
							&Flags	/* Address of the buffer value to get*/
							);
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Get the flags , status:%d, %s", s,TabErrMsg[s]);
		if (!s)
		{
			strcat(ResultBuff,"\r\n\t-Flags are:\t");
			if (! Flags )			strcat(ResultBuff,"0.");
			if (IsAfterTouch(Flags))	strcat(ResultBuff,"F_AFTER_TOUCH,");
			if (IsPitchWheel(Flags))	strcat(ResultBuff," F_PITCH_WHEEL,");
			if (IsModWheel(Flags))	strcat(ResultBuff," F_MOD_WHEEL,");
		}
		return s;
	}
}

/*-----------------------------------------------------------------------------
Test 21: step 1/1: 

 This test set the Flags FLAGS_PKEY to 0.
-----------------------------------------------------------------------------*/
byte Test21_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndPianoKey) Test5_Step1_1();
	/*-------------------------------------------------------------------
	 Get Flags 
	--------------------------------------------------------------------*/
	{
		Byte s;				// Status of operation
		Byte Flags =0 ;
		/* Set the flags to 0 */
		s = SetPianoKeyInfos(hWndPianoKey,	/* Handle of Pianokey window	*/
							FLAGS_PKEY,		/* Id of the infos to get	*/
							Flags	/* Address of the buffer value to get*/
							);
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Set the flags , status:%d, %s", s,TabErrMsg[s]);

		return s;
	}
}

/*-----------------------------------------------------------------------------
Test 22: step 1/1: 

 This test try to get the state of a key.
-----------------------------------------------------------------------------*/
byte Test22_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndPianoKey) Test5_Step1_1();
	/*-------------------------------------------------------------------
	 Get Flags 
	--------------------------------------------------------------------*/
	{
		Byte s;				// Status of operation
		long StateNumKey;
		/* Trying to get the state of a key */
		s = GetPianoKeyInfos(hWndPianoKey,	/* Handle of Pianokey window	*/
							SKEY_PKEY,		/* Id of the infos to get	*/
							&StateNumKey /* Address of the buffer value to get*/
							);
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Get the state of a key, status:%d, %s", s,TabErrMsg[s]);

		return s;
	}
}

/*-----------------------------------------------------------------------------
Test 23: step 1/1: 

  This test set the state (On/Off) of a key on the keyboard.
  Choose the state key and the  key number values with the spin control 
  1 and 2. A value of 0 for state indicate a 'KeyOff' state. A value 
  different of zero indicate a 'KeyOn'.

  then press the push button to execute and see the status in the result
  window.
-----------------------------------------------------------------------------*/
byte Test23_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndPianoKey) Test5_Step1_1();
	/*-------------------------------------------------------------------
	 Set the range key 
	--------------------------------------------------------------------*/
	{
		Byte s;							// Status of operation
		Byte State = (Byte)Infos1;	// Infos1 is the state key 
		Byte NumKey = (Byte)Infos2;	// Infos2 is the  key number
		long StateKey = MakeSKEY_PKEY(State,NumKey);
		/* set the state of a key of the keyboard */
		s = SetPianoKeyInfos(hWndPianoKey,	/* Handle of PianoKey window	*/
							SKEY_PKEY,		/* Id of the infos to set		*/
							StateKey		/* value to set					*/
							);
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Set state of a key, status:%d, %s",	s,TabErrMsg[s]);
		return s;
	}
}

/*-----------------------------------------------------------------------------
Test 24: step 1/1: 

 This test get and set the whole PianoKey window information INFOS_PKEY
	1) First the  test get the window informations,
	2) The width and height of white key are changed.
	3) The new window informations structure is set.
-----------------------------------------------------------------------------*/
byte Test24_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndPianoKey) Test5_Step1_1();
	/*-------------------------------------------------------------------
		Get the window informations.
		Change the width and height of white key.
		Set the window informations.
	--------------------------------------------------------------------*/
	{
		Byte s;				// Status of operation
		PianoKeyInfos WndInfos;
		/* Get the window informations.  */
		s = GetPianoKeyInfos(hWndPianoKey,/* Handle of PianoKey window	*/
							INFOS_PKEY,	/* Id of the infos to get	*/
							&WndInfos	/* Address of the buffer value to get*/
							);
		/* prepare the result message */
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Get window informations, status:%d, %s", s,TabErrMsg[s]);
		iResBuff = strlen(ResultBuff);
		/* Change the width and heigth of white keys. */
		WndInfos.WidthWkey += 2;	// increase the width.
		WndInfos.HeightWkey = 3 * WndInfos.WidthWkey;// change the height.
		/* Set the new window informations.  */
		s = SetPianoKeyInfos(hWndPianoKey,		/* Handle of PianoKey window	*/
							INFOS_PKEY,			/* Id of the infos to set	*/
							(long)&WndInfos		/* value to set				*/
							);
		/* prepare the result message */
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Set window informations, status:%d, %s", s,TabErrMsg[s]);
		return s;
	}
}

