/******************************************************************************
 NotifyProc.c
 
 Email: Jean-Jacques.CERESA@enac.fr
******************************************************************************/
#define STRICT
#define __Windows__		// Application Windows 
#include "Tutorial.h"

char ResNotifyFail[]="\r\n\
Installing a notifying procedure fails if the PianoKey window cannot \
notify. PianoKey window can notify if it has at less one of these flags \
styles:\r\n\
	S_EDIT, which enable edition of notes.\r\n\
	S_TITLE, which enable moving the window.\r\n\
";


/*----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
void Install_Deinstall_Notify(void)
{					
	Byte s;
	if( IsDlgButtonChecked(ghwndDlg,IDC_CHECK_NOTIFY))
	{	// Try to install the notifiy procedure.
		s = SetPianoKeyApplNotify (
					hWndPianoKey,	/* Handle of PianoKey window	*/
					NotifyProc		/* Pointer to notify routine */
					);
		strcpy(ResultBuff,"Result of installing the notify procedure");
		EnNotifyWnd= ! s;
		SendDlgItemMessage(ghwndDlg, IDC_CHECK_NOTIFY,BM_SETCHECK ,
													EnNotifyWnd,0);
	}
	else 
	{	// Try to de-install the notifiy procedure.
		s = SetPianoKeyApplNotify (
					hWndPianoKey,	/* Handle of PianoKey window	*/
					Null			/* Pointer to notify routine */
					);
		strcpy(ResultBuff, "Result of de-installing the notify procedure");
		EnNotifyWnd = False;
	}
	iResBuff = strlen(ResultBuff);
	wsprintf( &ResultBuff[iResBuff],":%d, %s", s,TabErrMsg[s]);
	if (s)	
	{
		strcat(ResultBuff, ResNotifyFail);
		MessageBeep(MB_ICONEXCLAMATION);
	}
	SetDlgItemText(ghwndDlg,IDC_EDIT_NOTIFY,""); // Clear the window

	SetDlgItemText(ghwndDlg, IDC_EDIT_RES,ResultBuff);
}


/*----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
Byte PIANOKEYALARMAPI NotifyProc (
				hPianoKey	hWndPianoKey,	/* Handle of PianoKey window	*/
				Byte		InfosId,		/* Id of the changed infos		*/ 
				long		Infos			/* Value of the infos			*/
				)
{	
	char Buff[100];
	switch (InfosId)
	{
		/*-------------------------------------------------------------------*/
		/* Coordinate of the upper-left corner  X et Y	(Notify) */
		case XY_PKEY:
			wsprintf( Buff,"%08X\t%s\tX:%d Y:%d",hWndPianoKey,
						TabNameIdInfos[InfosId],
						XposXY_PKEY(Infos),YposXY_PKEY(Infos));

		break;
		/* State, Key number and velocity				(Notify) */
		case SKEY_PKEY:
			wsprintf( Buff,"%08X\t%s\tState:%d Key:%d Vel:%d",hWndPianoKey,
						TabNameIdInfos[InfosId],
						StateSKEY_PKEY(Infos),
						NumKeySKEY_PKEY(Infos),
						VelSKEY_PKEY(Infos));
		break;
		/* AFTER_TOUCH event: Key number and pressure	(Notify) */
		case N_AFTER_TOUCH:
			wsprintf( Buff,"%08X\t%s\tKey:%d Pressure:%d",hWndPianoKey,
						TabNameIdInfos[InfosId],
						NumKeyN_AFTER_TOUCH(Infos),
						PressN_AFTER_TOUCH(Infos));
		break;
		/* PITCH_WHEEL event: -8192 to +8191 */
		case N_PITCH_WHEEL:
			wsprintf( Buff,"%08X\t%s\tValue:%d",hWndPianoKey,
						TabNameIdInfos[InfosId],Infos);
		break;
		/* MOD_WHEEL event: 0 to 16383 */
		case N_MOD_WHEEL:
			wsprintf( Buff,"%08X\t%s\tValue:%d",hWndPianoKey,
						TabNameIdInfos[InfosId],(short)Infos);
		break;
		/* request to close the Pianokey window */
		case N_CLOSE_PKEY:
			wsprintf(Buff,"%08X\t%s\tNo",hWndPianoKey,TabNameIdInfos[InfosId]);
		break;
	}
	SetDlgItemText(ghwndDlg,IDC_EDIT_NOTIFY,Buff);
	return False;
}

