/*****************************************************************************
 Module: TutWinmain.c           
 Email: Jean-Jacques.CERESA@enac.fr

******************************************************************************/

#define STRICT
#define __Windows__		// Application Windows 
#include "Tutorial.h"

//-Prototypes-----------------------------------------------------------------

extern BOOL CALLBACK TutorialDialogProc(HWND hwndDlg, UINT message,
										WPARAM wParam,  LPARAM lParam) ;
char Titre[]="PianoKey tutorial"; 
HINSTANCE  ghInstance;
/*****************************************************************************/
int  PASCAL WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance,
			LPSTR lpszCmdLine, int nCmdShow)
{

	int r;
	ghInstance = hInstance;
	InitCommonControls ();	// Necessary to load de common controls library.
	r= DialogBox(hInstance, MAKEINTRESOURCE(IDD_TUTORIAL), 
                     NULL, (DLGPROC)TutorialDialogProc);
	return 0;

}

