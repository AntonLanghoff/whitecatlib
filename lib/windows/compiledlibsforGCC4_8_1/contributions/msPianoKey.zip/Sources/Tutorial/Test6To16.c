/******************************************************************************
 Test6To15.c
 Email: Jean-Jacques.CERESA@enac.fr
******************************************************************************/


#define STRICT
#define __Windows__		// Application Windows 
#include "Tutorial.h"


/*=============================================================================
	The following tests get and set window informations by the use of
	GetPianoKeyInfos() and SetPianoKeyInfos() APIs. 
=============================================================================*/

/*----------------------------------------------------------------------------
Test 6: step 1/1:

This test get the length of the window title LEN_TITLE_MSN.
Now the application know the lenght of the buffer need to get the title 
of the window.

If the result is successful, the value of the lenght is displayed in the
result window.
-----------------------------------------------------------------------------*/
byte Test6_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndPianoKey) Test5_Step1_1();

	/*-------------------------------------------------------------------
	 Get the lenght of title 
	--------------------------------------------------------------------*/
	{
		Byte LenTitle;		// Infos
		Byte s;				// Status of operation
		s = GetPianoKeyInfos(hWndPianoKey,	/* Handle of PianoKey window	*/
							LEN_TITLE_PKEY,	/* Id of the infos to get		*/
							&LenTitle		/* address of the infos			*/
							);
		/* prepare the result message */
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Get lenght of title, status:%d, %s", s,TabErrMsg[s]);
		if (!s)
		{
			iResBuff = strlen(ResultBuff);
			wsprintf( &ResultBuff[iResBuff],"\r\n\t-Lenght of title:%d",
					LenTitle);
		}
		return s;
	}
}

/*----------------------------------------------------------------------------
Test 7: step 1/1: 

This test set the length of the window title LEN_TITLE_PKEY to  8 bytes.
This is usefull to limit the length of the title to the lenght of the buffer
used to get the window title.
Now a maximum of 8 bytes of the title will be received when getting the
window title.
-----------------------------------------------------------------------------*/
byte Test7_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndPianoKey) Test5_Step1_1();

	/*-------------------------------------------------------------------
	 Set the lenght of title 
	--------------------------------------------------------------------*/
	{
		Byte LenTitle = 8;	// Infos
		Byte s;				// Status of operation
		s = SetPianoKeyInfos(hWndPianoKey,	/* Handle of PianoKey window	*/
							LEN_TITLE_PKEY,	/* Id of the infos to set		*/
							LenTitle		/* Value to set					*/
							);
		/* prepare the result message */
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Set lenght of title, status:%d, %s", s,TabErrMsg[s]);
		iResBuff = strlen(ResultBuff);
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Lenght of title has been set to:%d bytes.", LenTitle);

		return s;
	}
}

/*----------------------------------------------------------------------------
Test 8: step 1/1: 

This test get the window title TITLE_PKEY.

If the result is successful, the title is displayed in the
result window.
-----------------------------------------------------------------------------*/
byte Test8_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndPianoKey) Test5_Step1_1();

	/*-------------------------------------------------------------------
	 Get the window title 
	--------------------------------------------------------------------*/
	{
		Byte Title [100];	// Buffer to get the title
		Byte s;				// Status of operation
		s = GetPianoKeyInfos(hWndPianoKey,/* Handle of PianoKey window	*/
							TITLE_PKEY,	/* Id of the infos to get		*/
							Title		/* Address of the buffer infos	*/
							);
		/* prepare the result message */
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Get title, status:%d, %s", s,TabErrMsg[s]);
		if (!s)
		{
			iResBuff = strlen(ResultBuff);
			wsprintf( &ResultBuff[iResBuff],"\r\n\t-Title is:%s", Title);
		}
		return s;
	}
}

/*----------------------------------------------------------------------------
Test 9: step 1/1: 

This test set window title TITLE_PKEY to: This is a new title.

If the result is successful, the new title is display in the caption bar 
if it exits.
-----------------------------------------------------------------------------*/
byte Test9_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndPianoKey) Test5_Step1_1();

	/*-------------------------------------------------------------------
	 Set the window title 
	--------------------------------------------------------------------*/
	{
		Byte Title []="This is a new title"; // Title to set
		Byte s;				// Status of operation
		s = SetPianoKeyInfos(hWndPianoKey,	/* Handle of PianoKey window	*/
							TITLE_PKEY,		/* Id of the infos to set		*/
							(long)Title		/* Address of value to set		*/
							);
		/* prepare the result message */
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Set title, status:%d, %s", s,TabErrMsg[s]);
		return s;
	}
}

/*----------------------------------------------------------------------------
Test 10: step 1/1: 

This test get the window style STYLE_PKEY.

If the result is successful, the style is displayed in the
result window.
-----------------------------------------------------------------------------*/
byte Test10_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndPianoKey) Test5_Step1_1();

	/*-------------------------------------------------------------------
	 Get the window style 
	--------------------------------------------------------------------*/
	{
		Byte s;				// Status of operation
		Word Style;			// Buffer to get the title
		s = GetPianoKeyInfos(hWndPianoKey,/* Handle of PianoKey window		*/
							STYLE_PKEY,	/* Id of the infos to get			*/
							&Style		/* Address of the buffer value to get*/
							);
		/* prepare the result message */
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Get style, status:%d, %s", s,TabErrMsg[s]);
		
		if (!s)
		{
			strcat(ResultBuff,"\r\n\t-Style is:\t");
			if (!Style)				strcat(ResultBuff,"0.");
			if (IsBorderPKEY(Style))	strcat(ResultBuff,"S_BORDER_PKEY, ");
			if (IsTitlePKEY(Style))		strcat(ResultBuff,"S_TITLE_PKEY, ");
			if (IsEditPKEY(Style))		strcat(ResultBuff,"S_EDIT_PKEY, ");
			if (IsMenuPKEY(Style))		strcat(ResultBuff,"S_MENU_PKEY, ");
			if (IsMinimizePKEY(Style))	strcat(ResultBuff,"S_MINIMIZE_PKEY, ");
			if (IsChildPKEY(Style))		strcat(ResultBuff,"S_CHILD_PKEY");
		}
		return s;
	}
}

/*----------------------------------------------------------------------------
Test 11: step 1/1: 

This test try to set window style STYLE_PKEY to: 0.
-----------------------------------------------------------------------------*/
byte Test11_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndPianoKey) Test5_Step1_1();

	/*-------------------------------------------------------------------
	 Set the window style 
	--------------------------------------------------------------------*/
	{
		Byte Style = 0;		// Style to set
		Byte s;				// Status of operation
		s = SetPianoKeyInfos(hWndPianoKey,	/* Handle of PianoKey window	*/
							STYLE_PKEY,		/* Id of the infos to set		*/
							Style			/* value to set					*/
							);
		/* prepare the result message */
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Set style, status:%d, %s",	s,TabErrMsg[s]);
		return s;
	}
}

/*----------------------------------------------------------------------------
Test 12: step 1/1: 

  This test get the window position : XY_PKEY
-----------------------------------------------------------------------------*/
byte Test12_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndPianoKey) Test5_Step1_1();
	/*-------------------------------------------------------------------
	 Get the window position 
	--------------------------------------------------------------------*/
	{
		Byte s;				// Status of operation
		long xyPos;
		s = GetPianoKeyInfos(hWndPianoKey,/* Handle of PianoKey window	*/
							XY_PKEY,		/* Id of the infos to get	*/
							&xyPos		/* Address of the buffer value to get*/
							);
		/* prepare the result message */
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Get X and Y position, status:%d, %s", s,TabErrMsg[s]);
		iResBuff = strlen(ResultBuff);
		if (!s) wsprintf( &ResultBuff[iResBuff],"\r\n\t-X:%d Y:%d",
							XposXY_PKEY(xyPos), YposXY_PKEY(xyPos));
		return s;
	}
}

/*----------------------------------------------------------------------------
Test 13: step 1/1: 

  This test set the window position : XY_PKEY
  Choose the X and Y values with the spin control 1 and 2 then press the 
  push button to execute and see the status in the result window.

-----------------------------------------------------------------------------*/
byte Test13_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndPianoKey) Test5_Step1_1();
	/*-------------------------------------------------------------------
	 Set the window position 
	--------------------------------------------------------------------*/
	{
		Byte s;				// Status of operation
		long xyPos;
		Word xPos = (Word)Infos1;	// Infos1 is X
		Word yPos = (Word)Infos2;	// Infos2 is Y
		xyPos = MakeXY_PKEY(xPos,yPos);
		s = SetPianoKeyInfos(hWndPianoKey,	/* Handle of PianoKey window	*/
							XY_PKEY,		/* Id of the infos to set	*/
							xyPos			/* value to set	*/
							);
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Set X and Y position, status:%d, %s", s,TabErrMsg[s]);
		return s;
	}
}

/*----------------------------------------------------------------------------
Test 14: step 1/1: 

  This test get the window size : SIZE_PKEY
-----------------------------------------------------------------------------*/
byte Test14_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndPianoKey) Test5_Step1_1();
	/*-------------------------------------------------------------------
	 Get the window size 
	--------------------------------------------------------------------*/
	{
		Byte s;				// Status of operation
		long Size;
		s = GetPianoKeyInfos(hWndPianoKey,	/* Handle of PianoKey window	*/
							SIZE_PKEY,		/* Id of the infos to get		*/
							&Size		/* Address of the buffer value to get*/
							);
		/* prepare the result message */
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Get size, status:%d, %s", s,TabErrMsg[s]);
		iResBuff = strlen(ResultBuff);
		if (!s)	wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Width:%d Height:%d",WidthSIZE_PKEY(Size), 
										HeightSIZE_PKEY(Size));
		return s;
	}
}

/*----------------------------------------------------------------------------
Test 15: step 1/1: 

 This test try to set window size SIZE_PKEY to: 0.
-----------------------------------------------------------------------------*/
byte Test15_Step1_1(void)
{
	/*-------------------------------------------------------------------
	 If the window does not exist, creation of the window 
	--------------------------------------------------------------------*/
	if (!hWndPianoKey) Test5_Step1_1();
	/*-------------------------------------------------------------------
	 Set the window size 
	--------------------------------------------------------------------*/
	{
		Byte s;				// Status of operation
		long Size;
		Size = 0;
		s = SetPianoKeyInfos(hWndPianoKey,	/* Handle of PianoKey window	*/
							SIZE_PKEY,		/* Id of the infos to set	*/
							Size			/* value to set	*/
							);
		wsprintf( &ResultBuff[iResBuff],
			"\r\n\t-Set size, status:%d, %s", s,TabErrMsg[s]);
		return s;
	}
}

