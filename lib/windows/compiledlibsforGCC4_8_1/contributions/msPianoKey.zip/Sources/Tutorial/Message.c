/******************************************************************************
 Message.c
 Email: Jean-Jacques.CERESA@enac.fr
******************************************************************************/

#define STRICT
#define __Windows__		// Application Windows 
#include "Tutorial.h"

/*----------------------------------------------------------------------------
 Table of report messages indexed by the status returned by PianoKey API.

		PKEYok				0	 Successful operation.
 Errors returned by API operating system calls: 
		PKEYerrOS			1	 Operating System errror.	
 Invalid parameters: 
		PKEYerrBadHandle	2	 Handle of window is invalid.	
		PKEYerrBadInfos		3	 Infos value is invalid.				
		PKEYerrBadIdInfos	4	 Code identifier is invald.			
		PKEYerrBadOp		5	 Operation (Set or Get) is invalid.
-----------------------------------------------------------------------------*/
char * TabErrMsg[]={
	"PKEYok, successful operation.",
	"PKEYerrOS, Operating System errror.",
	"PKEYerrBadHandle, handle of window is invalid.",
	"PKEYerrBadInfos, infos value is invalid.",
	"PKEYerrBadIdInfos, code identifier is invalid.",
	"PKEYerrBadOp, operation is invalid."
};

/*----------------------------------------------------------------------------
 Table of name code identifier indexed by the code identifier.
-----------------------------------------------------------------------------*/
char * TabNameIdInfos[]={
	"LEN_TITLE_PKEY", 	/* Number of byte of title (R-W)					*/
	"TITLE_PKEY" ,		/* Window title	(R-W)								*/
	"STYLE_PKEY",		/* style (R)										*/
	"XY_PKEY",			/* Coordinate of  upper-left corner X et Y (R-W-N)	*/
	"SIZE_PKEY",		/* Height and width	(R)								*/
	"RANGE_PKEY",		/* First key and last key on keyboard	 (R-W)		*/
	"SIZE_WKEY",		/* Height and width	of white keys(R-W)				*/
	"FLAGS_PKEY",		/* Validation flags	(R-W)							*/
	"INFOS_PKEY",		/* All the window informations (R-W)				*/
 	"SKEY_PKEY",		/* State and key number (R-W-N)						*/
	
	/* Notify code only */
	"N_AFTER_TOUCH",	/* After touch sensor in action	(N)					*/
	"N_PITCH_WHEEL",	/* Pitch wheel in action (N)						*/
	"N_MOD_WHEEL",		/* Modulation wheel in action (N)					*/
	"N_CLOSE_PKEY"		/* The user close the PianoKey Window (N)			*/
};

/*----------------------------------------------------------------------------
-----------------------------------------------------------------------------*/
void  DestroyPendingWindow(void)
{
	Byte s;

	if (hWndPianoKey)
	{
		/* Destroy the window */
		s=DestroyPianoKey(hWndPianoKey); 
		hWndPianoKey = Null;
		
		/* Uncheck de 'Notify' check box, clear the window, disable window. */
		SendDlgItemMessage(ghwndDlg, IDC_CHECK_NOTIFY,BM_SETCHECK ,0,0);
		SetDlgItemText(ghwndDlg,IDC_EDIT_NOTIFY,""); // Clear the window
		EnNotifyWnd = False;

		/* Prepare the result message */
		wsprintf( &ResultBuff[iResBuff],"\r\n\t-Destroying, status:%d, %s",
										s,TabErrMsg[s]);
		iResBuff = strlen(ResultBuff);
	}
}

/*----------------------------------------------------------------------------
 
-----------------------------------------------------------------------------*/
char DescTest1_Step1_1[]="\
Test 1:step 1/1:\r\n\
-------------------------\r\n\
This test create a simple PianoKey Windows with the following behavior:\r\n\
	- The style is for display only ( editing is disabled ).\r\n\
	- The windows informations are those by default:\r\n\
		.Key range: FIRST_KEY,LAST_KEY.\r\n\
		.Width and height of white key: WIDTH_WKEY,HEIGHT_WKEY(6 x 18 pixels.)\r\n\
		.Flags: No sliders for AFTER_TOUCH, PITCH_WHEEL and MOD_WHEEL.\r\n\
If any PianoKey window already exist it is destroyed before creating the new \
one.\r\n\
Press the push button to execute and see the status in the result window.";
  
/*---------------------------------------------------------------------------*/
char Res1_Step1_1[]="\
\r\n\
If the result is successful, you can see a small PianoKey window at the top of \
the tutorial dialog box.\r\n\
Try to register a notifying callback procedure by pressing the 'Notify' check \
box below and see the result in this window.";


/*---------------------------------------------------------------------------*/
char DescTest2_Step1_1[]="\
Test 2:step 1/1:\r\n\
-------------------------\r\n\
This test create a window. It do the same work than Test 1 but with a light \
different style window.\r\n\
	- The style is: S_BORDER_PKEY ( editing is disabled ).\r\n\
Press the push button to execute and see the status in the result window.";

/*---------------------------------------------------------------------------*/
char Res2_Step1_1[]="\
\r\n\
If the result is successful, you can see a small PianoKey window with a thin \
border at the top of the tutorial dialog box.\r\n\
Try to register a notifying callback procedure by pressing the 'Notify' check \
box below and see the result in this window.";


/*---------------------------------------------------------------------------*/
char DescTest3_Step1_1[]="\
Test 3:step 1/1:\r\n\
-------------------------\r\n\
This test create a window. It do the same work than Test 2 , with a light \
different style window, a title bar is to be added. The key range is from C3 \
to B6 and the width and height of white key is 8 x 24.\r\n\
	- The style is: S_BORDER_PKEY + S_TITLE_PKEY ( editing is disabled ).\r\n\
Press the push button to execute and see the status in the result window.";

/*---------------------------------------------------------------------------*/
char Res3_Step1_1[]="\
\r\n\
If the result is successful, you can see a small PianoKey window (above the \
tutorial dialog box) with a 3D border and a caption bar.\r\n\
Now the window can bee moved by the user. So the window is able to notify the \
tutorial application.\r\n\
Try to register a notifying callback procedure by pressing the 'Notify' check \
box below and see the result in this window.\r\n\
Try to move the PianoKey window and seen the result in the lower control \
window.";

/*---------------------------------------------------------------------------*/
char DescTest4_Step1_1[]="\
Test 4:step 1/1:\r\n\
-------------------------\r\n\
This test create a window. It do the same work than Test 3 , with a \
different style, the edition of notes is now enabled.\r\n\
	- The style is: S_BORDER_PKEY + S_TITLE_PKEY + S_EDIT_PKEY.\r\n\
With the S_EDIT_PKEY style, the user is allowed to use the keyboard \
features of the window. To learn about the keyboard capabilities, please \
refer to the user manual and try to use commands described in this manual.";

/*---------------------------------------------------------------------------*/
char Res4_Step1_1[]="\
\r\n\
If the result is successful, you can see a small PianoKey window (above the \
tutorial dialog box) with a caption bar.\r\n\
So the window is able to notify the tutorial application.\r\n\
Try to register a notifying callback procedure by pressing the 'Notify' check \
box below and see the result in this window.\r\n\
When the keys are pressed and depressed the SKEY_PKEY event is received by the \
callback procedure.";


/*---------------------------------------------------------------------------*/
char DescTest5_Step1_1[]="\
Test 5:step 1/1:\r\n\
-------------------------\r\n\
This test create a window. It do the same work than Test 4 , with sliders \
added to the right of window.\r\n\
To use the sliders immediately after pushing down a note, the CTRL key \
(of your computer) must be push down before the left clik mouse. \
Then you can drag over the AFTER_TOUCH(red), PITCH_WHEEL(green) or \
MOD_WHEEL(blue) sliders.To learn about the keyboard capabilities, please \
refer to the user manual and try to use commands described in this manual.";

/*---------------------------------------------------------------------------*/
char Res5_Step1_1[]="\
\r\n\
If the result is successful, you can see a small PianoKey window (above the \
tutorial dialog box) with a caption bar.\r\n\
So the window is able to notify the tutorial application. Try to register a \
notifying callback procedure by pressing the 'Notify' check box below and \
see the result in this window.\r\n\
When the slider are moving the sliders events are received by the callback \
procedure.";


/*---------------------------------------------------------------------------*/
char DescTest6_Step1_1[]="\
Test 6:step 1/1:\r\n\
-------------------------\r\n\
This test get the length LEN_TITLE_PKEY of the window title.\r\n\
Now the application know the lenght of the buffer need to get the title \
of the window.\r\n\
If the result is successful, the value of the lenght is displayed in the \
result window.\r\n\
Press the push button to execute and see the status in the result window.";

/*---------------------------------------------------------------------------*/
char DescTest7_Step1_1[]="\
Test 7:step 1/1:\r\n\
-------------------------\r\n\
This test set the length of the window title LEN_TITLE_PKEY to  8 bytes.\r\n\
This is usefull to limit the length of the title to the lenght of the buffer \
used to get the window title.\r\n\
Now a maximum of 8 bytes of the title will be received when getting the \
window title.\r\n\
Press the push button to execute and see the status in the result window.";

/*---------------------------------------------------------------------------*/
char DescTest8_Step1_1[]="\
Test 8:step 1/1:\r\n\
-------------------------\r\n\
This test get the window title TITLE_PKEY.\r\n\
If the result is successful, the title is displayed in the result window.\r\n\
Press the push button to execute and see the status in the result window.";

/*---------------------------------------------------------------------------*/
char DescTest9_Step1_1[]="\
Test 9:step 1/1:\r\n\
-------------------------\r\n\
This test set window title TITLE_PKEY to: This is a new title.\r\n\
If the result is successful, the new title is display in the caption bar if \
it exits.\r\n\
Press the push button to execute and see the status in the result window.";

/*---------------------------------------------------------------------------*/
char DescTest10_Step1_1[]="\
Test 10:step 1/1:\r\n\
-------------------------\r\n\
This test get the window style STYLE_PKEY.\r\n\
If the result is successful, the style is displayed in the result window.\r\n\
Press the push button to execute and see the status in the result window.";

/*---------------------------------------------------------------------------*/
char DescTest11_Step1_1[]="\
Test 11:step 1/1:\r\n\
-------------------------\r\n\
This test set window style STYLE_PKEY to: 0.\r\n\
Press the push button to execute and see the status in the result window.";

/*---------------------------------------------------------------------------*/
char DescTest12_Step1_1[]="\
Test 12:step 1/1:\r\n\
-------------------------\r\n\
This test get the window position : XY_PKEY";

/*---------------------------------------------------------------------------*/
char DescTest13_Step1_1[]="\
Test 13:step 1/1:\r\n\
-------------------------\r\n\
This test set the window position : XY_PKEY.\r\n\
Choose the X and Y values with the spin control 1 and 2 then press the push \
button to execute and see the status in the result window.";

/*---------------------------------------------------------------------------*/
char DescTest14_Step1_1[]="\
Test 14:step 1/1:\r\n\
-------------------------\r\n\
This test get the window size : SIZE_PKEY.";

/*---------------------------------------------------------------------------*/
char DescTest15_Step1_1[]="\
Test 15:step 1/1:\r\n\
-------------------------\r\n\
This test set the window size : SIZE_PKEY to 0.\r\n\
Press the push button to execute and see the status in the result window.";
/*---------------------------------------------------------------------------*/
char DescTest16_Step1_1[]="\
Test 16:step 1/1:\r\n\
-------------------------\r\n\
This test get the key range (FirstKey and LastKey) of the keyboard.";

/*---------------------------------------------------------------------------*/
char DescTest17_Step1_1[]="\
Test 17:step 1/1:\r\n\
-------------------------\r\n\
This test set the key range (RANGE_PKEY) of the keyboard.\r\n\
Choose the First key and Last key values with the spin control 1 and 2 then \
press the push button to execute and see the status in the result window.";

/*---------------------------------------------------------------------------*/
char DescTest18_Step1_1[]="\
Test 18:step 1/1:\r\n\
-------------------------\r\n\
This test get the size of white keys (width and height).";

/*---------------------------------------------------------------------------*/
char DescTest19_Step1_1[]="\
Test 19:step 1/1:\r\n\
-------------------------\r\n\
This test set the size of white keys (width and height).";

/*---------------------------------------------------------------------------*/
char DescTest20_Step1_1[]="\
Test 20:step 1/1:\r\n\
-------------------------\r\n\
This test get the Flags of the pianokey window.";

/*---------------------------------------------------------------------------*/
char DescTest21_Step1_1[]="\
Test 21:step 1/1:\r\n\
-------------------------\r\n\
This test set the Flags of the pianokey window to 0.";

/*---------------------------------------------------------------------------*/
char DescTest22_Step1_1[]="\
Test 22:step 1/1:\r\n\
-------------------------\r\n\
This test try to get the state of a key.";

/*---------------------------------------------------------------------------*/
char DescTest23_Step1_1[]="\
Test 23:step 1/1:\r\n\
-------------------------\r\n\
This test set the state (On/Off) of a key on the keyboard.\r\n\
Choose the state key and the  key number values with the spin control 1 and \
2. A value of 0 for state indicate a 'KeyOff' state. A value different \
of zero indicate a 'KeyOn' state.\r\n\
Press the push button to execute and see the status in the result window.";

/*---------------------------------------------------------------------------*/
char DescTest24_Step1_1[]="\
Test 24:step 1/1:\r\n\
-------------------------\r\n\
This test get and set the whole PianoKey window information INFOS_PKEY:\r\n\
	1)First the  test get the window informations.\r\n\
	2)The width and height of white key are changed.\r\n\
	3)The new window informations structure is set.";
