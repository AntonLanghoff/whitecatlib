//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Tutorial.rc
//
#define IDD_TUTORIAL                    101
#define IDD_ABOUT                       102
#define IDB_STAFF                       103
#define IDB_PIANO                       105
#define IDC_EDIT_TEST                   1000
#define IDC_SPIN_TEST                   1001
#define IDC_EDIT_SPIN_TEST              1002
#define IDC_EDIT_RES                    1003
#define IDC_EDIT_NOTIFY                 1004
#define IDC_GBOX_NOTIFY                 1009
#define IDEXIT                          1010
#define IDEXEC                          1011
#define IDC_STATIC0_NOTIFY              1013
#define IDC_STATIC1_NOTIFY              1014
#define IDC_STATIC2_NOTIFY              1015
#define IDC_STATIC3_NOTIFY              1016
#define IDC_ABOUT                       1017
#define IDC_CHECK_NOTIFY                1021
#define IDC_EDIT_SPIN_INFOS1            1024
#define IDC_STATIC_ABOUT                1026
#define IDC_EDIT_SPIN_INFOS2            1026
#define IDC_VERSION_MS                  1027
#define IDC_SPIN_INFOS2                 1027
#define IDC_VERSION_MSNOTES             1028
#define IDC_EDIT_SPIN_INFOS3            1028
#define IDC_VERSION_PIANOKEY            1028
#define IDC_RESTART                     1029
#define IDC_SPIN_INFOS3                 1030
#define IDC_SPIN_INFOS1                 1031
#define IDC_STATIC_EMAIL                1032

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1033
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
