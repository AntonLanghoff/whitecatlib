/*****************************************************************************
  Module: WinPaint.c

  R�le: 	Processing the WM_PAINT message.
 
  e-mail: Jean-Jacques.CERESA@enac.fr
/*****************************************************************************/
#define STRICT
#define  __Windows__
#include "Piano.h"

#define HEIGHT_MARK 5

/******************************************************************************
******************************************************************************/
void SetUpdateRectKey(PKEYinfosPtr Infos, RECT * Rect, Byte Key)
{
	short Width,Height;

	if (IsBlackKey(SemiTone(Key)))
			{ Width = WidthBkey(Infos); Height = HeightBkey(Infos);} 
	else	{ Width = WidthWkey(Infos); Height = HeightWkey(Infos);} 

	Rect->left = GetXposKey (&Infos->Param, Key);
	Rect->right = Rect->left + Width;
	Rect->bottom = Height-1;
	Rect->top = Rect->bottom - (HEIGHT_MARK + 1);
}

COLORREF TabSliderColors[NBR_SENSORS]={
	RGB(255,0,0),RGB(0,255,0),RGB(0,128,255)};	

/******************************************************************************
******************************************************************************/
Bool WinPaintPKEY (HWND hWnd)
{
	Bool r=TRUE;
	PAINTSTRUCT ps;
	HDC hdc  ;
	PKEYinfosPtr  Infos ;
	Byte i;
	HBRUSH hBrush;
	
	if (! GETPKEYINFOS(Infos,hWnd)) return(FALSE);
	
	hdc=BeginPaint(hWnd,&ps);

 	//-------------------------------------------------------------------------
	// Draw the white key first
	for( i= FirstKey(Infos); i <= LastKey(Infos); i++ )
	{
		if (!IsBlackKey(SemiTone(i)))
		{
			// Draw the white rectangle
			POINT Rect[4];
			Rect[0].x = Rect[3].x = GetXposKey (&Infos->Param, i);
			Rect[1].x = Rect[2].x = Rect[0].x + WidthWkey(Infos) - 1;
			
			Rect[0].y = Rect[1].y = 0;
			Rect[2].y = Rect[3].y = HeightWkey(Infos)-1;;

			Polygon(hdc,Rect,4);             
			if (IsKeyOn(Infos,i))
			{	// Draw the 'Key On' mark ( a small rectangle ).  
				RECT r;
				r.left = Rect[0].x + 2; r.right = Rect[1].x - 1;
				r.bottom = Rect[2].y - 1; r.top = r.bottom - HEIGHT_MARK;
				hBrush = CreateSolidBrush(RGB(255,0,0));
				FillRect( hdc,&r, hBrush);
				DeleteObject(hBrush);
			}
		}
	}
	//-------------------------------------------------------------------------
	// Draw black key last
	for( i= FirstKey(Infos); i <= LastKey(Infos); i++ )
	{
		if (IsBlackKey(SemiTone(i)))
		{
			// Fill the black rectangle
			RECT r ;
			r.left = GetXposKey (&Infos->Param, i);
			r.right = r.left + WidthBkey(Infos);
			r.top =0;
			r.bottom = HeightBkey(Infos);
			FillRect( hdc,&r, GetStockObject(BLACK_BRUSH));
			if (IsKeyOn(Infos,i))
			{	// Draw the 'Key On' mark ( a small rectangle ). 
				r.left++; r.right--; r.bottom--; r.top = r.bottom - HEIGHT_MARK;
				hBrush = CreateSolidBrush(RGB(255,255,255));
				FillRect( hdc,&r,hBrush);
				DeleteObject(hBrush);
			}
		}
	}
	//-------------------------------------------------------------------------
	// Draw the sensors sliders
	for( i= 0; i < NbrSensors(Infos); i++ )
	{
		// Draw the frame of slider.
		POINT Rect[4];
		HGDIOBJ OldObj;
		
		Rect[0].x = Rect[3].x = WidthKeyBrd(Infos) -1 + 
								i* (WidthSlider - 1);
		Rect[1].x = Rect[2].x = Rect[0].x + WidthSlider - 1;
			
		Rect[0].y = Rect[1].y = 0;
		Rect[2].y = Rect[3].y = HeightSlider - 1;;
		hBrush = GetStockObject(LTGRAY_BRUSH);
		OldObj = SelectObject(hdc, hBrush);
		Polygon(hdc,Rect,4);             
		DeleteObject(SelectObject(hdc, OldObj));
		//--------------------------------------------------------------------
		// Draw the button of slider.
		{	// mark key 
			RECT r;
			r.left = Rect[0].x + 2; r.right = Rect[1].x - 1;
			r.top = SliderButtLP(Infos,i); r.bottom = r.top + HEIGHT_S_BUTT; 
			hBrush = CreateSolidBrush(TabSliderColors[IdSensor(Infos,i)]);
			FillRect( hdc,&r,hBrush );
			DeleteObject(hBrush);
			// Draw the horizontal median line of button.
			{
				int y = r.top + HEIGHT_S_BUTT/2 ;
				MoveToEx( hdc,r.left ,y ,NULL);
				LineTo(hdc, r.right,y);
			}
		}
	}	
	//-------------------------------------------------------------------------
	EndPaint(hWnd,&ps);
	return r;
}
