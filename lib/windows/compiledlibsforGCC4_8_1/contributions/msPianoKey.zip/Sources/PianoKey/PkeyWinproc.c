/******************************************************************************
  Module:   PkeyWinProc.c          
  
  e-mail: Jean-Jacques.CERESA@enac.fr
*******************************************************************************/

#define STRICT

#define  __Windows__
#include "Piano.h"


/*****************************************************************************
 PianoKey window procedure
******************************************************************************/
LRESULT CALLBACK PianoKeyWinProc (HWND hWnd, UINT message, UINT wParam,
							  LONG lParam)
{
	switch(message)
	{
		//-- Window is create -------------------------------------------------
		case WM_CREATE:
		{	
			if (WinCreatePKEY(hWnd,((LPCREATESTRUCT)lParam)->lpCreateParams))
			{	
				return 0;
			}
			else	return -1;	// Window will be destroyed.
			
		}
		//---------------------------------------------------------------------
		// The window is repainted
		case WM_PAINT:
			WinPaintPKEY (hWnd);
			return 0;

		//-- Mouse cursor is moving -------------------------------------------
		case WM_MOVE:
			WinMovePKEY (hWnd,LOWORD (lParam), HIWORD (lParam)); 
			return 0;

		//-- User request to close the window ---------------------------------
		case WM_CLOSE:
			WinClosePKEY (hWnd); 
			return 0;
		//-- Window is about to be destroyed ----------------------------------
		case WM_DESTROY:
			WinDestroyPKEY (hWnd );
			return (0) ;
	}
	// The message is passed to the event manager.
	if (MsgHandler (hWnd,message,wParam, lParam)) return 0;
	// Default processing of the message.
	return DefWindowProc (hWnd, message, wParam, lParam) ;
}

