/******************************************************************************
  Module: EventMgr.c

  Purpose: Events manager and drawing states manager. 	
		   The manager process the 'mouse' and 'keyboard' message.

  e-mail: Jean-Jacques.CERESA@enac.fr	
/******************************************************************************/
#define STRICT
#define  __Windows__
#define __BuildLib__

#include "piano.h"

/******************************************************************************
 Check if mouse cursor is on a key.
 Return true if the cursor is on the key, false otherwise.
******************************************************************************/
Bool IsCursorOnKey(PKEYinfosPtr Infos, short xCursor, short yCursor, Byte Key)
{
	short Width, Height;
	RECT Rect ;
	POINT Point={xCursor,yCursor};

	if (IsBlackKey(SemiTone(Key)))
	{	Width = WidthBkey(Infos);	Height = HeightBkey(Infos); }
	else
	{	Width = WidthWkey(Infos);	Height = HeightWkey(Infos); }

	Rect.left = GetXposKey (&Infos->Param, Key);
	Rect.right = Rect.left + Width;
	Rect.top =0;
	Rect.bottom = Height;
	if(PtInRect(&Rect, Point)) { Infos->SearchKey = Key; return True; }
	else return False;
}


/******************************************************************************
 Search the key under the mouse cursor.
 Return true if the cursor is on a key, false otherwise.

******************************************************************************/
Bool SearchOnKey(PKEYinfosPtr Infos, short xCursor, short yCursor)
{
	Byte i;

	yMouse(Infos) = yCursor;
	// Search on black key first
	for( i= FirstKey(Infos); i <= LastKey(Infos); i++ )
	{
		if (IsBlackKey(SemiTone(i)))
			if(IsCursorOnKey(Infos, xCursor,yCursor,i)) return True;
	}
	// Search on white key last.
	for( i= FirstKey(Infos); i <= LastKey(Infos); i++ )
	{
		if (!IsBlackKey(SemiTone(i)))
			if(IsCursorOnKey(Infos, xCursor,yCursor,i)) return True;
	}
	return False;
}

/******************************************************************************
 Updating a key at state 'On'
 If necessary the key is repaint to show the new state.
******************************************************************************/
void UpdateKeyOn(PKEYinfosPtr Infos, Byte Key, Byte Left)
{
	if(Left) DisKeyOff(Infos,Key); 
	else	EnKeyOff(Infos,Key);
	if ( !IsKeyOn(Infos,Key) )
	{
		RECT Rect;
		SetKeyOn(Infos,Key);	/* The state is changed to 'On' */
		/* The key is repaint */
		SetUpdateRectKey(Infos, &Rect,Key);
		InvalidateRect(Infos->hWnd,&Rect,False);
		// Notify the parent
		if (!IsApi(Infos) && Infos->ApplNotifyPtr) 
		{
			Word Height;
			Byte Velocity;
			if (IsBlackKey(SemiTone(Key)))	Height = HeightBkey(Infos);
			else							Height = HeightWkey(Infos);
			Velocity = (127 * yMouse(Infos)) / (Height-1) ;	
			Infos->ApplNotifyPtr(Infos->hWnd,SKEY_PKEY,
							 MakeSKEY_PKEY_Vel(True,Key,Velocity));
		}
	}
}

/******************************************************************************
 Updating a key at state 'Off'
 If necessary the key is repaint to show the new state.
******************************************************************************/
void UpdateKeyOff(PKEYinfosPtr Infos,Byte Key)
{
	if (IsKeyOn(Infos,Key))
	{
		RECT Rect;
		ResetKeyOn(Infos,Key);/* The state is changed to 'Off' */
		/* The key is repaint */
		SetUpdateRectKey(Infos, &Rect,Key);
		InvalidateRect(Infos->hWnd,&Rect,False);
		// Notify the parent
		if (!IsApi(Infos) && Infos->ApplNotifyPtr) 
		{
			Infos->ApplNotifyPtr(Infos->hWnd,SKEY_PKEY,
							 MakeSKEY_PKEY_Vel(False,Key,0));
		}
	}
}

/******************************************************************************
 Updating all the key when draging the mouse cursor.
 If necessary the key is repaint to show the new state.
******************************************************************************/
void  UpdateDragKey(PKEYinfosPtr Infos, short xCursor, short yCursor)
{
	Byte i;
	Bool f=False;

	yMouse(Infos) = yCursor;
	//-------------------------------------------------------------------------
	// Search on black key first
	for( i= FirstKey(Infos); i <= LastKey(Infos); i++ )
	{	
		if (IsBlackKey(SemiTone(i)))
		{
			if (f || !(f=IsCursorOnKey(Infos, xCursor,yCursor,i)))	
					UpdateKeyOff(Infos,i);
			else	UpdateKeyOn(Infos,i,0);
		}
	}
	//-------------------------------------------------------------------------
	// Search on white key last.
	for( i= FirstKey(Infos); i <= LastKey(Infos); i++ )
	{
		if (!IsBlackKey(SemiTone(i)))
		{   
			if (f || !(f=IsCursorOnKey(Infos, xCursor,yCursor,i)))	
					UpdateKeyOff(Infos,i);
			else	UpdateKeyOn(Infos,i,0);
		}
	}
}


/******************************************************************************
 Search if the mouse cursor is on a slider button.
 On return, 
	True, if the search is found. The IdSlider is saved in PKEYinfos.
	Flase, if the search isn't found.
******************************************************************************/
Bool SearchOnSliderButt(PKEYinfosPtr Infos,short xCursor, short yCursor)
{
	POINT Point={xCursor,yCursor};
	Byte i;
	for( i= 0; i < NbrSensors(Infos); i++ )
	{
		RECT r;
		r.left = WidthKeyBrd(Infos) -1 + i* (WidthSlider - 1);
		r.right = r.left + WidthSlider - 2;
		r.left += 2;
		r.top = SliderButtLP(Infos,i); r.bottom = r.top + HEIGHT_S_BUTT; 
		
		if(PtInRect(&r, Point)) 
		{ 
			yMouse(Infos) = yCursor;
			SearchIdSlider(Infos) = i;
			return True; 
		}
	}	
	return False;
}

/******************************************************************************
 Update the slider indicated by SearchIdSlider.
	- Update the y position ValSliderLP whith NewValLP.
	  Flags true says that NewValLP is the new value.
	  Flags false says that the new value are defaults values which depends of 
      the sensor associated whith the slider.
	- Update the drawing of the slider.
******************************************************************************/
void UpdateDragSensor(PKEYinfosPtr Infos, short NewValLP, Byte Flags)
{
	Byte IdSlider = SearchIdSlider(Infos);
	Byte IdSensor = IdSensor(Infos,IdSlider);
	
	short CurValLP ;		// Current position in logicals pixels.
	long EvInfos;			// Infos event for notify.
 
	CurValLP = ValSliderLP(Infos,IdSlider);
	//-------------------------------------------------------------------------
	switch (IdSensor)
	{
		case IDS_AFTER_TOUCH:
			if (! Flags) NewValLP = 0;	// Default value: 0 
			// Current value for AFTER_TOUCH: 0 to 127 (7 bits value)
			{
				short CurVal ;			// Current value of the sensor.
				CurVal = (127 * NewValLP) / RangeSliderLP;
				EvInfos = MakeN_AFTER_TOUCH(CurVal,Key(Infos));
			}
			break;
		case IDS_PITCH_WHEEL:
			if (! Flags) NewValLP = MedValLP;	// default value is centered
			// Current value for PITCH_WHEEL: 0 to 16383 (14 bits value)
			// 8192 to 16383 represent the values: 0 to 8191 
			// 0 to 8191     represent the values: - 8192 to -1
			{
				short ValLP = NewValLP - MedValLP;
				// CurVal is : 0 to +8191
				if ( ValLP >= 0) EvInfos = (8191 * ValLP) /  PosRangeLP;	
				// CurVal is : -8192 to -1
				else  EvInfos = (8192 * ValLP) /  NegRangeLP;	
			}
			break;
		case IDS_MOD_WHEEL:
			// Current value for AFTER_TOUCH: 0 to 16383(14 bits value)
			if (! Flags) NewValLP = CurValLP;
			EvInfos = (16383 * NewValLP) / RangeSliderLP;
			break;
	}
	//-------------------------------------------------------------------------
	if ( NewValLP != CurValLP)
	{
		ValSliderLP(Infos,IdSlider)= NewValLP;
		// Update the button position on screen
		InvalidateRect(Infos->hWnd,&Infos->RectSlider,False);
		// Notify the parent
		if ( Infos->ApplNotifyPtr) 
		{
			Byte InfosId = IdSensor + N_AFTER_TOUCH;
			Infos->ApplNotifyPtr(Infos->hWnd, InfosId,EvInfos) ;
		}
	}
}

/******************************************************************************
 Search if the mouse cursor is on a slider area.
 On return, 
	True, if the search is found. The IdSlider is saved in PKEYinfos.
	Flase, if the search isn't found.
******************************************************************************/
Bool SearchOnSliderArea(PKEYinfosPtr Infos,short xCursor, short yCursor)
{
	Bool s;
	POINT Point={xCursor,yCursor};

	Byte IdSlider = SearchIdSlider(Infos);
	short NewValLP;
	Infos->RectSlider.left = WidthKeyBrd(Infos) -1 +  IdSlider * (WidthSlider - 1);
	Infos->RectSlider.right = Infos->RectSlider.left + WidthSlider;
	Infos->RectSlider.top = 0; 
	Infos->RectSlider.bottom = Infos->RectSlider.top + HeightSlider; 
		
	if(PtInRect(&Infos->RectSlider, Point)) 
	{ 
		// Update the new value ValSliderLP
		// Adjust the yCursor
		NewValLP = ValSliderLP(Infos,IdSlider);
		yCursor = Max(Min(MinSliderLP,yCursor), 1);
		NewValLP += (yMouse(Infos) - yCursor);
		NewValLP = Min(Max(0,NewValLP),RangeSliderLP); 
		yMouse(Infos) = yCursor;	// Save the y mouse for next moving.
		s =True; 
	}
	else  s= False;
	UpdateDragSensor(Infos,NewValLP, s);
	return s;
}

/******************************************************************************
 Messages manager:
 
 This manager handle the state of the 'drawing state machine' in function of
 mouse messages and computer keyboard actions of the user.

******************************************************************************/
Bool MsgHandler (HWND hWnd, UINT message, UINT wParam, LONG lParam)
{
	Byte State,Search;

	PKEYinfosPtr  Infos ;
	
	if (! GETPKEYINFOS(Infos,hWnd)) return(False);
	
	
	//-------------------------------------------------------------------------
	// If the 'PianoKey' is not interactive, all the mouse messages are ignored.
	if(!IsEditPKEY(Style(Infos))) 
	{
		SetCursor(Infos->hCursor);
		return False;
	}
	
	//-------------------------------------------------------------------------
	// The 'PianoKey' is  interactive, all the mouse messages are processed.
	State= Infos->StateDraw;
	switch(message)
	{
		//-- Mouse moving message ---------------------------------------------
		case WM_MOUSEMOVE:
			switch (State)
			{
				case DRAG_KEY:
					UpdateDragKey(Infos, LOWORD (lParam), HIWORD (lParam));
					break;
				case SET_ON_SENSOR:
					if ( SearchOnSliderButt(Infos, LOWORD (lParam),
											HIWORD (lParam)))
						Infos->StateDraw = DRAG_SENSOR;
					break;
				case DRAG_SENSOR:
					if (!SearchOnSliderArea(Infos, LOWORD (lParam),
						HIWORD (lParam)))
					Infos->StateDraw = SET_ON_SENSOR;
					break;
			}
			SetCursor(Infos->hCursor);
			break;
		//-- Left button of mouse is down -------------------------------------
		case WM_LBUTTONDOWN:
		{			
			RECT SliderRect;
			POINT PtSlider;
			Search= SearchOnKey(Infos, LOWORD (lParam), HIWORD (lParam));
			if (Search)
			{
				UpdateKeyOn(Infos,Key(Infos),0);
				Infos->StateDraw = DRAG_KEY;
			}
			// Check if the Ctrl key is pressed
			if (wParam & MK_CONTROL && NbrSensors(Infos))	
			{
				// the mouse cursor is clipped in the sliders area
				SliderRect.left = WidthKeyBrd(Infos)-1; SliderRect.top =0;
				ClientToScreen(hWnd ,(LPPOINT) &SliderRect);
				SliderRect.right = WidthClient(Infos);
				SliderRect.bottom = HeightWkey(Infos);
				ClientToScreen(hWnd , (LPPOINT)&SliderRect.right);
				Infos->StateDraw = SET_ON_SENSOR;
			}
			else
			{	// the mouse cursor is clipped in the keyboard area

				SliderRect.left =0; SliderRect.top =0;
				ClientToScreen(hWnd ,(LPPOINT) &SliderRect);
				SliderRect.right = WidthKeyBrd(Infos);
				SliderRect.bottom = HeightWkey(Infos);
				ClientToScreen(hWnd , (LPPOINT)&SliderRect.right);
			}
			//-------------------------------------------------------------
			ClipCursor(&SliderRect);	// Mouse cursor is clipped now !
			
			// the mouse cursor is moved in the clipped area
			PtSlider.x= LOWORD (lParam); PtSlider.y= HIWORD (lParam); 
			ClientToScreen(hWnd , &PtSlider);
			SetCursorPos(PtSlider.x,PtSlider.y);
			break;
		}
		//-- Right button of mouse is down ------------------------------------
		case WM_RBUTTONDOWN:
			Search= SearchOnKey(Infos, LOWORD (lParam), HIWORD (lParam));
			if(Search)
			{
				UpdateKeyOn(Infos,Key(Infos),(byte)!IsKeyOn(Infos,Key(Infos)));
				Infos->StateDraw = SET_ON_KEY;
			}
			break;

		//-- Left button of mouse is up ---------------------------------------
		case WM_LBUTTONUP:
		//-- Right button of mouse is up --------------------------------------
		case WM_RBUTTONUP:
			switch (State)
			{
				case SET_ON_KEY:
				case DRAG_KEY:
					Search= SearchOnKey(Infos,LOWORD(lParam),
												HIWORD(lParam));
					break;
				case DRAG_SENSOR: 
					// Update the key for DRAG_SENSOR state.
					UpdateDragSensor(Infos,0, False);
				case SET_ON_SENSOR:
					Search = True;
			}
			// Update the key for SET_ON_KEY,DRAG_KEY and SET_ON_SENSOR states
			if(Search && IsEnKeyOff(Infos,Key(Infos)))
				UpdateKeyOff(Infos,Key(Infos));
			ClipCursor(NULL);
			Infos->StateDraw = OFF;
			break;
		
		//----------------------------------------------------------------------
		default: return False;
	}
	return True;
}
