/******************************************************************************
  PianoKeyInfos.c

  e-mail: Jean-Jacques.CERESA@enac.fr	
******************************************************************************/

#define STRICT
#define __Windows__		// Application Windows 
#define __BuildLib__
#include "Piano.h"


/*----------------------------------------------------------------------------
	Getting and setting general informations about a PianoKey window.
-----------------------------------------------------------------------------*/
/* Getting informations  API */
Byte 	PIANOKEYAPI GetPianoKeyInfos ( 
					hPianoKey	hWndPianoKey,	/* Handle of PianoKey window */
					Byte		InfosId,		/* Id of infos to retrieve	*/ 
					InfosPtr	InfosPKEY		/* Pointer on infos to get	*/
					)
{
	PKEYinfosPtr  Infos ;
	if (! GETPKEYINFOS(Infos,hWndPianoKey))		return PKEYerrBadHandle;
	else
	{
		PKEYerror(Infos) = PKEYok;
		switch (InfosId)
		{
			/* Length of window title */
			case LEN_TITLE_PKEY:
				*(Byte *)InfosPKEY = LenTitle(Infos);				
				break;
			/* Window title */
			case TITLE_PKEY:
				GetWindowText(hWndPianoKey,InfosPKEY,LenTitle(Infos));				
				break;
			/* Window style */
			case STYLE_PKEY:
				*(Word *)InfosPKEY = Style(Infos);
				break;
			/* Window position X and Y */
			case XY_PKEY:
				*(long *)InfosPKEY = MakeXY_PKEY(xPos(Infos),yPos(Infos));
				break;
			/* Window size */
			case SIZE_PKEY:
				*(long *)InfosPKEY = MakeSIZE_PKEY(Width(Infos),Height(Infos));
				break;
			/* Range of the Piano keyboard: First key and Last key */
			case RANGE_PKEY:
				*(Word *)InfosPKEY = MakeRANGE_PKEY(FirstKey(Infos),
													LastKey(Infos));
				break;
			/* Size (width and Height) of white keys */
			case SIZE_WKEY:
				*(long *)InfosPKEY = MakeSIZE_WKEY(WidthWkey(Infos),
													HeightWkey(Infos));
				break;
			/* Validations Flags */
			case FLAGS_PKEY:
				*(Byte *)InfosPKEY = FlagsPkey(Infos);
				break;
			/* State of a key */
			case SKEY_PKEY:
				PKEYerror(Infos) = PKEYerrBadOp;
				break;
			/* All the windows informations */
			case INFOS_PKEY:		/* All the window informations (R-W) */
				*(PianoKeyInfosPtr)InfosPKEY = Infos->Param.PianoKey; 
				break;
			default: PKEYerror(Infos) = PKEYerrBadIdInfos;
		}
	}
	return PKEYerror(Infos);
}

//----------------------------------------------------------------------------
/* Setting informations API */
Byte 	PIANOKEYAPI SetPianoKeyInfos ( 
				hPianoKey	hWndPianoKey,	/* Handle of PianoKey window	*/
				Byte		InfosId,		/* Id of infos to retrieve		*/ 
				long		InfosPKEY		/* Value to set					*/
				)
{
	PKEYinfosPtr  Infos ;
	Param Param;			// working parameters.

	if (! GETPKEYINFOS(Infos,hWndPianoKey))		return PKEYerrBadHandle;
	else
	{
		SetApi(Infos);		// Signal that an API call is running
		Param.PKEYerror = PKEYok;
		switch (InfosId)
		{
			/* Length of window title */
			case LEN_TITLE_PKEY:
				LenTitle(Infos) = (Byte)InfosPKEY;
				break;
			/* Window title */
			case TITLE_PKEY:
				SetWindowText(hWndPianoKey,(char *)InfosPKEY);
				LenTitle(Infos) = strlen((char *)InfosPKEY)+1;
				break;
			/* Window style */
			case STYLE_PKEY:
				Param.PKEYerror = PKEYerrBadOp;
				break;
			/* Window position X and Y */
			case XY_PKEY:
				MoveWindow(Infos->hWnd, XposXY_PKEY(InfosPKEY),
										YposXY_PKEY(InfosPKEY),
										Width(Infos),Height(Infos),True);
				break;
			/* Window size */
			case SIZE_PKEY:
				Param.PKEYerror = PKEYerrBadOp;
				break;

			/* Range of the Piano keyboard: First key and Last key */
			case RANGE_PKEY:
				Param = Infos->Param;
				Param.PianoKey.FirstKey = FirstKeyRANGE_PKEY((Word)InfosPKEY);
				Param.PianoKey.LastKey = LastKeyRANGE_PKEY(((Word)InfosPKEY));
				if (!InitCheckParam(&Param, Null)) break;
				Infos->Param = Param;
				MoveWindow(Infos->hWnd, xPos(Infos),yPos(Infos),
										Width(Infos),Height(Infos),True);
				break;
			/* Size (width and Height) of white keys */
			case SIZE_WKEY:
				Param = Infos->Param;
				Param.PianoKey.WidthWkey = WidthSIZE_WKEY(InfosPKEY);
				Param.PianoKey.HeightWkey = HeightSIZE_WKEY(InfosPKEY);
				if (!InitCheckParam(&Param, Null)) break;
				Infos->Param = Param;
				MoveWindow(Infos->hWnd, xPos(Infos),yPos(Infos),
										Width(Infos),Height(Infos),True);
				break;
			/* Validations Flags */
			case FLAGS_PKEY:
				Param = Infos->Param;
				Param.PianoKey.Flags = (Byte)InfosPKEY;
				if (!InitCheckParam(&Param, Null)) break;
				Infos->Param = Param;
				MoveWindow(Infos->hWnd, xPos(Infos),yPos(Infos),
										Width(Infos),Height(Infos),True);
				break;
			/* State of a key */
			case SKEY_PKEY:
				{
					Byte NumKey = NumKeySKEY_PKEY(InfosPKEY);
					
					if(!IsCheckKey(Infos,NumKey))
					{	Param.PKEYerror = PKEYerrBadInfos; break;}
					// Set the state of NumKey
					if (StateSKEY_PKEY(InfosPKEY))UpdateKeyOn(Infos,NumKey,0); 
					else UpdateKeyOff(Infos,NumKey);
				}
				break;
			/* All the windows informations */
			case INFOS_PKEY:		/* All the window informations 	*/
				Param.PianoKey = *(PianoKeyInfosPtr)InfosPKEY;
				Param.PianoKey.LenTitle = Infos->Param.PianoKey.LenTitle;
				Param.PianoKey.Style = Infos->Param.PianoKey.Style;
				if (!InitCheckParam(&Param, Null)) break;
				Infos->Param = Param;
				MoveWindow(Infos->hWnd, xPos(Infos),yPos(Infos),
										Width(Infos),Height(Infos),True);
				break;
			default: Param.PKEYerror = PKEYerrBadIdInfos;
		}
		ResetApi(Infos);
	}
	return Param.PKEYerror;
}


