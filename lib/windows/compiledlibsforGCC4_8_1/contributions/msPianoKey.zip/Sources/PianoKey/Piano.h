/*****************************************************************************
  Piano.h

  e-mail: Jean-Jacques.CERESA@enac.fr
******************************************************************************/
#ifndef __PIANO_H__
#define __PIANO_H__
#include "PianoKey.h"
#include "Resource.h"


#if 0
/*-----------------------------------------------------------------------------
 Pitch GM
-----------------------------------------------------------------------------*/
// Pitch for octave 0
#define Cf  -1
#define C	0
#define Cs	1
#define Df	Cs
#define D	2
#define Ds	3
#define Ef	Ds
#define E	4
#define Es	5
#define Ff	4
#define F	5
#define Fs	6
#define Gf	Fs
#define G	7
#define Gs	8
#define Af	Gs
#define A	9
#define As	10
#define Bf	As
#define B	11
#define Bs	12
#endif

#define GM_PITCH_MAX	127
// gmP return a GM pitch from note name and octave number
#define gmP(Pitch,Oct)	( (Pitch + ((Oct) * 12)) )


/*-----------------------------------------------------------------------------
  Macros to set  informations to the application:
-----------------------------------------------------------------------------*/
/* Build a SKEY_PKEY information */
#define MakeSKEY_PKEY_Vel(State,NumKey,Vel) \
	(MakeLongInfos(MakeWordInfos(State,NumKey),MakeWordInfos(Vel,0))) 

/* Build an AFTER_TOUCH event */
#define MakeN_AFTER_TOUCH(Press,NumKey) \
			(MakeLongInfos(MakeWordInfos(Press,NumKey),0)) 

/* Build a SIZE_PKEY information */
#define MakeSIZE_PKEY(w,h) (MakeLongInfos(w,h)) 


/*-----------------------------------------------------------------------------
  Macros to get pitch and type of key.
-----------------------------------------------------------------------------*/
#define BLACK_TYPE 1	// Type of black key
#define IsBlackKey(p)	((TabKeyType[p] & BLACK_TYPE))

#define PitchRelOct(NumKey)	(NumKey %12)
// SemiTone return the semitone number (0-->11) of Pitch
#define SemiTone(Pitch)	(((Pitch) % 12)) 
#define OctNum(Pitch)	(((Pitch) / 12))


/*-----------------------------------------------------------------------------
  Macros to access  key state
-----------------------------------------------------------------------------*/
#define Key(p) (p->SearchKey)
#define MaskState(k)	((1 << (k & 0xf) ))

#define WordState(p,k)	( p->TabKeyState[(k & 0x7f) >> 4] ) 
#define IsKeyOn(p,k)	(( WordState(p,k) & MaskState(k) ))
#define SetKeyOn(p,k)	( WordState(p,k) |= MaskState(k)  )
#define ResetKeyOn(p,k)	( WordState(p,k) &= ~MaskState(k) )

#define WordEnable(p,k)	( p->TabEnableKeyOff[(k & 0x7f) >> 4] )
#define IsEnKeyOff(p,k)	(( WordEnable(p,k) &  MaskState(k)	 ))
#define EnKeyOff(p,k)	( WordEnable(p,k) |= MaskState(k)     )
#define DisKeyOff(p,k)	( WordEnable(p,k) &= ~MaskState(k)    )

/*-----------------------------------------------------------------------------
  Macros to access  PionoKey window information.
-----------------------------------------------------------------------------*/
#define LenTitle(p)			(p->Param.PianoKey.LenTitle) 
#define Style(p)			(p->Param.PianoKey.Style) 
#define xPos(p)				(p->Param.PianoKey.xPos) 
#define yPos(p)				(p->Param.PianoKey.yPos) 
#define FirstKey(p)			(p->Param.PianoKey.FirstKey)
#define LastKey(p)			(p->Param.PianoKey.LastKey)
#define WidthWkey(p)		(p->Param.PianoKey.WidthWkey)
#define HeightWkey(p)		(p->Param.PianoKey.HeightWkey)
#define FlagsPkey(p)		(p->Param.PianoKey.Flags)

#define WidthKeyBrd(p)		(p->Param.WidthKeyBrd)
#define WidthClient(p)		(p->Param.WidthClient)
#define WidthBkey(p)		(p->Param.WidthBkey)
#define HeightBkey(p)		(p->Param.HeightBkey)
#define Width(p)			(p->Param.WidthWnd)
#define Height(p)			(p->Param.HeightWnd)
#define NbrSensors(p)		(p->Param.NbrSensors)
#define PKEYerror(p)		(p->Param.PKEYerror)

#define yMouse(p)			(p->yMouse)
#define SearchIdSlider(p)	(p->SearchIdSlider)
/*-----------------------------------------------------------------------------
  Macros to check  key number
-----------------------------------------------------------------------------*/
#define IsCheckKey(p,k)	( (FirstKey(p) <= k && k <= LastKey(p)) )


#define API_F		0x01	// Appel PKEYAPI en cours

// IsAPI retourne TRUE lorsque un appel MSNOTEAPI est en cours.
#define IsApi(p)			( (p->Flags & API_F) )
#define SetApi(p)			( p->Flags |= API_F  )
#define ResetApi(p)			( p->Flags &= ~API_F )

#if 0
#define IsDraging(p)		((p->StateDraw == DRAG_KEY))
#endif

/*-----------------------------------------------------------------------------
 Macros to process Slider position in LP.
-----------------------------------------------------------------------------*/
#define WidthSlider			(WidthWkey(Infos))
#define HeightSlider		(HeightWkey(Infos))

#define HEIGHT_S_BUTT		3					// height of slider button
#define MinSliderLP			((HeightSlider-2))	// Minimum position
#define MaxSliderLP			(HEIGHT_S_BUTT )		// maximum position
// Range of slider in LP
//#define RangeSliderLP		((-(MaxSliderLP - MinSliderLP)))
#define RangeSliderLP		((MinSliderLP - MaxSliderLP))
// Position Y of Slider Button i
#define ValSliderLP(p,i)	(p->Param.TabSensors[i].ValSliderLP)
//#define ColorSlider(p,i)	(p->TabSensors[i].Color)
#define SliderButtLP(p,i)	((MinSliderLP - ValSliderLP(p,i) - HEIGHT_S_BUTT+1))
#define IdSensor(p,i)		(p->Param.TabSensors[i].IdSensor)

/*--- Macros for slider with zero centered (postive and negative values) ----*/
#define NegRangeLP			((RangeSliderLP/2))
#define MedValLP			((NegRangeLP)) 
#define PosRangeLP			((RangeSliderLP - NegRangeLP))

/*--- Identifier number for Sensor ------------------------------------------*/
enum{
	IDS_AFTER_TOUCH,		
	IDS_PITCH_WHEEL,
	IDS_MOD_WHEEL,
	NBR_SENSORS				// Numbers maximums of sensors.
};

/*-----------------------------------------------------------------------------
 Drawing state
-----------------------------------------------------------------------------*/
enum{
	OFF,
	SET_ON_KEY,
	DRAG_KEY,
	SET_ON_SENSOR,
	DRAG_SENSOR
};


/*-----------------------------------------------------------------------------
 Slider structure
-----------------------------------------------------------------------------*/
typedef struct{
	Byte		IdSensor;			// Index identifier of sensors
	short		ValSliderLP;		// Position in LP  
}SliderDesc;

/*-----------------------------------------------------------------------------
 Parameter structure
-----------------------------------------------------------------------------*/
typedef struct{
	PianoKeyInfos	PianoKey;		// PianoKey informations.
	short			WidthKeyBrd;	// Width from the first to last key.
	short			WidthClient;	// Width of the client aera.
	short			WidthBkey;		// Width of black key.
	short			HeightBkey;		// Height of black key.
	short			WidthWnd;		// Width of the window.
	short			HeightWnd;		// Height of the window.
	Byte			NbrSensors;		// Numbers of sensors.
	SliderDesc TabSensors[NBR_SENSORS];	// Array of sensors descriptors.
	Byte			PKEYerror;		// Status code
}Param, FAR * ParamPtr;

/*-----------------------------------------------------------------------------
			Structure of the variables for a PianoKey windows.
-----------------------------------------------------------------------------*/
typedef struct
{
	//-------------------------------------------------------------------------
	// Specific to Windows OS 
	HINSTANCE hInst;				// module instance.
	HWND hWnd;						// PianoKey window handle.
	//-------------------------------------------------------------------------
//	HCURSOR hPenCur;				// Key cursor.
	HCURSOR hCursor;				// Current cursor.
	Param			Param;			// key range and size informations.
	Byte StateDraw;					// Drawing state.
	ApplNotifyPtr	ApplNotifyPtr;	// Address of call back procedure.
	Byte Flags;						// Flags.
	//-------------------------------------------------------------------------
	short			yMouse;			// Current yMouse cursor
	Byte SearchIdSlider;			// Id Slider under mouse cursor.			
	RECT RectSlider;				// Update rectangle for slider.			
	//-------------------------------------------------------------------------
	Word TabKeyState[8];			// Array of key states ( 8 x 16 bits)
	Word TabEnableKeyOff[8];		// Array of Enable keyOff ( 8 x 16 bits)
	Byte SearchKey;					// Key under mouse cursor
}PKEYinfos, FAR * PKEYinfosPtr;

/*-----------------------------------------------------------------------------
 -----------------------------------------------------------------------------*/
extern Byte TabKeyType[];	// Table of type key.

/*-----------------------------------------------------------------------------
 Macros specific to Windows OS.
-----------------------------------------------------------------------------*/

#define GWL_PKEY_INFOS	0	// Structure offset.
#define GETHINST( hWnd )  ((HINSTANCE) GetWindowLong( hWnd, GWL_HINSTANCE ))
#define GETPKEYINFOS(pInfo,hwnd) ((NULL !=(pInfo =\
		(PKEYinfosPtr) GetWindowLong( hwnd, GWL_PKEY_INFOS ))))

/*-----------------------------------------------------------------------------
 Procedure  specific  to Windows OS.
-----------------------------------------------------------------------------*/
Bool WinPaintPKEY (HWND hWnd);
Bool WinMovePKEY( HWND hWnd, WORD xClientPos, WORD yClientPos );
Bool WinCreatePKEY (HWND hWnd,ParamPtr ParamPtr);
Bool WinDestroyPKEY (HWND hWnd);
Bool WinClosePKEY (HWND  hWnd ); 
Bool MsgHandler (HWND hWnd, UINT message, UINT wParam, LONG lParam);

/*-----------------------------------------------------------------------------
 Procedures
-----------------------------------------------------------------------------*/
void UpdateKeyOn(PKEYinfosPtr Infos, Byte Key, Byte Left);
void UpdateKeyOff(PKEYinfosPtr Infos,Byte Key);
short GetXposKey (ParamPtr Param, Byte NumKey);
void SetUpdateRectKey(PKEYinfosPtr Infos, RECT * Rect, Byte Key);
//Byte GetNbrSensors(PKEYinfosPtr Infos , Byte Flags);
Bool InitCheckParam(ParamPtr Param, DWORD * CreateStylePtr);

/*---------------------------------------------------------------------------*/
#endif	// __PIANO_H__