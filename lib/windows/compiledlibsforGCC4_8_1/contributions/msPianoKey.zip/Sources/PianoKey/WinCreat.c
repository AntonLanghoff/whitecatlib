/*****************************************************************************
  Module: WinCreat.c

  R�le: 	Processing of WM_CREATE, WM_DESTROY, WM_MOVE messages

  e-mail: Jean-Jacques.CERESA@enac.fr
/*****************************************************************************/

#define STRICT
#define  __Windows__
#include "Piano.h"


void DeInitPKEYinfos(PKEYinfosPtr  Infos );

/******************************************************************************
	Creation and initialisation of window structure.
	Input parameters: ParamPtr pointer on parameter coming from CreatePianoKey
	API.
******************************************************************************/
Bool WinCreatePKEY (HWND hWnd,ParamPtr ParamPtr)
{
	
	PKEYinfosPtr   Infos ;
	HINSTANCE hInst;
	//-------------------------------------------------------------------------
	// Allocation de la structure PKEYInfos
	//-------------------------------------------------------------------------

	ParamPtr->PKEYerror = PKEYerrOS;
	// Create the internal structure.
	Infos = calloc(sizeof(PKEYinfos),1);
	if (!Infos) return False;

	// Record the structure pointer in the window structure fen�tre.
	SetWindowLong( hWnd, GWL_PKEY_INFOS, (LONG) Infos ) ;
	Infos->hWnd = hWnd;
	Infos->hInst = hInst =	GETHINST( hWnd );
	//-------------------------------------------------------------------------
	// Initialization of initials parameters.
	Infos->Param = * ParamPtr;
	Infos->StateDraw = OFF;
	// Loading the mouse cursor shape
	if(IsEditPKEY(Style(Infos)))
	{
		Infos->hCursor = LoadCursor(hInst, MAKEINTRESOURCE(IDC_CURSOR1));
	}
	else Infos->hCursor = LoadCursor(NULL,IDC_ARROW);
	ParamPtr->PKEYerror = PKEYok;
	return True;
}

/******************************************************************************
	Window closing
******************************************************************************/
Bool WinClosePKEY (HWND  hWnd )
{
	PKEYinfosPtr  Infos ;
	if (! GETPKEYINFOS(Infos,hWnd)) return(FALSE);
	if (!Infos->ApplNotifyPtr ||
		Infos->ApplNotifyPtr(Infos->hWnd, N_CLOSE_PKEY,0)
		)
		DestroyWindow(hWnd);
	return TRUE;
}

/******************************************************************************
  Window destroying.
******************************************************************************/
Bool WinDestroyPKEY (HWND hWnd)
{
	PKEYinfosPtr  Infos ;
	if (! GETPKEYINFOS(Infos,hWnd)) return(FALSE);
	DeInitPKEYinfos(Infos);   
	return TRUE;
}

/******************************************************************************
  De-initialisation.
******************************************************************************/
void DeInitPKEYinfos(PKEYinfosPtr  Infos )
{
	//---------------------------------
	// Structure PKEYinfos.
	free(Infos);
}

/******************************************************************************
  BOOL WinMovePKEY( HWND hWnd, WORD xClientPos, WORD yClientPos )

  Description: process the  WM_MOVE message.
 
  Input parameters: 
	hWnd,  Handle of the window.
	xClientPos, position X of client area.
	yClientPos, position Y of client area.

******************************************************************************/
Bool WinMovePKEY( HWND hWnd, WORD xClientPos, WORD yClientPos )
{
	PKEYinfosPtr  Infos ;
	RECT r;
	POINT p;

	if (! GETPKEYINFOS(Infos,hWnd)) return(False);
	// Get the new position (in screen coordinates)
	GetWindowRect(hWnd, &r);
	// If PianoKey window is a child, X and Y postion must be converted 
	// relative to the parent window's client area.
	p.x = (short)r.left; p.y = (short)r.top;
	if (IsChildPKEY(Style(Infos)))
	{
		ScreenToClient(GetParent(hWnd),&p);
	}
	xPos(Infos) = (short)p.x; yPos(Infos) = (short)p.y;
	if (!IsApi(Infos) && Infos->ApplNotifyPtr) 
		Infos->ApplNotifyPtr(Infos->hWnd,XY_PKEY,
							MakeLongInfos(xPos(Infos),yPos(Infos)));
	return True ;
}


