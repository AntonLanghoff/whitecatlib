/******************************************************************************
   PkeyDllMain.c
 
   e-mail: Jean-Jacques.CERESA@enac.fr
******************************************************************************/

#define STRICT
#define __Windows__
#define __BuildLib__
#include "Piano.h"


char NameClass[]="CS_PIANOKEY";

extern LRESULT CALLBACK  PianoKeyWinProc (HWND, UINT, UINT, LONG) ;

HINSTANCE hInstanceDll;	// Instance of Dll
Word Version;			// Version infos


/******************************************************************************
 Main procedure for Dll
******************************************************************************/
int WINAPI DllMain (HINSTANCE hInstance, DWORD fdwReason, PVOID pvReserved)
{
	BOOL r;
	WNDCLASS    wndclass ;
	hInstanceDll = hInstance; 
	switch (fdwReason)
	{
		case DLL_PROCESS_ATTACH:
			wndclass.style        = CS_HREDRAW|CS_VREDRAW|CS_OWNDC;
			wndclass.lpfnWndProc  = PianoKeyWinProc;
			wndclass.cbClsExtra   = 0;
			wndclass.cbWndExtra   = sizeof(PKEYinfosPtr);
			wndclass.hInstance    = hInstance;
			wndclass.hIcon     = LoadIcon(NULL,IDI_APPLICATION);
			wndclass.hCursor      = NULL;
			wndclass.hbrBackground= GetStockObject(WHITE_BRUSH);
			wndclass.lpszMenuName = NULL;
			wndclass.lpszClassName= NameClass;
			r = (BOOL) RegisterClass (&wndclass);
			if (r)	Version = 100;
			else	Version = 0;
			break;
		case DLL_PROCESS_DETACH:
			r =	UnregisterClass(NameClass, hInstanceDll);
	}
	return r ;
}


/*-----------------------------------------------------------------------------
 Ckeck the PianoKeyInfos.
-----------------------------------------------------------------------------*/
Byte CheckPianoKeyInfos (ParamPtr Param)
{
	Param->PKEYerror = PKEYerrBadInfos;
	if (Param->PianoKey.FirstKey > Param->PianoKey.LastKey || 
		Param->PianoKey.FirstKey > GM_PITCH_MAX ||
		Param->PianoKey.LastKey > GM_PITCH_MAX) return False;
	
	Param->PKEYerror = PKEYok;
	return True;
}

/*-----------------------------------------------------------------------------
	Position of 12 semitone of an octave. 
	- b7 to b4: The position of each semitone is in number of key.
	- b0: 0 for a white key, 1 for a black key.
-----------------------------------------------------------------------------*/
Byte TabKeyType[]={0, 1*16|1, 1*16, 2*16|1, 2*16, 3*16, 4*16|1, 4*16, 5*16|1,
					5*16, 6*16|1, 6*16 };


/*-----------------------------------------------------------------------------
 Get the X position of a key relative to beging of octave.
-----------------------------------------------------------------------------*/
short GetXposKeyRelOct (ParamPtr Param, Byte NumKey)
{

	Byte Pitch = SemiTone(NumKey);
	short xPos = (TabKeyType[Pitch]>> 4) * (Param->PianoKey.WidthWkey-1);

	if (IsBlackKey(Pitch)) xPos  -= (Param->WidthBkey-1)/2;  
	return xPos;	
}

/*-----------------------------------------------------------------------------
 Get the X position of a key relative to the right edge of keyboard
-----------------------------------------------------------------------------*/
short GetXposKey (ParamPtr Param, Byte NumKey)
{
	Byte FirstKey = Param->PianoKey.FirstKey;
	short xPos = - GetXposKeyRelOct(Param,FirstKey);
	
	xPos += (OctNum(NumKey) - OctNum(FirstKey)) * 
			7 * (Param->PianoKey.WidthWkey-1);
	return xPos + GetXposKeyRelOct(Param,NumKey);
}

/*-----------------------------------------------------------------------------
 Set and init the sliders 
-----------------------------------------------------------------------------*/
void GetNbrSensors(ParamPtr Param)
{
	Byte i;			// Index value of sensors
	Byte Nbr = 0;	// Number of sensors
	Byte Mask = 1;
	for ( i=0; i < NBR_SENSORS; Mask <<= 1, i++)
	{
		if(Mask & Param->PianoKey.Flags)
		{
			{
				Param->TabSensors[Nbr].IdSensor = i;
				if (i == IDS_PITCH_WHEEL)
				{
					short Min =Param->PianoKey.HeightWkey -2; 
					short Med = (Min - MaxSliderLP)/2;
					Param->TabSensors[Nbr].ValSliderLP = Med;
				}
				else Param->TabSensors[Nbr].ValSliderLP = 0;
			}
			Nbr++;
		}
	}
	Param->NbrSensors = Nbr;
}

/*-----------------------------------------------------------------------------
 Initialise and check the Param structure.

 Input parameter:
	Param,	adress of the Param structure filled with KeyRange,WidthKkey,
			HeightWkey and Flags.
			On return the structure is completed with the others field.
	CreateStyle, if not nul, pointer on the returned style need for creation
	             of the pianokey window.

 On return: True if checking of input parameters is correct, false otherwise.
-----------------------------------------------------------------------------*/
Bool InitCheckParam(ParamPtr Param, DWORD * CreateStylePtr)
{
	DWORD	CreateStyle;	// Style
	Word Style = Param->PianoKey.Style;
	//-------------------------------------------------------------------------
	// Adjust the width and height of keys
	Param->PianoKey.WidthWkey = Max(Param->PianoKey.WidthWkey, WIDTH_WKEY);
	Param->PianoKey.HeightWkey = Max(Param->PianoKey.HeightWkey, HEIGHT_WKEY);
	Param->WidthBkey = Param->PianoKey.WidthWkey / 2;	// Width of black key.
	if (!(Param->WidthBkey % 2)) Param->WidthBkey++; 
	Param->HeightBkey = Param->PianoKey.HeightWkey / 2;	// Height of black key.
	//-------------------------------------------------------------------------
	// Checking of parameters.
	if (!CheckPianoKeyInfos (Param)) return False;
	//-------------------------------------------------------------------------
	// Build the creation style
	if (IsChildPKEY(Style))	CreateStyle = WS_CHILD;	// child window.
	else					CreateStyle = WS_POPUP; // overlapped window.
	if (IsBorderPKEY(Style))	CreateStyle |= WS_BORDER;			//Border
	if (IsTitlePKEY(Style))		CreateStyle |= WS_CAPTION;			//Title
	if (IsMinimizePKEY(Style))	CreateStyle |= WS_MINIMIZEBOX;		//Minimize
	if (IsMenuPKEY(Style))		CreateStyle |= (WS_SYSMENU|WS_CAPTION);	//Menu
	//-------------------------------------------------------------------------
	// Make the Width and Height of window
	{
		RECT  Rect;				// Client rectangle structure
		int Width,Height;		// Width and Height of PianoKey window. 

		Byte LastKey = Param->PianoKey.LastKey;
		Width = GetXposKey(Param, LastKey);
		if (IsBlackKey(SemiTone(LastKey))) Width += Param->WidthBkey;
		else								Width += Param->PianoKey.WidthWkey;
		// increase the width if there is sensors.
		Param->WidthKeyBrd = Width;		// Width of keys zone
		GetNbrSensors(Param);
		if(IsEditPKEY(Style))
			Width += Param->NbrSensors * (Param->PianoKey.WidthWkey-1);
		Param->WidthClient = Width;		// Width of the rectangle (client area)
		Height= Param->PianoKey.HeightWkey;
		// compute the width and height of the window.
		Rect.left = 0;		Rect.top = 0;
		Rect.right = Width;	Rect.bottom = Height;
		AdjustWindowRect(&Rect,CreateStyle, FALSE);
		Param->WidthWnd = Width = Rect.right - Rect.left;
		Param->HeightWnd = Height = Rect.bottom - Rect.top;
	}
	if (CreateStylePtr) * CreateStylePtr = CreateStyle; 
	return True;
}

/*-----------------------------------------------------------------------------
	creation of PianoKey window.
-----------------------------------------------------------------------------*/
/* creation */
Byte PIANOKEYAPI CreatePianoKey(
				hParent	hWndParent,		/* Handle of parent					*/
				PtrhPianoKey	PtrhPianoKey,	/* Pointer on Window handle */
				TitlePtr	Title,		/* Title of the window.				*/	
				Word		Style,		/* Style of window					*/
				Word		xPos,		/* Position x of topleft edge		*/
				Word		yPos,		/* Position y of topleft	edge	*/
				Word		KeyRange,	/* First key and last key			*/
				Word		WidthWkey,	/* Width white keys.				*/
				Word		HeightWkey,	/* Height white keys.				*/
				Byte 		Flags		/* Flags							*/ 
				)
{

	hPianoKey hWnd;
	DWORD	CreateStyle;	// Style
	Param Param;			// Save parameters.
	
	//-------------------------------------------------------------------------
	// Checking of hWndParent
	if (! IsWindow(hWndParent)) { return PKEYerrBadHandle;}

	//-------------------------------------------------------------------------
	// Build the parameters structure.
	Param.PianoKey.LenTitle = strlen(Title)+1;
	Param.PianoKey.Style = Style;
	Param.PianoKey.xPos = xPos;	Param.PianoKey.yPos = yPos;
	Param.PianoKey.FirstKey = FirstKeyRANGE_PKEY(KeyRange);
	Param.PianoKey.LastKey = LastKeyRANGE_PKEY(KeyRange);
	Param.PianoKey.WidthWkey = WidthWkey;
	Param.PianoKey.HeightWkey = HeightWkey;
	Param.PianoKey.Flags = Flags;				// Flags;		

	if (!InitCheckParam(&Param, &CreateStyle)) return Param.PKEYerror;

	//---------------------------------------------------------------------
	// Creation
	Param.PKEYerror = PKEYerrOS;
	hWnd=CreateWindow (NameClass,Title,
			  CreateStyle,
			  Param.PianoKey.xPos,Param.PianoKey.yPos,
			  Param.WidthWnd,Param.HeightWnd,hWndParent,
			  NULL,hInstanceDll,&Param);
	//-------------------------------------------------------------------------
	/* Show the window */
    if (hWnd ) 
	{
		ShowWindow (hWnd, SW_NORMAL) ;
	}
	* PtrhPianoKey = hWnd;
	return Param.PKEYerror;
}

/*----------------------------------------------------------------------------
	Destroying PianoKey window .
-----------------------------------------------------------------------------*/
Byte	PIANOKEYAPI DestroyPianoKey(
				hPianoKey hWndPianoKey	/* Handle of PianoKey window	 */
				)
{
	if (DestroyWindow(hWndPianoKey)) return PKEYok; 
	else return PKEYerrBadHandle;
}

/*----------------------------------------------------------------------------
	Setting application notify  procedure.
-----------------------------------------------------------------------------*/
Byte	PIANOKEYAPI SetPianoKeyApplNotify (
				hPianoKey hWndPianoKey,		/* Handle of Pianokey window	*/
				ApplNotifyPtr ApplNotify	/* Pointer to notify routine	*/
				)
{
	PKEYinfosPtr  Infos ;
	if (! GETPKEYINFOS(Infos,hWndPianoKey)) return PKEYerrBadHandle;
	else
	{
		if(IsCanNotifyPKEY(Style(Infos)))
		{	Infos->ApplNotifyPtr = ApplNotify; 	PKEYerror(Infos) = PKEYok;}
		else PKEYerror(Infos) = PKEYerrBadOp	; 
	}
	return PKEYerror(Infos);
}

/*----------------------------------------------------------------------------
	Getting version informations.
-----------------------------------------------------------------------------*/
Word 	PIANOKEYAPI GetPianoKeyVersion( void )
{
	return Version;
}
