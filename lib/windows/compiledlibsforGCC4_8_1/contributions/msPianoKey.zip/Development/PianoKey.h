/*----------------------------------------------------------------------------
 PianoKey.h

 Header file for applications using PianoKey. 

 e-mail: Jean-Jacques.CERESA@enac.fr
-----------------------------------------------------------------------------*/

#ifndef __PIANOKEY_H__
#define __PIANOKEY_H__

/*---------------------------------------------------------------------------*/
/* To use for Windows, add: #define __Windows__ in your sources files */


/*--- Definition for the Windows Operating System ---------------------------*/
#ifdef __Windows__
#include <windows.h>		
#ifdef WIN32 /* For WIN 32 applications or DLL */
/* for DLL library building add: #define  __BuildLib__  in your sources files */
#	ifdef __BuildLib__
		
#	   define PIANOKEYAPI  __declspec(dllexport) /* to export API functions */

#	else

#	   define PIANOKEYAPI  __declspec(dllimport) /* to import API functions */

#	endif
#	define PIANOKEYALARMAPI	CALLBACK

#else	/* Not WIN32 but WIN 16 bits */

#  define PIANOKEYAPI WINAPI _export
#  define PIANOKEYALARMAPI	WINAPI _export

#endif	/* WIN32 */


typedef HWND	hPianoKey;	/* Handle of a PianoKey window. */
typedef HWND	hParent;	/* Handle of a PianoKey window parent. */

#endif	/* __Windows__ */

/*-----------------------------------------------------------------------------
	Common types and declarations.
-----------------------------------------------------------------------------*/
typedef unsigned long       Dword;
typedef unsigned short      Word;
typedef unsigned char       Byte;
typedef Byte				Bool;
#define MakeWord(a, b)      ((Word)(((Byte)(a)) | ((Word)((Byte)(b))) << 8))
#define MakeLong(a, b)		((long)(((Word)(a)) | ((Dword)((Word)(b))) << 16))
#define LoWord(l)           ((Word)(l))
#define HiWord(l)           ((Word)(((Dword)(l) >> 16) & 0xFFFF))
#define LoByte(w)           ((Byte)(w))
#define HiByte(w)           ((Byte)(((Word)(w) >> 8) & 0xFF))

#define Max(a,b)            (((a) > (b)) ? (a) : (b))
#define Min(a,b)            (((a) < (b)) ? (a) : (b))

#define Null    ((void *)0)

#define False               0
#define True                1
/*---------------------------------------------------------------------------*/


/*-----------------------------------------------------------------------------
 These macros are useful for Getting and Setting informations
-----------------------------------------------------------------------------*/

#define LoWordInfos(li)	(LoWord(li))
#define HiWordInfos(li)	(HiWord(li))
#define LoByteInfos(wi)	(LoByte(wi))
#define HiByteInfos(wi)	(HiByte(wi))
#define MakeLongInfos(lw,hw) (MakeLong(lw,hw))
#define MakeWordInfos(lb,hb) (MakeWord(lb,hb))

/*------------ Macros for setting information -------------------------------*/
/* Build a XY_PKEY information */
#define MakeXY_PKEY(x,y) (MakeLongInfos(x,y))

/* Build a RANGE_PKEY information */
#define MakeRANGE_PKEY(FirstKey,LastKey) (MakeWordInfos(FirstKey,LastKey))
													
/* Build a SIZE_WKEY information */
#define MakeSIZE_WKEY(w,h) (MakeLongInfos(w,h)) 

/* Build a SKEY_PKEY information */
#define MakeSKEY_PKEY(State,NumKey) \
					(MakeLongInfos(MakeWordInfos(State,NumKey),0)) 

/*------------ Macros for getting informations ------------------------------*/
/* Return the X and X position from XY_PKEY informations */	
#define XposXY_PKEY(i) (LoWordInfos(i))	/* Return the X position	*/	
#define YposXY_PKEY(i) (HiWordInfos(i))	/* Return the Y position	*/

/* Return the Width and Height from SIZE_PKEY informations */	
#define WidthSIZE_PKEY(i) (LoWordInfos(i)) /* Return the Width of window  */
#define HeightSIZE_PKEY(i)(HiWordInfos(i)) /* Return the Height of window */

/* Return the first key and the last key from RANGE_PKEY informations */	
#define FirstKeyRANGE_PKEY(i)	 (LoByteInfos(i))	/* Return first key */
#define LastKeyRANGE_PKEY(i)	 (HiByteInfos(i))	/* Return last key  */

/* Return the Width and Height from SIZE_WKEY informations */	
#define WidthSIZE_WKEY(i) (LoWordInfos(i)) /* Return the Width of white key  */
#define HeightSIZE_WKEY(i)(HiWordInfos(i)) /* Return the Height of white key */

/* Return State , NumKey and Velocity from SKEY_PKEY informations */	
#define StateSKEY_PKEY(i)	 (LoByteInfos(LoWordInfos(i)))	/* return state	*/
#define NumKeySKEY_PKEY(i)	 (HiByteInfos(LoWordInfos(i)))	/* return key  */
#define VelSKEY_PKEY(i)	 (LoByteInfos(HiWordInfos(i)))	/* return velocity */

/* Return Pressure and NumKey from N_AFTER_TOUCH informations */	
#define PressN_AFTER_TOUCH(i) (LoByteInfos(LoWordInfos(i)))	/* return pressure */
#define NumKeyN_AFTER_TOUCH(i)(HiByteInfos(LoWordInfos(i)))	/* return key  */

/*--Defaults values ----------------------------------------------------------*/
#define FIRST_KEY   0				  /* First key of the keyboard. */
#define LAST_KEY    127				  /* Last key of the keyboard.  */

#define WIDTH_WKEY  6				  /* Min width of white key   */
#define HEIGHT_WKEY  (3*WIDTH_WKEY)	  /* height of white key  */


/*-----------------------------------------------------------------------------
	Structure of informations about a PianoKey window.
-----------------------------------------------------------------------------*/
/* Style */
#define	S_EDIT_PKEY		0x0001	/* Interactive window 			*/
#define S_BORDER_PKEY	0x0004	/* Border						*/
#define S_TITLE_PKEY	0x0008	/* Caption bar and border		*/
#define S_MENU_PKEY		0x0040	/* Menu							*/
#define S_MINIMIZE_PKEY	0x0080	/* Minimize button				*/
#define S_CHILD_PKEY	0x0400	/* Child window					*/

#define S_DEFAULT_PKEY		((S_TITLE_PKEY|S_EDIT_PKEY|S_MENU_PKEY))
#define S_CANNOTIFY_PKEY	((S_TITLE_PKEY|S_EDIT_PKEY ))

#define IsEditPKEY(s)		((s & S_EDIT_PKEY))
#define IsBorderPKEY(s)		((s & S_BORDER_PKEY))
#define IsTitlePKEY(s)		((s & S_TITLE_PKEY))
#define IsMenuPKEY(s)		((s & S_MENU_PKEY))
#define IsMinimizePKEY(s)	((s & S_MINIMIZE_PKEY))
#define IsChildPKEY(s)		((s & S_CHILD_PKEY))
#define IsCanNotifyPKEY(s)	((s & S_CANNOTIFY_PKEY))


typedef char FAR *TitlePtr;
typedef  void * InfosPtr;
typedef struct
{
	Byte	LenTitle;	/* Lenght of title.									*/
	Word	Style;		/* Style											*/
	short	xPos;		/* Position x of right edge.						*/
	short	yPos;		/* Position y of the top edge.						*/
	Byte	FirstKey;	/* First key on the keyboard						*/
	Byte	LastKey;	/* Last key on the keyboard							*/
	short	WidthWkey;	/* Width of white keys.								*/
	short	HeightWkey;	/* Height of white keys.							*/
	Byte	Flags;		/* Validations flags: 								*/
						/* F_AFTER_TOUCH for after-touch sensor				*/
						/* F_PITCH_WHEEL for pitch wheel					*/
						/* F_MOD_WHEEL for modulation wheel					*/
}PianoKeyInfos, * FAR PianoKeyInfosPtr;


/*-----------------------------------------------------------------------------
	APIs for PianoKey window.
-----------------------------------------------------------------------------*/

typedef  hPianoKey * FAR PtrhPianoKey;		/* Pointer on hPianoKey			*/

/*-----------------------------------------------------------------------------
	creation - destruction of a  MsNotes window.
-----------------------------------------------------------------------------*/
/* creation */
Byte PIANOKEYAPI CreatePianoKey(
				hParent	hWndParent,		/* Handle of parent					*/
				PtrhPianoKey	PtrhPianoKey,	/* Pointer on Window handle */
				TitlePtr	Title,		/* Title of the window.				*/	
				Word		Style,		/* Style of window					*/
				Word		xPos,		/* Position x of topleft edge		*/
				Word		yPos,		/* Position y of topleft	edge	*/
				Word		KeyRange,	/* First key and last key			*/
				Word		WidthWkey,	/* Width white keys.				*/
				Word		HeightWkey,	/* Height white keys.				*/
				Byte 		Flags		/* Flags							*/ 
				);


/*  destruction */
Byte	PIANOKEYAPI DestroyPianoKey(
				hPianoKey hWndPianoKey	/* Handle of PianoKey window	 */
				);

/*----------------------------------------------------------------------------
	Getting and setting general informations about a PianoKey window.
-----------------------------------------------------------------------------*/
/* Following are codes identifiers informations:InfosId */
enum 
{	/* codes identifiers for window informations */
	LEN_TITLE_PKEY = 0,	/* Number of byte of title (R-W)					*/
	TITLE_PKEY ,		/* Window title	(R-W)								*/
	STYLE_PKEY,			/* style (R)										*/
	XY_PKEY,		/* Coordinate of the upper-left corner X et Y (R-W-N)	*/
	SIZE_PKEY,		/* Height and width	(R)									*/
	RANGE_PKEY,		/* First key and last key on keyboard	 (R-W)			*/
	SIZE_WKEY,		/* Height and width	of white keys(R-W)					*/
	FLAGS_PKEY,		/* Validation flags	(R-W)								*/
	INFOS_PKEY,		/* All the window informations (R-W)					*/
 	SKEY_PKEY,		/* State and key number (R-W-N)							*/
	
	/* Notify code only */
	N_AFTER_TOUCH,	/* After touch sensor in action	(N)						*/
	N_PITCH_WHEEL,	/* Pitch wheel in action (N)								*/
	N_MOD_WHEEL,	/* Modulation wheel in action (N)							*/
	N_CLOSE_PKEY	/* The user close the PianoKey Window (N)					*/
};


/*----------------------------------------------------------------------------
	Values of the flags infos FLAGS_PKEY.
	Each bit of infos value is a flag. The description of the flags follow.
-----------------------------------------------------------------------------*/

#define F_AFTER_TOUCH	0x01	/* to enable after touch sensor				*/
#define F_PITCH_WHEEL	0x02	/* to enable pitch wheel					*/
#define F_MOD_WHEEL		0x04	/* to enable modulation wheel				*/

#define IsAfterTouch(f)		((f & F_AFTER_TOUCH))
#define SetAfterTouch(f)	( f |= F_AFTER_TOUCH )
#define ResetAfterTouch(f)	( f &= ~F_AFTER_TOUCH )

#define IsPitchWheel(f)		((f & F_PITCH_WHEEL))
#define SetPitchWheel(f)	( f |= F_PITCH_WHEEL )
#define ResetPitchWheel(f)	( f &= ~F_PITCH_WHEEL )

#define IsModWheel(f)		((f & F_PITCH_WHEEL))
#define SetModWheel(f)	( f |= F_PITCH_WHEEL )
#define ResetModWheel(f)	( f &= ~F_PITCH_WHEEL )

/* Getting informations */
Byte 	PIANOKEYAPI GetPianoKeyInfos ( 
				hPianoKey	hWndPianoKey,	/* Handle of PianoKey window	*/
				Byte		InfosId,		/* Id of infos to retrieve		*/ 
				InfosPtr	Infos			/* Pointer on infos to retrieve	*/
);


/* Setting informations */
Byte 	PIANOKEYAPI SetPianoKeyInfos ( 
				hPianoKey	hWndPianoKey,	/* Handle of PianoKey window	*/
				Byte		InfosId,		/* Id of infos to retrieve		*/ 
				long		Infos			/* Value to set					*/
);

/*-----------------------------------------------------------------------------
	Application notify proc�dure 
-----------------------------------------------------------------------------*/
typedef Byte (PIANOKEYALARMAPI *ApplNotifyPtr) (
				hPianoKey	hWndPianoKey,	/* Handle of PianoKey window	*/
				Byte		InfosId,		/* Id of the changed infos		*/ 
				long		Infos			/* Value of the infos			*/
				);
				

/*----------------------------------------------------------------------------
	Setting application notify  procedure.
-----------------------------------------------------------------------------*/
Byte	PIANOKEYAPI SetPianoKeyApplNotify (
				hPianoKey hWndPianoKey,		/* Handle of Pianokey window	*/
				ApplNotifyPtr ApplNotify	/* Pointer to notify routine	*/
				);

					
/*----------------------------------------------------------------------------
	Getting Status informations.
-----------------------------------------------------------------------------*/
/*-----------------------------------------------------------------------------
 Code errors: PKEYerror
-----------------------------------------------------------------------------*/
#define		PKEYok				0	/* Successful operation.				*/
/* Errors returned by API operating system calls */
#define		PKEYerrOS			1	/* Operating System errror.				*/
/* Invalid parameters */
#define		PKEYerrBadHandle	2	/* Handle of window is invalid.			*/
#define		PKEYerrBadInfos		3	/* Infos value is invalid.				*/
#define		PKEYerrBadIdInfos	4	/* Code identifier is invald.			*/
#define		PKEYerrBadOp		5	/* Operation (Set or Get) is invalid	*/


/*----------------------------------------------------------------------------
	Getting version informations.
-----------------------------------------------------------------------------*/
Word 	PIANOKEYAPI GetPianoKeyVersion( void );

/*---------------------------------------------------------------------------*/
#endif  /*  __PIANOKEY_H__ */

